import React, { useState, useRef, useEffect } from 'react';
import { 
  Upload, 
  FileSpreadsheet, 
  Check, 
  HelpCircle, 
  Sparkles, 
  Eye, 
  ArrowRight, 
  Settings, 
  RefreshCw, 
  AlertCircle, 
  Trash2, 
  Info,
  Sliders,
  CheckCircle2,
  X
} from 'lucide-react';
import { parseCSVToRows, guessMappings, processMappedRows, INDICATORS, ColumnMapping, SurveyAudience } from '../lib/csvParser';
import { SemesterData, CustomQuestion } from '../types';

interface IntelligentCSVImporterProps {
  semesters: SemesterData[];
  onImportComplete: (nuevoSemestre: SemesterData, feedbackMessage: string) => void;
  suggestedAudience?: SurveyAudience;
}

interface LoadedFileInfo {
  fileName: string;
  headers: string[];
  rows: Record<string, string>[];
  mappings: ColumnMapping[];
  confidence: number;
}

export const IntelligentCSVImporter: React.FC<IntelligentCSVImporterProps> = ({
  semesters,
  onImportComplete,
  suggestedAudience
}) => {
  // Dual file states
  const [clientFile, setClientFile] = useState<LoadedFileInfo | null>(null);
  const [teamFile, setTeamFile] = useState<LoadedFileInfo | null>(null);

  // Target semester
  const [inputSemester, setInputSemester] = useState<string>('2027-S1');

  // Drag states for both areas
  const [dragActiveClient, setDragActiveClient] = useState(false);
  const [dragActiveTeam, setDragActiveTeam] = useState(false);

  // Error/Success feedbacks
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Step: 'uploading' | 'mapping' | 'preview'
  const [step, setStep] = useState<'uploading' | 'mapping' | 'preview'>('uploading');

  // Inputs reference
  const clientInputRef = useRef<HTMLInputElement>(null);
  const teamInputRef = useRef<HTMLInputElement>(null);

  // Memory mapping retrieval
  const getRememberedMappings = (): Record<string, string> => {
    try {
      const data = localStorage.getItem('comuniza_remembered_csv_mappings');
      return data ? JSON.parse(data) : {};
    } catch {
      return {};
    }
  };

  const saveRememberedMappings = (newMapeos: ColumnMapping[]) => {
    try {
      const saved = getRememberedMappings();
      newMapeos.forEach(m => {
        if (m.mappedKey !== 'ignore') {
          saved[m.csvHeader.toLowerCase()] = m.mappedKey;
        }
      });
      localStorage.setItem('comuniza_remembered_csv_mappings', JSON.stringify(saved));
    } catch (e) {
      console.warn('No se pudieron guardar las preferencias de mapeo', e);
    }
  };

  // Deduced semester from file name
  const tryDeduceSemester = (name: string) => {
    const nameMatch = name.match(/20\d{2}[-_\s]?[sS][12]/i);
    if (nameMatch) {
      const parts = nameMatch[0].toUpperCase().replace('_', '-').replace(' ', '-');
      const year = parts.substring(0, 4);
      const sem = parts.includes('S1') ? 'S1' : 'S2';
      setInputSemester(`${year}-${sem}`);
    }
  };

  // Import flow for specific audience
  const handleFileLoad = (file: File, audience: SurveyAudience) => {
    setErrorMsg(null);
    tryDeduceSemester(file.name);

    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target?.result as string;
      if (!text || text.trim().length === 0) {
        setErrorMsg(`El archivo de ${audience === 'clientes' ? 'Clientes' : 'Equipo'} está vacío.`);
        return;
      }
      processUploadedCSV(text, file.name, audience);
    };
    reader.onerror = () => {
      setErrorMsg(`Error al abrir el archivo de ${audience === 'clientes' ? 'Clientes' : 'Equipo'}.`);
    };
    reader.readAsText(file);
  };

  const processUploadedCSV = (csvText: string, name: string, audience: SurveyAudience) => {
    try {
      const { headers: parsedHeaders, rows: parsedRows } = parseCSVToRows(csvText);
      if (parsedHeaders.length === 0 || parsedRows.length === 0) {
        setErrorMsg(`Mala estructura: no se detectaron filas útiles en el archivo "${name}".`);
        return;
      }

      // 1. Initial heuristic guess for the audience
      const guess = guessMappings(parsedHeaders, audience);

      // 2. Adjust mapping based on memory
      const remembered = getRememberedMappings();
      const adaptedMappings = guess.mappings.map(m => {
        const key = m.csvHeader.toLowerCase();
        if (remembered[key]) {
          const matchingInd = INDICATORS.find(i => i.key === remembered[key]);
          if (matchingInd && matchingInd.group === audience) {
            return {
              ...m,
              mappedKey: remembered[key],
              label: matchingInd.label
            };
          }
        }
        return m;
      });

      // 3. Recalculate confidence for this file
      const requiredInds = INDICATORS.filter(ind => ind.group === audience && ind.isRequired);
      const mappedRequiredCount = requiredInds.filter(req => adaptedMappings.some(m => m.mappedKey === req.key)).length;
      const confidence = requiredInds.length > 0 ? (mappedRequiredCount / requiredInds.length) : 1;

      const fileInfo: LoadedFileInfo = {
        fileName: name,
        headers: parsedHeaders,
        rows: parsedRows,
        mappings: adaptedMappings,
        confidence: confidence
      };

      if (audience === 'clientes') {
        setClientFile(fileInfo);
      } else {
        setTeamFile(fileInfo);
      }
    } catch (err) {
      setErrorMsg(`Error al procesar el archivo CSV de ${audience === 'clientes' ? 'Clientes' : 'Equipo'}. Comprueba que las columnas sigan un formato correcto.`);
    }
  };

  // Drag handlers for Clientes
  const handleDragClient = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActiveClient(true);
    } else if (e.type === "dragleave") {
      setDragActiveClient(false);
    }
  };

  const handleDropClient = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActiveClient(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileLoad(e.dataTransfer.files[0], 'clientes');
    }
  };

  // Drag handlers for Equipo
  const handleDragTeam = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActiveTeam(true);
    } else if (e.type === "dragleave") {
      setDragActiveTeam(false);
    }
  };

  const handleDropTeam = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActiveTeam(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileLoad(e.dataTransfer.files[0], 'equipo');
    }
  };

  // Remove uploaded slots
  const removeClientFile = () => {
    setClientFile(null);
    setErrorMsg(null);
  };

  const removeTeamFile = () => {
    setTeamFile(null);
    setErrorMsg(null);
  };

  // Trigger processing when files are uploaded
  const handleProceed = () => {
    if (!clientFile && !teamFile) {
      setErrorMsg('Debes cargar al menos un archivo CSV (Clientes o Equipo) para continuar.');
      return;
    }

    // Check if any loaded file has low confidence (confidence < 1.0)
    const clientNeedsMapping = clientFile ? clientFile.confidence < 1.0 : false;
    const teamNeedsMapping = teamFile ? teamFile.confidence < 1.0 : false;

    if (clientNeedsMapping || teamNeedsMapping) {
      // Directs to Mapping Safety Net
      setStep('mapping');
    } else {
      // High confidence automatically goes directly to instant Preview! Zero friction!
      setStep('preview');
    }
  };

  // Handle manual column mapping changes
  const handleColumnMapChange = (header: string, targetKey: string, audience: SurveyAudience) => {
    const file = audience === 'clientes' ? clientFile : teamFile;
    if (!file) return;

    const updated = file.mappings.map(m => {
      if (m.csvHeader === header) {
        if (targetKey === 'ignore') {
          return { ...m, mappedKey: 'ignore', label: 'Ignorar columna' };
        }
        const indicator = INDICATORS.find(i => i.key === targetKey);
        return { 
          ...m, 
          mappedKey: targetKey, 
          label: indicator ? indicator.label : 'Ignorar columna' 
        };
      }
      return m;
    });

    const requiredInds = INDICATORS.filter(ind => ind.group === audience && ind.isRequired);
    const mappedRequiredCount = requiredInds.filter(req => updated.some(m => m.mappedKey === req.key)).length;
    const newConf = requiredInds.length > 0 ? (mappedRequiredCount / requiredInds.length) : 1;

    const updatedFile = { ...file, mappings: updated, confidence: newConf };

    if (audience === 'clientes') {
      setClientFile(updatedFile);
    } else {
      setTeamFile(updatedFile);
    }
  };

  // Confirm and combine final inputs
  const handleConfirmImport = () => {
    try {
      // 1. Save preferences to memory
      if (clientFile) saveRememberedMappings(clientFile.mappings);
      if (teamFile) saveRememberedMappings(teamFile.mappings);

      // 2. Process both files to get metrics
      const clientParsed = clientFile ? processMappedRows(clientFile.rows, clientFile.mappings, 'clientes', inputSemester) : null;
      const teamParsed = teamFile ? processMappedRows(teamFile.rows, teamFile.mappings, 'equipo', inputSemester) : null;

      // Clean ID representation
      const cleanPeriodID = (inputSemester || '2027-S1')
        .replace('-', '-S')
        .split('-S')
        .reverse()
        .join('-')
        .toUpperCase(); // e.g. "S1-2027"

      // 3. Form unified SemesterData object
      // Take existing client/team items from historical state if any, to avoid loss of opposite audience data
      const existing = semesters.find(s => s.id === cleanPeriodID);

      // Combine custom questions safely
      let combinedCustomQs: CustomQuestion[] = [];
      if (existing && existing.customQuestions) {
        combinedCustomQs = [...existing.customQuestions];
      }
      if (clientParsed?.customQuestions) {
        clientParsed.customQuestions.forEach(newQ => {
          combinedCustomQs = combinedCustomQs.filter(q => !(q.header === newQ.header && q.audience === 'clientes'));
          combinedCustomQs.push(newQ);
        });
      }
      if (teamParsed?.customQuestions) {
        teamParsed.customQuestions.forEach(newQ => {
          combinedCustomQs = combinedCustomQs.filter(q => !(q.header === newQ.header && q.audience === 'equipo'));
          combinedCustomQs.push(newQ);
        });
      }

      const mergedData: SemesterData = {
        id: cleanPeriodID,
        periodo: inputSemester || '2027-S1',
        customQuestions: combinedCustomQs.length > 0 ? combinedCustomQs : undefined,

        // CLIENT DATA: new parsed values, or if not uploaded, existing historical values, or safe fallback
        clienteNumRespuestas: clientFile ? clientFile.rows.length : (existing ? existing.clienteNumRespuestas : 0),
        palabrasA1: clientParsed?.palabrasA1 || (existing ? existing.palabrasA1 : [
          { text: 'Sólido', value: 15 }, { text: 'Cercano', value: 12 }, { text: 'Confianza', value: 8 }
        ]),
        fortalezasA2: clientParsed?.fortalezasA2 || (existing ? existing.fortalezasA2 : {
          'Propuesta de valor': 40, 'Calidad de productos o servicios': 25, 
          'Experiencia de cliente': 20, 'Credibilidad y confianza': 15, 'Otro': 0
        }),
        acuerdoA3: clientParsed?.acuerdoA3 || (existing ? existing.acuerdoA3 : {
          propuesta_clara: 8.0, relevancia_publicos: 8.0, diferenciacion_alternativas: 7.8,
          genera_confianza: 8.1, proyecta_coherencia: 8.0, evolucion_adecuada: 8.0
        }),
        apropiacionA4: clientParsed?.apropiacionA4 || (existing ? existing.apropiacionA4 : {
          no_la_entiendo: 5, no_relaciono: 10, relaciono_parcialmente: 20, relaciono_claramente: 40, relaciono_y_diferencial: 25
        }),
        personalidadA5: clientParsed?.personalidadA5 || (existing ? existing.personalidadA5 : {
          'Cercana': 44, 'Innovadora': 38, 'Fiable': 42, 'Inspiradora': 30, 'Experta': 38
        }),
        retosA6: clientParsed?.retosA6 || (existing ? existing.retosA6 : {
          'Experiencia de cliente': 35, 'Comunicación': 35, 'Diferenciación': 20, 'Innovación': 10
        }),
        clustersA7: clientParsed?.clustersA7 || (existing ? existing.clustersA7 : [
          { name: 'Consolidación de atributos de cercanía comercial', percentage: 65 },
          { name: 'Demanda de mayor claridad en la diversificación de gama', percentage: 35 }
        ]),

        // TEAM DATA: new parsed values, or if not uploaded, existing historical values, or safe fallback
        empleadoNumRespuestas: teamFile ? teamFile.rows.length : (existing ? existing.empleadoNumRespuestas : 0),
        acuerdoB1: teamParsed?.acuerdoB1 || (existing ? existing.acuerdoB1 : {
          entiendo_posicionamiento: 8.5, se_aplicar_marca: 8.0, recursos_suficientes: 7.5, mejores_decisiones: 8.0, coherencia_promesa: 8.0
        }),
        apropiacionB2: teamParsed?.apropiacionB2 || (existing ? existing.apropiacionB2 : {
          no_la_entiendo: 2, no_relaciono: 5, relaciono_parcialmente: 15, relaciono_claramente: 45, relaciono_y_diferencial: 33
        }),
        barrerasB3: teamParsed?.barrerasB3 || (existing ? existing.barrerasB3 : {
          'Falta de claridad': 10, 'Falta de herramientas o plantillas': 15, 'Falta de formación': 12,
          'Incoherencias entre áreas': 18, 'Falta de tiempo': 30, 'Resistencia al cambio': 10, 'Otro': 5
        }),
        clustersB4: teamParsed?.clustersB4 || (existing ? existing.clustersB4 : [
          { name: 'Excelente acogida a la nueva guía simplificada', percentage: 70 },
          { name: 'Petición de talleres breves interdepartamentales', percentage: 30 }
        ])
      };

      // Feed complete semester data back to core
      let auditMsg = '';
      if (clientFile && teamFile) {
        auditMsg = `¡Datos consolidados correctamente! Cargadas ${clientFile.rows.length} encuestas de clientes y ${teamFile.rows.length} de equipo para el semestre ${inputSemester}.`;
      } else if (clientFile) {
        auditMsg = `¡Datos consolidados correctamente! Cargadas ${clientFile.rows.length} encuestas de clientes para el semestre ${inputSemester}. No se modificó el equipo.`;
      } else if (teamFile) {
        auditMsg = `¡Datos consolidados correctamente! Cargadas ${teamFile.rows.length} encuestas de equipo para el semestre ${inputSemester}. No se modificaron los clientes.`;
      }

      onImportComplete(mergedData, auditMsg);

      // Clean slots
      setClientFile(null);
      setTeamFile(null);
      setStep('uploading');
    } catch (e) {
      setErrorMsg('Ocurrió un error inesperado al consolidar y guardar los datos mapeados.');
    }
  };

  // Demo loaders for quick checks
  const handleLoadDemoCSV = (type: 'clientes' | 'equipo') => {
    const clientsStr = `Semestre de Medición;Asociación de Palabras libres;¿Cuál crees que es la principal fortaleza?;Claridad de propuesta;Relevancia pág;Diferenciacion;Grado de Confianza;Coherencia percibida;Evolucion;Acoplamiento de marca;Atributos extra opcionales;Retos clave
2027-S1;Cercano;Sólido;Ágil;Propuesta de valor;8.8;8.2;7.9;8.4;9.1;8.5;relaciono_claramente;Innovadora;Cálida;Comunicación
2027-S1;Innovador;Confiable;Rápido;Calidad de productos o servicios;9.1;8.5;8.0;8.7;8.8;8.7;relaciono_y_diferencial;Cercana;Diferenciación`;

    const employeesStr = `Período;Entiendo el posicionamiento;Sé aplicar la marca en mi puesto de trabajo;Tengo recursos suficientes;Mejores decisiones cotidianas;Coherencia con las promesas de marca;Nivel de vinculación individual;Dificultades detectadas;Sugerencias abiertas
2027-S1;9.2;8.4;8.1;8.6;8.4;relaciono_y_diferencial;Incoherencias entre áreas;Más formación
2027-S1;8.3;7.8;8.0;8.2;8.1;relaciono_claramente;Falta de tiempo;Talleres prácticos`;

    const csvText = type === 'clientes' ? clientsStr : employeesStr;
    const dummyName = type === 'clientes' ? 'GoogleForms_Respuestas_Clientes_Crudo.csv' : 'Typeform_Alineacion_Equipo_Crudo.csv';

    processUploadedCSV(csvText, dummyName, type);
  };

  return (
    <div className="w-full bg-white border border-[#E5E5E0] rounded-none-none overflow-hidden shadow-2xs" id="intelligent-csv-importer-root">
      
      {/* 1. UPLOADING SCREEN */}
      {step === 'uploading' && (
        <div className="p-6 sm:p-8 space-y-6">
          
          {/* Top Recommendation path block with Comuniza branding guidelines info */}
          <div className="p-4 bg-emerald-50/50 border border-emerald-100 rounded-none-none space-y-2">
            <h5 className="text-xs font-bold text-emerald-950 flex items-center gap-1.5 font-display">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              Ruta automática inteligente sin plantilla intermedia
            </h5>
            <p className="text-xs text-emerald-900/85 leading-relaxed font-sans">
              <strong>Si usas el formulario que te ha preparado Comuniza, la carga es automática:</strong> exporta el CSV de Google Forms directamente y súbelo aquí. La herramienta detectará las preguntas por palabras clave y generará las métricas sin que tengas que copiar y pegar ningún texto.
            </p>
          </div>

          {/* DUAL DROPZONES GRID */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            
            {/* AREA 1: CLIENTES */}
            <div 
              onDragEnter={handleDragClient}
              onDragOver={handleDragClient}
              onDragLeave={handleDragClient}
              onDrop={handleDropClient}
              className={`border border-dashed rounded-none-none p-5 flex flex-col items-center justify-between min-h-[220px] text-center transition-all ${
                clientFile 
                  ? 'border-emerald-300 bg-emerald-50/10' 
                  : dragActiveClient 
                    ? 'border-[#F9423A] bg-[#F9423A]/5' 
                    : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50/30'
              }`}
            >
              <div className="space-y-3 w-full">
                <div className={`p-2.5 mx-auto rounded-none-none w-fit ${clientFile ? 'bg-emerald-50 text-emerald-600' : 'bg-[#F9423A]/5 text-[#F9423A]'}`}>
                  <FileSpreadsheet className="w-6 h-6 stroke-[1.5]" />
                </div>
                
                <div className="space-y-1">
                  <h4 className="text-xs font-bold text-gray-900 font-display">Encuesta de Clientes (Mercado)</h4>
                  <p className="text-[11px] text-gray-400 max-w-[240px] mx-auto">
                    Arrastra aquí el CSV directo de Google Forms o selecciona el archivo.
                  </p>
                </div>

                {clientFile ? (
                  <div className="p-2 bg-emerald-50 border border-emerald-100 rounded-none-none text-left flex items-center justify-between gap-1.5">
                    <div className="truncate min-w-0">
                      <span className="block font-mono text-[9px] font-bold text-emerald-800 leading-none truncate">{clientFile.fileName}</span>
                      <span className="text-[10px] text-emerald-600 font-medium font-mono">{clientFile.rows.length} respuestas cargadas</span>
                    </div>
                    <button 
                      type="button" 
                      onClick={removeClientFile}
                      className="p-1 hover:bg-emerald-100 text-emerald-700 hover:text-rose-600 rounded-none cursor-pointer transition-colors"
                      title="Eliminar archivo"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ) : (
                  <div className="text-[10px] text-gray-400 font-mono select-none">
                    Arrastra el archivo o haz clic abajo
                  </div>
                )}
              </div>

              <div className="pt-3 w-full flex flex-col gap-2">
                <input
                  ref={clientInputRef}
                  type="file"
                  accept=".csv"
                  onChange={(e) => {
                    if (e.target.files && e.target.files[0]) {
                      handleFileLoad(e.target.files[0], 'clientes');
                    }
                  }}
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => clientInputRef.current?.click()}
                  className="w-full py-1.5 border border-gray-200 hover:border-gray-300 text-[#1a1a1a] hover:bg-gray-100 font-bold text-[11px] rounded-none-none cursor-pointer transition-all shadow-3xs"
                >
                  Seleccionar CSV Clientes
                </button>

                <button
                  type="button"
                  onClick={() => handleLoadDemoCSV('clientes')}
                  className="text-[10px] text-gray-400 hover:text-gray-600 underline font-mono cursor-pointer bg-transparent border-none py-0.5"
                >
                  Probar con simulación de clientes crudo
                </button>
              </div>

            </div>

            {/* AREA 2: EQUIPO */}
            <div 
              onDragEnter={handleDragTeam}
              onDragOver={handleDragTeam}
              onDragLeave={handleDragTeam}
              onDrop={handleDropTeam}
              className={`border border-dashed rounded-none-none p-5 flex flex-col items-center justify-between min-h-[220px] text-center transition-all ${
                teamFile 
                  ? 'border-emerald-300 bg-emerald-50/10' 
                  : dragActiveTeam 
                    ? 'border-[#7A1626] bg-[#7A1626]/5' 
                    : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50/30'
              }`}
            >
              <div className="space-y-3 w-full">
                <div className={`p-2.5 mx-auto rounded-none-none w-fit ${teamFile ? 'bg-emerald-50 text-emerald-600' : 'bg-[#7A1626]/5 text-[#7A1626]'}`}>
                  <FileSpreadsheet className="w-6 h-6 stroke-[1.5]" />
                </div>
                
                <div className="space-y-1">
                  <h4 className="text-xs font-bold text-gray-900 font-display">Encuesta de Equipo (Cultura)</h4>
                  <p className="text-[11px] text-gray-400 max-w-[240px] mx-auto">
                    Arrastra aquí el CSV directo de Google Forms o selecciona el archivo.
                  </p>
                </div>

                {teamFile ? (
                  <div className="p-2 bg-emerald-50 border border-emerald-100 rounded-none-none text-left flex items-center justify-between gap-1.5">
                    <div className="truncate min-w-0">
                      <span className="block font-mono text-[9px] font-bold text-emerald-800 leading-none truncate">{teamFile.fileName}</span>
                      <span className="text-[10px] text-emerald-600 font-medium font-mono">{teamFile.rows.length} respuestas cargadas</span>
                    </div>
                    <button 
                      type="button" 
                      onClick={removeTeamFile}
                      className="p-1 hover:bg-emerald-100 text-emerald-700 hover:text-rose-600 rounded-none cursor-pointer transition-colors"
                      title="Eliminar archivo"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ) : (
                  <div className="text-[10px] text-gray-400 font-mono select-none">
                    Arrastra el archivo o haz clic abajo
                  </div>
                )}
              </div>

              <div className="pt-3 w-full flex flex-col gap-2">
                <input
                  ref={teamInputRef}
                  type="file"
                  accept=".csv"
                  onChange={(e) => {
                    if (e.target.files && e.target.files[0]) {
                      handleFileLoad(e.target.files[0], 'equipo');
                    }
                  }}
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => teamInputRef.current?.click()}
                  className="w-full py-1.5 border border-gray-200 hover:border-gray-300 text-[#1a1a1a] hover:bg-gray-100 font-bold text-[11px] rounded-none-none cursor-pointer transition-all shadow-3xs"
                >
                  Seleccionar CSV Equipo
                </button>

                <button
                  type="button"
                  onClick={() => handleLoadDemoCSV('equipo')}
                  className="text-[10px] text-gray-400 hover:text-gray-600 underline font-mono cursor-pointer bg-transparent border-none py-0.5"
                >
                  Probar con simulación de equipo crudo
                </button>
              </div>

            </div>

          </div>

          {/* Error display */}
          {errorMsg && (
            <div className="p-3 bg-rose-50 text-rose-800 border border-rose-100 rounded-none-none text-xs flex items-center space-x-2 font-medium">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* PARAMETERS ACTIONS BAR (Unified semester and proceed action) */}
          <div className="pt-4 border-t border-gray-100 flex flex-col sm:flex-row justify-between items-center bg-[#f5f5f5] -mx-6 -mb-6 p-5 gap-3 rounded-none-b-xl">
            <div className="flex items-center space-x-2">
              <span className="text-xs font-mono font-bold text-gray-600 uppercase">Semestre Destino:</span>
              <select
                value={inputSemester}
                onChange={(e) => setInputSemester(e.target.value)}
                className="text-xs font-mono font-bold border border-gray-300 rounded-none p-1.5 bg-white outline-none text-gray-800 focus:ring-1 focus:focus:ring-[#F9423A]/10"
              >
                <option value="2026-S1">2026 Semestre 1 (S1)</option>
                <option value="2026-S2">2026 Semestre 2 (S2)</option>
                <option value="2027-S1">2027 Semestre 1 (S1)</option>
                <option value="2027-S2">2027 Semestre 2 (S2)</option>
                <option value="2028-S1">2028 Semestre 1 (S1)</option>
                <option value="2028-S2">2028 Semestre 2 (S2)</option>
              </select>
            </div>

            <button
              type="button"
              disabled={!clientFile && !teamFile}
              onClick={handleProceed}
              className={`px-5 py-2.5 font-bold font-mono text-xs rounded-none-none flex items-center space-x-1.5 transition-all shadow-2xs ${
                (!clientFile && !teamFile) 
                  ? 'bg-gray-200 text-gray-400 cursor-not-allowed' 
                  : 'bg-[#F9423A] hover:bg-[#e0352e] text-white cursor-pointer'
              }`}
            >
              <span>Siguiente: Procesar Archivos</span>
              
            </button>
          </div>

        </div>
      )}

      {/* 2. MAPPING STEP */}
      {step === 'mapping' && (
        <div className="p-5 sm:p-6 space-y-5 bg-white animate-fadeIn" id="importer-step-mapping">
          <div>
            <span className="font-mono text-[9px] uppercase tracking-wider text-[#F9423A] font-bold bg-[#F9423A]/5 px-2 py-0.5 rounded-none">
              Paso de Red de Seguridad • Mapeo Manual Asistido
            </span>
            <h4 className="text-sm font-bold font-display text-gray-900 mt-1">
              Asignación manual de columnas no reconocidas para {inputSemester}
            </h4>
            <p className="text-xs text-gray-450 leading-relaxed max-w-2xl mt-1">
              Hemos emparejado automáticamente las columnas que coinciden con palabras clave. Por favor confirma o ajusta las columnas de las que no estábamos 100% seguros:
            </p>
          </div>

          <div className="space-y-6">
            {/* Clientes mapping block */}
            {clientFile && (
              <div className="border border-gray-100 rounded-none-none overflow-hidden shadow-3xs bg-white">
                <div className="px-4 py-2 bg-[#F9423A]/5 font-mono text-[10px] font-bold text-[#F9423A] border-b border-gray-105 flex justify-between items-center">
                  <span>Mapear Columnas de Clientes (Archivo: {clientFile.fileName})</span>
                  <span>Confianza: {Math.round(clientFile.confidence * 100)}%</span>
                </div>
                <div className="overflow-x-auto text-xs">
                  <table className="w-full text-left">
                    <thead>
                      <tr className="bg-[#f5f5f5] text-[9px] font-mono font-bold text-gray-400 border-b border-gray-100">
                        <th className="p-2">Columna en CSV</th>
                        <th className="p-2">Dato Muestra</th>
                        <th className="p-2">Indicador Asignado</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100 font-sans">
                      {clientFile.mappings.map(m => {
                        const sampleText = clientFile.rows[0]?.[m.csvHeader] || '(vacío)';
                        const shortSample = sampleText.length > 55 ? sampleText.substring(0, 52) + '...' : sampleText;
                        return (
                          <tr key={m.csvHeader} className="hover:bg-gray-50/50">
                            <td className="p-2 font-medium max-w-xs truncate" title={m.csvHeader}>{m.csvHeader}</td>
                            <td className="p-2 font-mono text-[10px] text-gray-400 capitalize">{shortSample}</td>
                            <td className="p-2">
                              <select
                                value={m.mappedKey}
                                onChange={(e) => handleColumnMapChange(m.csvHeader, e.target.value, 'clientes')}
                                className="w-full max-w-sm text-xs font-mono border rounded-none p-1 outline-none font-medium"
                              >
                                <option value="ignore">❌ Ignorar / No usar esta columna</option>
                                <option value="semestre">📆 Semestre / Periodo (Año-S1/S2)</option>
                                <option value="custom">✨ Pregunta adicional del cliente (Bloque personalizado)</option>
                                <optgroup label="Variables Clientes (Mercado)">
                                  {INDICATORS.filter(ind => ind.group === 'clientes').map(ind => (
                                    <option key={ind.key} value={ind.key}>{ind.isRequired ? '⭐️ ' : ''}{ind.label}</option>
                                  ))}
                                </optgroup>
                              </select>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Team mapping block */}
            {teamFile && (
              <div className="border border-gray-100 rounded-none-none overflow-hidden shadow-3xs bg-white">
                <div className="px-4 py-2 bg-[#7A1626]/5 font-mono text-[10px] font-bold text-[#7A1626] border-b border-gray-105 flex justify-between items-center">
                  <span>Mapear Columnas de Equipo Interno (Archivo: {teamFile.fileName})</span>
                  <span>Confianza: {Math.round(teamFile.confidence * 100)}%</span>
                </div>
                <div className="overflow-x-auto text-xs">
                  <table className="w-full text-left">
                    <thead>
                      <tr className="bg-[#f5f5f5] text-[9px] font-mono font-bold text-gray-400 border-b border-gray-100">
                        <th className="p-2">Columna en CSV</th>
                        <th className="p-2">Dato Muestra</th>
                        <th className="p-2">Indicador Asignado</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100 font-sans">
                      {teamFile.mappings.map(m => {
                        const sampleText = teamFile.rows[0]?.[m.csvHeader] || '(vacío)';
                        const shortSample = sampleText.length > 55 ? sampleText.substring(0, 52) + '...' : sampleText;
                        return (
                          <tr key={m.csvHeader} className="hover:bg-gray-50/50">
                            <td className="p-2 font-medium max-w-xs truncate" title={m.csvHeader}>{m.csvHeader}</td>
                            <td className="p-2 font-mono text-[10px] text-gray-400 capitalize">{shortSample}</td>
                            <td className="p-2">
                              <select
                                value={m.mappedKey}
                                onChange={(e) => handleColumnMapChange(m.csvHeader, e.target.value, 'equipo')}
                                className="w-full max-w-sm text-xs font-mono border rounded-none p-1 outline-none font-medium"
                              >
                                <option value="ignore">❌ Ignorar / No usar esta columna</option>
                                <option value="semestre">📆 Semestre / Periodo (Año-S1/S2)</option>
                                <option value="custom">✨ Pregunta adicional del cliente (Bloque personalizado)</option>
                                <optgroup label="Variables Equipo (Cultura)">
                                  {INDICATORS.filter(ind => ind.group === 'equipo').map(ind => (
                                    <option key={ind.key} value={ind.key}>{ind.isRequired ? '⭐️ ' : ''}{ind.label}</option>
                                  ))}
                                </optgroup>
                              </select>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>

          <div className="flex justify-between items-center pt-2 gap-3 border-t border-gray-100">
            <button
              type="button"
              onClick={() => {
                setStep('uploading');
                setErrorMsg(null);
              }}
              className="px-4 py-2 text-xs font-bold font-mono text-gray-500 hover:text-gray-850 bg-white border border-gray-200 hover:bg-gray-50 rounded-none-none cursor-pointer transition-colors"
            >
              Atrás / Cambiar archivos
            </button>

            <button
              type="button"
              onClick={() => setStep('preview')}
              className="px-5 py-2.5 bg-[#1a1a1a] hover:bg-black text-white font-bold text-xs rounded-none-none cursor-pointer transition-colors flex items-center space-x-1.5"
            >
              <span>Siguiente: Ver Resumen de Entrada</span>
              
            </button>
          </div>

        </div>
      )}

      {/* 3. PREVIEW STEP */}
      {step === 'preview' && (
        <div className="p-6 bg-[#f5f5f5] space-y-4 animate-fadeIn text-center" id="importer-step-preview">
          
          <div className="inline-flex p-4 bg-emerald-50 rounded-none-none text-emerald-600 mx-auto">
            <CheckCircle2 className="w-8 h-8 stroke-[1.5]" />
          </div>

          <div className="space-y-1 max-w-md mx-auto">
            <h4 className="text-base font-extrabold font-display text-gray-900">
              Vista previa de la importación
            </h4>
            <p className="text-xs text-gray-400">
              Hemos leído el archivo y ya está estructurado. ¿Confirmas añadirlo al histórico del Cuadro de Mando Comuniza?
            </p>
          </div>

          {/* Core confirmation statistics box */}
          <div className="bg-white border border-[#E5E5E0] rounded-none-none p-5 text-left max-w-xl mx-auto space-y-3.5 shadow-2xs">
            <span className="text-[10px] font-mono text-[#F9423A] uppercase tracking-wide block font-bold leading-none border-b border-gray-50 pb-2">
              Resumen de registros detectados
            </span>
            
            <div className="space-y-2.5 divide-y divide-gray-50 text-xs">
              <div className="flex justify-between items-center py-1 font-mono">
                <span className="text-gray-500 font-bold">SEMESTRE DESTINO:</span>
                <span className="font-bold text-gray-950 font-display bg-gray-100 px-2 py-0.5 rounded-none text-xs select-all">
                  {inputSemester.toUpperCase()}
                </span>
              </div>

              {clientFile && (
                <div className="flex justify-between items-start pt-2">
                  <div className="space-y-0.5">
                    <span className="font-bold text-gray-800 block">✓ Respuestas de Clientes (Mercado)</span>
                    <span className="text-[10px] font-mono text-gray-400 block">{clientFile.fileName}</span>
                  </div>
                  <span className="text-xs font-mono font-bold bg-[#F9423A]/5 text-[#F9423A] px-2 py-0.5 rounded-none">
                    {clientFile.rows.length} respuestas
                  </span>
                </div>
              )}

              {teamFile && (
                <div className="flex justify-between items-start pt-2">
                  <div className="space-y-0.5">
                    <span className="font-bold text-gray-800 block">✓ Respuestas de Equipo (Cultura)</span>
                    <span className="text-[10px] font-mono text-gray-400 block">{teamFile.fileName}</span>
                  </div>
                  <span className="text-xs font-mono font-bold bg-[#7A1626]/5 text-[#7A1626] px-2 py-0.5 rounded-none">
                    {teamFile.rows.length} respuestas
                  </span>
                </div>
              )}
            </div>

            {(() => {
              const matchesS = semesters.find(s => s.periodo === inputSemester || s.id === inputSemester.toUpperCase());
              if (matchesS) {
                return (
                  <div className="p-2.5 bg-amber-50 text-amber-900 border border-amber-200 rounded-none text-[11px] font-sans leading-relaxed">
                    ℹ️ <strong>Nota histórica importante:</strong> El semestre {inputSemester.toUpperCase()} ya contenía registros previos de marcas. Al confirmar, unificaremos la información y fusionaremos los datos del mercado con los de cultura sin borrar los indicadores anteriores.
                  </div>
                );
              }
              return null;
            })()}

            {(() => {
              const clientCustomCount = clientFile?.mappings.filter(m => m.mappedKey === 'custom').length || 0;
              const teamCustomCount = teamFile?.mappings.filter(m => m.mappedKey === 'custom').length || 0;
              
              if (clientCustomCount > 0 || teamCustomCount > 0) {
                return (
                  <div className="p-3 bg-indigo-50 text-indigo-900 border border-indigo-200 rounded-none text-[11.5px] font-sans leading-relaxed text-left flex items-start gap-2">
                    <Info className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
                    <div>
                      <strong>Preguntas adicionales detectadas:</strong> Se han identificado {clientCustomCount > 0 ? `${clientCustomCount} en el CSV de Clientes` : ''} {clientCustomCount > 0 && teamCustomCount > 0 ? 'y' : ''} {teamCustomCount > 0 ? `${teamCustomCount} en el CSV de Equipo` : ''} que se guardarán en un bloque independiente sin alterar tus 4 indicadores principales.
                    </div>
                  </div>
                );
              }
              return null;
            })()}

          </div>

          <div className="flex justify-center items-center space-x-3.5 pt-4">
            <button
              type="button"
              onClick={() => {
                setStep('uploading');
              }}
              className="px-4 py-2.5 text-xs font-bold font-mono text-gray-500 hover:text-gray-800 bg-white border border-gray-200 hover:bg-gray-50 rounded-none-none cursor-pointer transition-colors"
            >
              Cancelar Carga
            </button>

            <button
              type="button"
              onClick={handleConfirmImport}
              className="px-6 py-2.5 bg-[#F9423A] hover:bg-[#e0352e] text-white font-bold text-xs rounded-none-none cursor-pointer transition-all shadow-xs flex items-center space-x-1.5"
            >
              <span>✓ Añadir al histórico</span>
            </button>
          </div>

        </div>
      )}

    </div>
  );
};
