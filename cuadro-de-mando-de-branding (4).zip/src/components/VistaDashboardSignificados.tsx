import React, { useState, useRef } from 'react';
import { 
  FileSpreadsheet, 
  Download, 
  Upload,
  Sliders,
  TrendingUp, 
  TrendingDown, 
  Minus, 
  HelpCircle, 
  AlertTriangle, 
  Edit3, 
  FileCheck, 
  Sparkles,
  Clipboard,
  Trash2,
  Calendar,
  Lock,
  Unlock,
  CheckCircle,
  Users,
  Briefcase,
  Layers,
  ArrowRightLeft,
  ArrowRight
} from 'lucide-react';
import { SemesterData, Prescription, PlaceholderConfig } from '../types';
import { IntelligentCSVImporter } from './IntelligentCSVImporter';
import { 
  calcularSignificadoScore, 
  calcularFortalezaScore, 
  calcularAlineamientoDashboard, 
  calcularImplantacionScore,
  calcularApropiacionScore
} from '../data';
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';

// Resilient Inline SVG evolution line chart for robust PDF export rendering
const EvolutionLineChart: React.FC<{
  data: number[];
  labels: string[];
  activeIndex: number;
  maxVal: number;
  color?: string;
  isPercentage?: boolean;
}> = ({ data, labels, activeIndex, maxVal, color = '#F9423A', isPercentage = false }) => {
  const width = 360;
  const height = 100;
  const paddingX = 20;
  const paddingY = 15;

  if (data.length < 2) {
    return <div className="text-[11px] font-mono text-gray-400">Datos insuficientes para series temporales</div>;
  }

  // Map to SVG coordinates
  const points = data.map((val, idx) => {
    const x = paddingX + (idx / (data.length - 1)) * (width - (paddingX * 2));
    const y = (height - paddingY) - (val / maxVal) * (height - (paddingY * 2));
    return { x, y, val };
  });

  const pathD = points
    .map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x.toFixed(1)} ${p.y.toFixed(1)}`)
    .join(' ');

  const areaD = `${pathD} L ${points[points.length - 1].x.toFixed(1)} ${height - paddingY} L ${points[0].x.toFixed(1)} ${height - paddingY} Z`;

  return (
    <div className="space-y-1">
      <svg width="100%" height={height} viewBox={`0 0 ${width} ${height}`} className="overflow-visible select-none">
        {/* Subtle grid lines */}
        <line x1={paddingX} y1={height - paddingY} x2={width - paddingX} y2={height - paddingY} stroke="#E5E5E0" strokeWidth="1" strokeDasharray="2 2" />
        <line x1={paddingX} y1={paddingY} x2={width - paddingX} y2={paddingY} stroke="#E5E5E0" strokeWidth="1" strokeDasharray="2 2" />

        {/* Shaded Area */}
        <path d={areaD} fill={color} opacity="0.04" stroke="none" />

        {/* Connection line */}
        <path
          d={pathD}
          fill="none"
          stroke={color}
          strokeWidth="2.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />

        {/* Data points */}
        {points.map((p, i) => {
          const isActive = i === activeIndex;
          return (
            <g key={i}>
              <circle
                cx={p.x}
                cy={p.y}
                r={isActive ? 5 : 3}
                fill={isActive ? '#1a1a1a' : color}
                stroke={isActive ? '#FFFFFF' : 'none'}
                strokeWidth={isActive ? 1.5 : 0}
                className="transition-all"
              />
              {/* Point Label */}
              <text
                x={p.x}
                y={p.y - 8}
                textAnchor="middle"
                className="font-mono text-[9px] font-bold"
                fill={isActive ? '#1a1a1a' : '#777777'}
              >
                {p.val}{isPercentage ? '%' : ''}
              </text>
              {/* Bottom Label */}
              <text
                x={p.x}
                y={height - 2}
                textAnchor="middle"
                className="font-mono text-[8px] text-gray-400 font-bold"
              >
                {labels[i]}
              </text>
            </g>
          );
        })}
      </svg>
    </div>
  );
};

interface VistaDashboardSignificadosProps {
  semesters: SemesterData[];
  setSemesters: React.Dispatch<React.SetStateAction<SemesterData[]>>;
  selectedSemesterId: string;
  setSelectedSemesterId: (id: string) => void;
  prescriptions: Prescription[];
  setPrescriptions: React.Dispatch<React.SetStateAction<Prescription[]>>;
  config: PlaceholderConfig;
  setConfig: (config: PlaceholderConfig) => void;
  perfilAcceso: 'consultor' | 'marca';
  setPerfilAcceso: (perfil: 'consultor' | 'marca') => void;
}

export const VistaDashboardSignificados: React.FC<VistaDashboardSignificadosProps> = ({
  semesters,
  setSemesters,
  selectedSemesterId,
  setSelectedSemesterId,
  prescriptions,
  setPrescriptions,
  config,
  setConfig,
  perfilAcceso,
  setPerfilAcceso
}) => {
  const [showCsvBox, setShowCsvBox] = useState(false);
  const [csvFeedback, setCsvFeedback] = useState<{ success: boolean; msg: string } | null>(null);
  const [isExporting, setIsExporting] = useState(false);
  const [editingPrescriptionId, setEditingPrescriptionId] = useState<string | null>(null);

  const dashboardPrintRef = useRef<HTMLDivElement>(null);

  // Active semester calculation
  const activeIndex = semesters.findIndex(s => s.id === selectedSemesterId);
  const activeSemester = semesters[activeIndex] || (semesters.length > 0 ? semesters[semesters.length - 1] : null);

  // Helper values for comparisons
  const prevSemester = activeSemester && activeIndex > 0 ? semesters[activeIndex - 1] : null;

  // Determine active mode based on available data
  const hasClientes = activeSemester && activeSemester.clienteNumRespuestas > 0;
  const hasEquipo = activeSemester && activeSemester.empleadoNumRespuestas > 0;

  let mode: 'A' | 'B' | 'C' | 'EMPTY' = 'EMPTY';
  if (hasClientes && hasEquipo) {
    mode = 'C';
  } else if (hasClientes) {
    mode = 'A';
  } else if (hasEquipo) {
    mode = 'B';
  }

  // Compute indices safely
  const activeSignificado = activeSemester ? calcularSignificadoScore(activeSemester) : 0;
  const activeFortaleza = activeSemester ? calcularFortalezaScore(activeSemester) : 0;

  const alignCliente = activeSemester ? calcularApropiacionScore(activeSemester.apropiacionA4) : 0;
  const alignInterno = activeSemester ? calcularApropiacionScore(activeSemester.apropiacionB2) : 0;
  const alignGap = activeSemester ? (alignInterno - alignCliente) : 0;

  let activeAlineamiento = 0;
  if (activeSemester) {
    if (mode === 'C') {
      activeAlineamiento = calcularAlineamientoDashboard(activeSemester).score;
    } else if (mode === 'A') {
      activeAlineamiento = alignCliente;
    } else if (mode === 'B') {
      activeAlineamiento = alignInterno;
    }
  }

  const activeImplantacion = activeSemester ? calcularImplantacionScore(activeSemester) : 0;

  // Compute indices for previous period safely
  const prevSignificado = prevSemester ? calcularSignificadoScore(prevSemester) : null;
  const prevFortaleza = prevSemester ? calcularFortalezaScore(prevSemester) : null;

  let prevAlineamiento: number | null = null;
  if (prevSemester) {
    const prevHasClientes = prevSemester.clienteNumRespuestas > 0;
    const prevHasEquipo = prevSemester.empleadoNumRespuestas > 0;
    if (prevHasClientes && prevHasEquipo) {
      prevAlineamiento = calcularAlineamientoDashboard(prevSemester).score;
    } else if (prevHasClientes) {
      prevAlineamiento = calcularApropiacionScore(prevSemester.apropiacionA4);
    } else if (prevHasEquipo) {
      prevAlineamiento = calcularApropiacionScore(prevSemester.apropiacionB2);
    }
  }

  const prevImplantacion = prevSemester ? calcularImplantacionScore(prevSemester) : null;

  // Trend percentages safely
  const deltaSignificado = prevSignificado !== null ? activeSignificado - prevSignificado : 0;
  const deltaFortaleza = prevFortaleza !== null ? activeFortaleza - prevFortaleza : 0;
  const deltaAlineamiento = prevAlineamiento !== null ? activeAlineamiento - prevAlineamiento : 0;
  const deltaImplantacion = prevImplantacion !== null ? activeImplantacion - prevImplantacion : 0;

  // Handlers for edit prescriptions
  const handleEditPrescription = (id: string, text: string) => {
    setPrescriptions(prev => prev.map(p => p.id === id ? { ...p, text } : p));
  };

  // Mock template simulators for easy execution
  const simulateNewPeriod = () => {
    // Generate S1-2027 based on 2026-S2 with slight random variations
    const newId = 'S1-2027';
    if (semesters.some(s => s.id === newId)) {
      alert('La simulación S1-2027 ya se encuentra cargada en la sesión.');
      return;
    }

    const newSemester: SemesterData = {
      id: newId,
      periodo: '2027-S1',
      clienteNumRespuestas: 195,
      palabrasA1: [
        { text: 'Líder', value: 62 },
        { text: 'Innovador', value: 58 },
        { text: 'Prestigioso', value: 49 },
        { text: 'Humano', value: 45 },
        { text: 'Cercano', value: 38 },
        { text: 'Confiable', value: 36 },
        { text: 'Económico', value: 12 },
        { text: 'Sencillo', value: 34 }
      ],
      fortalezasA2: {
        'Propuesta de valor': 41,
        'Calidad de productos o servicios': 25,
        'Experiencia de cliente': 22,
        'Credibilidad y confianza': 10,
        'Innovación': 24,
        'Cercanía': 15,
        'Liderazgo en su categoría': 12,
        'Impacto o contribución': 8,
        'Otro': 0
      },
      acuerdoA3: {
        propuesta_clara: 8.8,
        relevancia_publicos: 8.4,
        diferenciacion_alternativas: 8.1,
        genera_confianza: 8.6,
        proyecta_coherencia: 8.3,
        evolucion_adecuada: 8.9
      },
      apropiacionA4: {
        no_la_entiendo: 3,
        no_relaciono: 8,
        relaciono_parcialmente: 10,
        relaciono_claramente: 44,
        relaciono_y_diferencial: 35
      },
      personalidadA5: {
        'Cercana': 41,
        'Innovadora': 48,
        'Fiable': 42,
        'Inspiradora': 39,
        'Experta': 43,
        'Dinámica': 36,
        'Transparente': 31,
        'Ambiciosa': 20,
        'Humana': 34,
        'Comprometida': 35
      },
      retosA6: {
        'Claridad del posicionamiento': 5,
        'Diferenciación': 8,
        'Comunicación': 12,
        'Experiencia de cliente': 25,
        'Coherencia entre canales': 10,
        'Innovación': 15,
        'Cultura interna': 6,
        'Activación comercial': 4
      },
      clustersA7: [
        { name: 'Consolidación plena del valor Premium con excelente asimilación', percentage: 60 },
        { name: 'Petición de optimizar las herramientas colaborativas de autoservicio', percentage: 25 },
        { name: 'Deseo de mayor impacto en comunicación verde/social', percentage: 15 }
      ],

      empleadoNumRespuestas: 140,
      acuerdoB1: {
        entiendo_posicionamiento: 9.3,
        se_aplicar_marca: 8.8,
        recursos_suficientes: 8.3,
        mejores_decisiones: 8.5,
        coherencia_promesa: 8.6
      },
      apropiacionB2: {
        no_la_entiendo: 1,
        no_relaciono: 2,
        relaciono_parcialmente: 8,
        relaciono_claramente: 44,
        relaciono_y_diferencial: 45
      },
      barrerasB3: {
        'Falta de claridad': 1,
        'Falta de herramientas o plantillas': 7,
        'Falta de formación': 5,
        'Incoherencias entre áreas': 15,
        'Falta de tiempo': 33,
        'Resistencia al cambio': 3,
        'Otro': 36
      },
      clustersB4: [
        { name: 'Orgullo de marca total con foco en escalabilidad y tiempo de entrega', percentage: 55 },
        { name: 'Coordinación entre áreas para evitar duplicidades en proyectos', percentage: 30 },
        { name: 'Demanda de manuales de acogida para nuevos colaboradores', percentage: 15 }
      ]
    };

    setSemesters(prev => [...prev, newSemester]);
    setSelectedSemesterId(newId);
    alert('Simulación cargada con éxito. Se ha sumado el semestre "2027-S1". Puedes visualizar el narrowing del GAP!');
  };

  // Copia de seguridad en JSON
  const handleDownloadBackup = () => {
    try {
      const dataPayload = {
        app: 'comuniza-brand-tracker',
        exportedAt: new Date().toISOString(),
        config,
        semesters,
        prescriptions
      };
      
      const blob = new Blob([JSON.stringify(dataPayload, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `Copia_Seguridad_Comuniza_${config.marca.replace(/\s+/g, '_')}_${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      alert('¡Copia de seguridad (.json) descargada a tu ordenador! Guárdala bien.');
    } catch (err) {
      alert('Error al exportar la copia de seguridad.');
    }
  };

  const handleUploadBackup = (event: React.ChangeEvent<HTMLInputElement>) => {
    const fileReader = new FileReader();
    const files = event.target.files;
    if (!files || files.length === 0) return;

    fileReader.onload = (e) => {
      try {
        const text = e.target?.result as string;
        const parsed = JSON.parse(text);
        
        if (parsed.semesters && parsed.config) {
          setSemesters(parsed.semesters);
          setConfig(parsed.config);
          if (parsed.prescriptions) {
            setPrescriptions(parsed.prescriptions);
          }
          alert('¡Éxito! Copia de seguridad oficial cargada. El histórico y la configuración de marca han sido actualizados.');
        } else {
          alert('Este archivo JSON no parece ser una copia de seguridad válida de esta aplicación.');
        }
      } catch (err) {
        alert('Formato de archivo inválido.');
      }
    };
    fileReader.readAsText(files[0]);
  };

  // EXPORT PROCESS (PNG/PDF)
  const runExport = async (format: 'png' | 'pdf') => {
    if (!dashboardPrintRef.current) return;
    setIsExporting(true);
    
    // Smart converter helper to prevent html2canvas crashing on v4 oklch() colors
    const approximateOklchToRgb = (oklchStr: string): string => {
      try {
        const match = oklchStr.match(/oklch\s*\(\s*([0-9.]+)\s+([0-9.]+)\s+([0-9.]+)(?:\s*\/\s*([0-9.%]+))?\s*\)/i);
        if (!match) return '#888888';
        
        const L = parseFloat(match[1]);
        const C = parseFloat(match[2]);
        const H = parseFloat(match[3]);
        let alpha = 1;
        if (match[4]) {
          const alphaStr = match[4].trim();
          if (alphaStr.endsWith('%')) {
            alpha = parseFloat(alphaStr) / 100;
          } else {
            alpha = parseFloat(alphaStr);
          }
        }
        
        const clamp = (val: number) => Math.max(0, Math.min(255, Math.round(val)));
        
        if (C < 0.04) {
          const v = clamp(L * 255);
          return `rgba(${v}, ${v}, ${v}, ${alpha})`;
        }
        
        let r = 128, g = 128, b = 128;
        if (H >= 340 || H < 45) {
          r = L * 255 + (1 - L) * 255 * C * 2;
          g = L * 255 - L * 255 * C * 1.5;
          b = L * 255 - L * 255 * C * 1.5;
        } else if (H >= 45 && H < 90) {
          r = L * 255 + (1 - L) * 200 * C;
          g = L * 255 + (1 - L) * 150 * C;
          b = L * 255 - L * 255 * C * 2;
        } else if (H >= 90 && H < 165) {
          r = L * 255 - L * 255 * C * 1.5;
          g = L * 255 + (1 - L) * 200 * C * 2;
          b = L * 255 - L * 255 * C * 1.5;
        } else if (H >= 165 && H < 265) {
          r = L * 255 - L * 255 * C * 1.5;
          g = L * 255 - L * 255 * C * 0.5;
          b = L * 255 + (1 - L) * 255 * C * 2;
        } else if (H >= 265 && H < 340) {
          r = L * 255 + (1 - L) * 150 * C;
          g = L * 255 - L * 150 * C;
          b = L * 255 + (1 - L) * 150 * C;
        }
        
        return `rgba(${clamp(r)}, ${clamp(g)}, ${clamp(b)}, ${alpha})`;
      } catch (err) {
        return '#888888';
      }
    };

    // Tiny delay to ensure UI states are finished
    setTimeout(async () => {
      try {
        const element = dashboardPrintRef.current;
        if (element) {
          element.classList.add('exporting');
        }
        const canvas = await html2canvas(element!, {
          scale: 2, // high res 2x
          useCORS: true,
          logging: false,
          ignoreElements: (el) => {
            // Hide buttons, selectors, forms during print
            return el.id === 'dashboard-period-selector-panel' || 
                   el.id === 'diccionario-prescripciones-edicion' || 
                   el.classList.contains('hide-during-print');
          },
          onclone: (clonedDoc) => {
            try {
              // Sanitize standard <style> blocks
              const styleTags = Array.from(clonedDoc.getElementsByTagName('style'));
              styleTags.forEach(styleTag => {
                if (styleTag.innerHTML && styleTag.innerHTML.includes('oklch')) {
                  styleTag.innerHTML = styleTag.innerHTML.replace(/oklch\s*\([^)]+\)/gi, (m) => approximateOklchToRgb(m));
                }
              });

              // Sanitize linked and dynamic style sheets
              const sheets = Array.from(clonedDoc.styleSheets);
              const sanitizedStyleTag = clonedDoc.createElement('style');
              let concatenatedCSS = '';

              sheets.forEach((sheet) => {
                try {
                  const rules = sheet.cssRules || sheet.rules;
                  if (!rules) return;
                  for (let i = 0; i < rules.length; i++) {
                    concatenatedCSS += rules[i].cssText + '\n';
                  }
                  // Disable the original sheet so html2canvas doesn't re-parse it
                  (sheet as any).disabled = true;
                } catch (e) {
                  // Ignore CORS errors for external CDN stylesheets
                }
              });

              if (concatenatedCSS) {
                const sanitizedCSS = concatenatedCSS.replace(/oklch\s*\([^)]+\)/gi, (m) => approximateOklchToRgb(m));
                sanitizedStyleTag.innerHTML = sanitizedCSS;
                clonedDoc.head.appendChild(sanitizedStyleTag);
              }

              // Also sanitize any inline oklch helper styles on elements
              const allElements = Array.from(clonedDoc.getElementsByTagName('*'));
              allElements.forEach((el: any) => {
                if (el.style) {
                  ['color', 'backgroundColor', 'borderColor', 'background', 'border'].forEach((prop) => {
                    const val = el.style[prop];
                    if (val && val.toLowerCase().includes('oklch')) {
                      el.style[prop] = val.replace(/oklch\s*\([^)]+\)/gi, (m: string) => approximateOklchToRgb(m));
                    }
                  });
                }
              });
            } catch (styleErr) {
              console.warn("Could not fully rewrite oklch colors for export, proceeding anyway:", styleErr);
            }
          }
        });

        if (element) {
          element.classList.remove('exporting');
        }

        const imgData = canvas.toDataURL('image/png');

        if (format === 'png') {
          const link = document.createElement('a');
          link.download = `comuniza-dashboard-${config.marca}-${activeSemester.periodo}.png`;
          link.href = imgData;
          link.click();
        } else {
          // PDF Landscape 16:9 aspect ratio standard template
          const pdf = new jsPDF('landscape', 'mm', 'a4');
          const pdfWidth = pdf.internal.pageSize.getWidth();
          const pdfHeight = pdf.internal.pageSize.getHeight();
          
          // Calculate bounding box keeping proportions
          const imgWidth = canvas.width;
          const imgHeight = canvas.height;
          const ratio = Math.min(pdfWidth / imgWidth, pdfHeight / imgHeight);
          
          const finalW = imgWidth * ratio;
          const finalH = imgHeight * ratio;
          
          const x = (pdfWidth - finalW) / 2;
          const y = (pdfHeight - finalH) / 2;

          pdf.addImage(imgData, 'PNG', x, y, finalW, finalH);
          pdf.save(`comuniza-dashboard-${config.marca}-${activeSemester.periodo}.pdf`);
        }
      } catch (err) {
        console.error(err);
        alert('Ocurrió un error al preparar la exportación.');
      } finally {
        setIsExporting(false);
      }
    }, 200);
  };

  // Callback on successful active file drop/load within dashboard
  const handleCSVImportComplete = (nuevoSemestre: SemesterData, feedbackMessage: string) => {
    setSemesters(prev => {
      const filtered = prev.filter(s => s.id !== nuevoSemestre.id);
      return [...filtered, nuevoSemestre];
    });
    setSelectedSemesterId(nuevoSemestre.id);
    setCsvFeedback({ success: true, msg: feedbackMessage });
    
    setTimeout(() => {
      setCsvFeedback(null);
    }, 5000);
  };

  // Check which indicators are dropping below their previous period score to trigger automatic prescriptive alerts
  const prescriptionsToTrigger: { id: string; name: string; text: string; activeVal: number; prevVal: number }[] = [];
  
  if (prevSemester && mode !== 'EMPTY') {
    if ((mode === 'A' || mode === 'C') && deltaSignificado < 0 && prevSignificado !== null) {
      const p = prescriptions.find(x => x.id === 'significado');
      if (p) prescriptionsToTrigger.push({ ...p, activeVal: activeSignificado, prevVal: prevSignificado });
    }
    if ((mode === 'A' || mode === 'C') && deltaFortaleza < 0 && prevFortaleza !== null) {
      const p = prescriptions.find(x => x.id === 'fortaleza');
      if (p) prescriptionsToTrigger.push({ ...p, activeVal: activeFortaleza, prevVal: prevFortaleza });
    }
    if (deltaAlineamiento < 0 && prevAlineamiento !== null) {
      const p = prescriptions.find(x => x.id === 'alineamiento');
      if (p) prescriptionsToTrigger.push({ ...p, activeVal: activeAlineamiento, prevVal: prevAlineamiento });
    }
    if ((mode === 'B' || mode === 'C') && deltaImplantacion < 0 && prevImplantacion !== null) {
      const p = prescriptions.find(x => x.id === 'implantacion');
      if (p) prescriptionsToTrigger.push({ ...p, activeVal: activeImplantacion, prevVal: prevImplantacion });
    }
  }

  return (
    <div className="space-y-6" id="dashboard-meaning-container">
      
      {/* SECTION A: UPPER CONTROLS & CSV IMPORT HUB */}
      <div className="p-4 bg-white border border-[#E5E5E0] rounded-none-none space-y-4" id="dashboard-period-selector-panel">
        
        {/* UPPER ROW: PERIOD SELECTION & ACCESS PROFILE */}
        <div className="flex flex-col xl:flex-row justify-between items-start xl:items-center gap-4 pb-3 border-b border-gray-100">
          
          {/* Semester select buttons */}
          <div className="space-y-1">
            <label className="block text-[10px] font-mono font-bold text-gray-400 uppercase tracking-widest">
              Selección de Periodo / Cohorte Semestral
            </label>
            <div className="flex flex-wrap gap-1.5" id="grup-botones-semestres">
              {semesters.map((s) => {
                const active = s.id === selectedSemesterId;
                return (
                  <button
                    key={s.id}
                    type="button"
                    onClick={() => setSelectedSemesterId(s.id)}
                    className={`px-3 py-1.5 text-xs font-mono font-bold rounded-none transition-all cursor-pointer whitespace-nowrap ${
                      active
                        ? 'bg-[#F9423A] text-white shadow-xs'
                        : 'bg-[#f5f5f5] text-gray-600 border border-[#E5E5E0] hover:text-gray-900 hover:bg-gray-100'
                    }`}
                  >
                    {s.periodo}
                    <span className="text-[9px] opacity-65 ml-1.5 font-normal">
                      (C: {s.clienteNumRespuestas} | E: {s.empleadoNumRespuestas})
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Profile access toggle switcher */}
          <div className="space-y-1">
            <label className="block text-[10px] font-mono font-bold text-[#F9423A]/90 uppercase tracking-widest">
              Perfil de Acceso / Simulación
            </label>
            <div className="flex border border-[#E5E5E0] rounded-none bg-gray-50 p-0.5" id="perfil-de-acceso-buttons">
              <button
                type="button"
                onClick={() => setPerfilAcceso('consultor')}
                className={`flex items-center space-x-1.5 px-3 py-1 text-xs font-mono font-bold rounded-none transition-colors cursor-pointer whitespace-nowrap ${
                  perfilAcceso === 'consultor'
                    ? 'bg-[#1a1a1a] text-white'
                    : 'text-gray-500 hover:text-gray-850'
                }`}
              >
                <Unlock className="w-3 h-3 text-white/70" />
                <span>Consultor (Comuniza)</span>
              </button>
              <button
                type="button"
                onClick={() => setPerfilAcceso('marca')}
                className={`flex items-center space-x-1.5 px-3 py-1 text-xs font-mono font-bold rounded-none transition-colors cursor-pointer whitespace-nowrap ${
                  perfilAcceso === 'marca'
                    ? 'bg-[#1a1a1a] text-white'
                    : 'text-gray-500 hover:text-gray-850'
                }`}
              >
                <Lock className="w-3 h-3 text-[#F9423A]" />
                <span>Marca Evaluada</span>
              </button>
            </div>
          </div>

        </div>

        {/* LOWER ROW: OPERATIONS TOOLBAR */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-3">
          
          <div className="flex items-center space-x-1.5 text-[10px] text-gray-400 font-mono">
            <Sliders className="w-3.5 h-3.5 text-[#F9423A]" />
            <span className="font-bold uppercase tracking-wider">Operaciones de Base de Datos y Simulación</span>
          </div>

          {/* Action Panel Utilities */}
          <div className="flex flex-wrap items-center gap-2 font-mono">
            <button
              type="button"
              onClick={() => setShowCsvBox(!showCsvBox)}
              className="flex items-center space-x-1.5 px-3 py-1.5 bg-[#F9423A]/10 hover:bg-[#F9423A]/20 text-[#F9423A] border border-[#F9423A]/25 rounded-none text-xs font-bold transition-all cursor-pointer whitespace-nowrap"
              id="btn-upload-double-csv"
              title="Importar CSV de encuestas"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span>Cargar CSV Siguiente</span>
            </button>
            
            <button
              type="button"
              onClick={simulateNewPeriod}
              className="flex items-center space-x-1.5 px-3 py-1.5 bg-gray-100 hover:bg-gray-200 text-gray-700 border border-gray-300 rounded-none text-xs font-bold transition-all cursor-pointer whitespace-nowrap"
              title="Cargar automáticamente el siguiente semestre"
            >
              <Sparkles className="w-3.5 h-3.5 text-[#F9423A]" />
              <span>Simular Semestre</span>
            </button>

            <div className="hidden sm:block h-6 w-px bg-gray-200 mx-1" />

            <button
              type="button"
              onClick={handleDownloadBackup}
              className="flex items-center space-x-1.5 px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-250 rounded-none text-xs font-bold transition-all cursor-pointer whitespace-nowrap"
              title="Guardar archivo .json con todo tu histórico y configuración"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Guardar Copia (.json)</span>
            </button>

            <label 
              className="flex items-center space-x-1.5 px-3 py-1.5 bg-white hover:bg-gray-50 text-gray-700 border border-gray-350 rounded-none text-xs font-bold transition-all cursor-pointer whitespace-nowrap"
              title="Restaurar toda tu información desde un archivo .json local"
            >
              <Upload className="w-3.5 h-3.5" />
              <span>Restaurar Copia</span>
              <input
                type="file"
                accept=".json"
                onChange={handleUploadBackup}
                className="hidden"
              />
            </label>
          </div>

        </div>

        {/* Suggestion alert for adding the other audience */}
        {mode === 'A' && (
          <div className="p-3 bg-amber-50/50 border border-amber-200 rounded-none-none flex items-start gap-2.5 text-xs text-amber-800 font-sans hide-during-print fade-in">
            <Sparkles className="w-4 h-4 text-amber-500 mt-0.5 shrink-0" />
            <p>
              <strong>Sugerencia de marca:</strong> Se están visualizando solo datos de <strong>Clientes</strong>. Añade el cuestionario de <strong>Equipo</strong> para analizar la cultura interna y comparar ambas miradas en el <strong>Gap de Alineamiento</strong>.
            </p>
          </div>
        )}
        {mode === 'B' && (
          <div className="p-3 bg-amber-50/50 border border-amber-200 rounded-none-none flex items-start gap-2.5 text-xs text-amber-800 font-sans hide-during-print fade-in">
            <Sparkles className="w-4 h-4 text-amber-500 mt-0.5 shrink-0" />
            <p>
              <strong>Sugerencia de marca:</strong> Se están visualizando solo datos de <strong>Equipo</strong>. Añade el cuestionario de <strong>Clientes</strong> para analizar la percepción de mercado y comparar ambas miradas en el <strong>Gap de Alineamiento</strong>.
            </p>
          </div>
        )}

      </div>

      {/* CSV BOX LOADER DROPDOWN CONTENT */}
      {showCsvBox && (
        <div className="bg-white border border-[#E5E5E0] rounded-none-none p-5 space-y-4 hide-during-print fade-in" id="double-csv-importer-box">
          <div className="flex justify-between items-start border-b border-gray-100 pb-3">
            <div>
              <h4 className="text-sm font-bold text-[#1a1a1a] font-display">Carga inteligente de datos semestrales (CSV)</h4>
              <p className="text-xs text-gray-400 mt-1">
                Sube el archivo crudo descargado de Google Forms, Google Sheets o cualquier software de encuestas.
              </p>
            </div>
            <button 
              onClick={() => setShowCsvBox(false)} 
              className="text-xs font-mono font-bold text-gray-400 hover:text-gray-700 underline"
            >
              Cerrar
            </button>
          </div>

          <IntelligentCSVImporter 
            semesters={semesters} 
            onImportComplete={handleCSVImportComplete}
          />

          {csvFeedback && (
            <div className={`p-3 rounded-none text-xs font-mono font-bold ${csvFeedback.success ? 'bg-emerald-50 text-emerald-800 border border-emerald-100' : 'bg-rose-50 text-rose-800 border border-rose-100'}`}>
              {csvFeedback.msg}
            </div>
          )}
        </div>
      )}

      {/* CORE EXPORTEABLE PRINT CANVAS CONTAINER */}
      <div 
        ref={dashboardPrintRef}
        className="space-y-6 bg-[#f5f5f5] p-1 rounded-none-none"
        id="dashboard-printable-area-canvas"
      >
        
        {mode === 'EMPTY' ? (
          <div className="bg-white border-2 border-dashed border-[#E5E5E0] rounded-none-none p-12 text-center max-w-2xl mx-auto my-12 space-y-6 fade-in">
            <div className="mx-auto w-16 h-16 bg-[#F9423A]/5 rounded-none-none flex items-center justify-center">
              <FileSpreadsheet className="w-8 h-8 text-[#F9423A]" />
            </div>
            <div className="space-y-2">
              <h3 className="text-lg font-bold font-display text-[#1a1a1a]">Cuadro de mando sin datos activos</h3>
              <p className="text-sm text-gray-500 leading-relaxed font-sans">
                Todavía no se ha cargado ningún cuestionario. Sube tu primer CSV de Clientes o de Equipo para empezar a ver tu cuadro de mando.
              </p>
            </div>
            <div className="flex flex-col sm:flex-row justify-center items-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => setShowCsvBox(true)}
                className="flex items-center space-x-2 px-4 py-2 bg-[#F9423A] text-white rounded-none text-sm font-bold transition-all hover:bg-red-600 cursor-pointer font-mono"
              >
                <Upload className="w-4 h-4" />
                <span>Cargar archivo CSV</span>
              </button>
              <button
                type="button"
                onClick={simulateNewPeriod}
                className="flex items-center space-x-2 px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 border border-gray-300 rounded-none text-sm font-bold transition-all cursor-pointer font-mono"
              >
                <Sparkles className="w-4 h-4 text-[#F9423A]" />
                <span>Simular datos Comuniza</span>
              </button>
            </div>
          </div>
        ) : (
          <>
            {/* PRINT HEADER: ONLY SHOWN ON PNG/PDF GENERATION */}
            <div className="hidden show-on-print border-b border-[#E5E5E0] pb-4 mb-4" id="comuniza-print-header">
              <div className="flex justify-between items-end">
                <div>
                  <div className="text-[10px] font-mono uppercase font-extrabold tracking-widest text-[#F9423A]">
                    INFORME DE TRANSFORMACIÓN DE MARCA • COMUNIZA
                  </div>
                  <h1 className="text-2xl font-extrabold font-display text-[#1a1a1a] uppercase tracking-tight mt-1">
                    Cuadro de mando de significados
                  </h1>
                  <span className="text-xs text-gray-500 font-mono">
                    Marca Evaluada: <span className="font-bold text-[#1a1a1a]">{config.marca}</span> • Muestra total: {config.cohorteMuestra}
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-xl font-extrabold text-[#F9423A] font-display">comuniza,</span>
                  <div className="text-xs font-mono font-bold text-gray-700 mt-0.5">
                    Periodo: {activeSemester?.periodo}
                  </div>
                </div>
              </div>
            </div>

            {/* 1. BRAND DESIGN DETAILS ROW WITH EXPORT TRIGGERS */}
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-[#E5E5E0] pb-4">
              <div>
                <div className="flex items-center space-x-2">
                  <span className="w-1.5 h-1.5 bg-[#F9423A] rounded-none-none" />
                  <span className="text-[10px] font-mono uppercase font-extrabold text-gray-400 tracking-wider">
                    SITUACIÓN ACTUAL • {activeSemester?.periodo}
                  </span>
                  
                  {/* Discrete Mode Badge Indicator */}
                  {mode === 'C' ? (
                    <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-none text-[9px] font-bold font-mono bg-emerald-50 text-emerald-800 border border-emerald-200">
                      Clientes + Equipo
                    </span>
                  ) : mode === 'A' ? (
                    <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-none text-[9px] font-bold font-mono bg-blue-50 text-blue-800 border border-blue-200">
                      Solo Clientes
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-none text-[9px] font-bold font-mono bg-purple-50 text-purple-800 border border-purple-200">
                      Solo Equipo
                    </span>
                  )}
                </div>
                <h2 className="text-2xl font-extrabold font-display leading-tight tracking-tight text-[#1a1a1a] mt-1">
                  Resumen evolutivo de la marca {config.marca}
                </h2>
              </div>

              <div className="flex gap-2 font-mono hide-during-print">
                <button 
                  onClick={() => runExport('png')}
                  disabled={isExporting}
                  className="flex items-center space-x-1 px-2.5 py-1.5 bg-white border border-[#E5E5E0] rounded-none text-xs font-bold text-gray-600 hover:text-[#1a1a1a] hover:border-gray-500 transition-colors cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5 text-[#F9423A]" />
                  <span>{isExporting ? 'Procesando...' : 'Exportar PNG (2x)'}</span>
                </button>
                <button 
                  onClick={() => runExport('pdf')}
                  disabled={isExporting}
                  className="flex items-center space-x-1 px-2.5 py-1.5 bg-[#1a1a1a] hover:bg-gray-800 text-white rounded-none text-xs font-bold transition-all cursor-pointer"
                >
                  <FileCheck className="w-3.5 h-3.5" />
                  <span>{isExporting ? 'Generando...' : 'Descargar PDF Slide (16:9)'}</span>
                </button>
              </div>
            </div>

        {/* 2. THE FOUR SYNTHETIC INDICATORS CARDS ROW */}
        <div className={`grid grid-cols-1 gap-4 ${
          mode === 'C' ? 'sm:grid-cols-2 lg:grid-cols-4' : mode === 'A' ? 'sm:grid-cols-3 lg:grid-cols-3' : 'sm:grid-cols-2 lg:grid-cols-2'
        }`} id="row-kpis-4-sinteticos">
          
          {/* KPI 1: SIGNIFICADO */}
          {(mode === 'A' || mode === 'C') && (
            <div className="bg-white border border-[#E5E5E0] p-5 rounded-none-none flex flex-col justify-between space-y-4">
              <div className="flex justify-between items-start">
                <div className="space-y-0.5">
                  <span className="font-mono text-[9px] uppercase font-bold text-gray-400 tracking-widest block">EXTERNO • ASOCIACIONES</span>
                  <h4 className="text-sm font-bold text-[#1a1a1a] font-display">Significado de marca</h4>
                </div>
                <div className="p-1.5 bg-[#F9423A]/5 rounded-none">
                  <Users className="w-4 h-4 text-[#F9423A]" />
                </div>
              </div>

              <div className="flex items-baseline space-x-3">
                <span className="text-4xl font-extrabold font-display text-[#1a1a1a] tracking-tight">{activeSignificado}</span>
                <span className="text-xs font-mono text-gray-400">/ 100 ptos</span>
              </div>

              <div className="pt-3 border-t border-gray-100 flex items-center justify-between text-xs font-mono">
                <span className="text-gray-400">Vs Semestre anterior:</span>
                {prevSemester ? (
                  <div className={`flex items-center space-x-0.5 font-bold ${deltaSignificado >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                    {deltaSignificado >= 0 ? <TrendingUp className="w-3.5 h-3.5" /> : <TrendingDown className="w-3.5 h-3.5" />}
                    <span>{deltaSignificado >= 0 ? `+${deltaSignificado}` : deltaSignificado} ptos</span>
                  </div>
                ) : (
                  <span className="text-gray-400 italic">Línea Base</span>
                )}
              </div>
            </div>
          )}

          {/* KPI 2: FORTALEZA / DIFERENCIACIÓN */}
          {(mode === 'A' || mode === 'C') && (
            <div className="bg-white border border-[#E5E5E0] p-5 rounded-none-none flex flex-col justify-between space-y-4">
              <div className="flex justify-between items-start">
                <div className="space-y-0.5">
                  <span className="font-mono text-[9px] uppercase font-bold text-gray-400 tracking-widest block">EXTERNO • POSICIONAMIENTO</span>
                  <h4 className="text-sm font-bold text-[#1a1a1a] font-display">Fortaleza y diferenciación</h4>
                </div>
                <div className="p-1.5 bg-[#F9423A]/5 rounded-none">
                  <Layers className="w-4 h-4 text-[#F9423A]" />
                </div>
              </div>

              <div className="flex items-baseline space-x-3">
                <span className="text-4xl font-extrabold font-display text-[#1a1a1a] tracking-tight">{activeFortaleza}</span>
                <span className="text-xs font-mono text-gray-400">/ 100 ptos</span>
              </div>

              <div className="pt-3 border-t border-gray-100 flex items-center justify-between text-xs font-mono">
                <span className="text-gray-400">Vs Semestre anterior:</span>
                {prevSemester ? (
                  <div className={`flex items-center space-x-0.5 font-bold ${deltaFortaleza >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                    {deltaFortaleza >= 0 ? <TrendingUp className="w-3.5 h-3.5" /> : <TrendingDown className="w-3.5 h-3.5" />}
                    <span>{deltaFortaleza >= 0 ? `+${deltaFortaleza}` : deltaFortaleza} ptos</span>
                  </div>
                ) : (
                  <span className="text-gray-400 italic">Línea Base</span>
                )}
              </div>
            </div>
          )}

          {/* KPI 3: ALINEAMIENTO ESTRATÉGICO */}
          <div className="bg-[#1a1a1a] text-white p-5 rounded-none-none flex flex-col justify-between space-y-4 shadow-sm">
            <div className="flex justify-between items-start">
              <div className="space-y-0.5">
                <span className="font-mono text-[9px] uppercase font-bold text-white/50 tracking-widest block">
                  {mode === 'C' ? 'DIALÉCTICA INTERNO-EXTERNO' : mode === 'A' ? 'EXTERNO • CLIENTES' : 'INTERNO • CULTURA'}
                </span>
                <h4 className="text-sm font-bold font-display text-white">
                  {mode === 'C' ? 'Alineamiento estratégico' : 'Apropiación de la idea'}
                </h4>
              </div>
              <div className="p-1.5 bg-white/10 rounded-none">
                <ArrowRightLeft className="w-4 h-4 text-[#F9423A]" />
              </div>
            </div>

            <div className="flex items-baseline space-x-3">
              <span className="text-4xl font-extrabold font-display text-white tracking-tight">{activeAlineamiento}</span>
              <span className="text-xs font-mono text-white/65">/ 100 ptos</span>
            </div>

            <div className="pt-3 border-t border-white/10 flex items-center justify-between text-xs font-mono">
              <span className="text-white/50">Vs Semestre anterior:</span>
              {prevSemester ? (
                <div className={`flex items-center space-x-0.5 font-bold ${deltaAlineamiento >= 0 ? 'text-emerald-400' : 'text-rose-300'}`}>
                  {deltaAlineamiento >= 0 ? <TrendingUp className="w-3.5 h-3.5" /> : <TrendingDown className="w-3.5 h-3.5" />}
                  <span>{deltaAlineamiento >= 0 ? `+${deltaAlineamiento}` : deltaAlineamiento} ptos</span>
                </div>
              ) : (
                <span className="text-white/40 italic">Línea Base</span>
              )}
            </div>
          </div>

          {/* KPI 4: IMPLANTACIÓN OPERATIVA */}
          {(mode === 'B' || mode === 'C') && (
            <div className="bg-white border border-[#E5E5E0] p-5 rounded-none-none flex flex-col justify-between space-y-4">
              <div className="flex justify-between items-start">
                <div className="space-y-0.5">
                  <span className="font-mono text-[9px] uppercase font-bold text-gray-400 tracking-widest block">INTERNO • CULTURA Y EQUIPO</span>
                  <h4 className="text-sm font-bold text-[#1a1a1a] font-display">Implantación operativa</h4>
                </div>
                <div className="p-1.5 bg-[#F9423A]/5 rounded-none">
                  <Briefcase className="w-4 h-4 text-[#F9423A]" />
                </div>
              </div>

              <div className="flex items-baseline space-x-3">
                <span className="text-4xl font-extrabold font-display text-[#1a1a1a] tracking-tight">{activeImplantacion}</span>
                <span className="text-xs font-mono text-gray-400">/ 100 ptos</span>
              </div>

              <div className="pt-3 border-t border-gray-100 flex items-center justify-between text-xs font-mono">
                <span className="text-gray-400">Vs Semestre anterior:</span>
                {prevSemester ? (
                  <div className={`flex items-center space-x-0.5 font-bold ${deltaImplantacion >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                    {deltaImplantacion >= 0 ? <TrendingUp className="w-3.5 h-3.5" /> : <TrendingDown className="w-3.5 h-3.5" />}
                    <span>{deltaImplantacion >= 0 ? `+${deltaImplantacion}` : deltaImplantacion} ptos</span>
                  </div>
                ) : (
                  <span className="text-gray-400 italic">Línea Base</span>
                )}
              </div>
            </div>
          )}

        </div>

        {/* 3. CORE GAP ANALYSIS INSIGHT: COMPARING VALUE ALIGNMENT (SIDE BY SIDE) */}
        {mode === 'C' && (
          <div className="bg-white border border-[#E5E5E0] rounded-none-none p-6 space-y-6" id="gap-de-alineamiento-panel">
            
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-gray-100 pb-3">
              <div className="space-y-1">
                <span className="font-mono text-[9px] uppercase font-bold text-[#F9423A]">INSIGHT DIFERENCIAL • MIRADAS CRUZADAS</span>
                <h3 className="text-base font-bold font-display text-[#1a1a1a]">
                  Brecha de Alineamiento (Clientes vs. Equipo Interno)
                </h3>
              </div>
              
              <div className="px-3 py-1 bg-[#f5f5f5] border border-[#E5E5E0] rounded-none font-mono text-xs font-bold text-gray-700">
                Cruce: Percepción Externa vs. Asimilación Cultural
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
              
              {/* The interactive gap indicators (4 columns) */}
              <div className="lg:col-span-4 space-y-4">
                <p className="text-xs text-gray-500 leading-relaxed">
                  Este indicador mide la cohesión del rebranding. Contrastar el nivel de apropiación de la idea central de marca de tu mercado contra el de tu propio equipo señala si la promesa se está externalizando bien o si se queda enquistada de forma interna.
                </p>

                <div className="p-4 bg-[#f5f5f5] rounded-none border border-gray-100 space-y-2">
                  <div className="flex justify-between items-baseline">
                    <span className="text-xs font-mono text-gray-400">Brecha Nominal:</span>
                    <span className="text-base font-mono font-bold text-[#1a1a1a]">
                      {alignGap > 0 ? `+${alignGap}` : alignGap} ptos
                    </span>
                  </div>
                  <div className="flex justify-between items-baseline">
                    <span className="text-xs font-mono text-gray-400">Diagnóstico:</span>
                    <span className="text-xs font-bold text-[#F9423A]">
                      {alignGap > 15 
                        ? 'Desfase importante (La cultura interna lidera)' 
                        : alignGap < -10 
                        ? 'Mercado asimila más rápido' 
                        : 'Alineación coherente de marca'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Faced progress bars (8 columns) representing "dos barras enfrentadas por la apropiación de la idea de marca" */}
              <div className="lg:col-span-8 space-y-6">
                
                <div className="space-y-4">
                  
                  {/* 1. Bar Clientes */}
                  <div className="space-y-1.5">
                    <div className="flex justify-between text-xs font-mono">
                      <span className="font-bold text-gray-600 flex items-center gap-1">
                        <Users className="w-3.5 h-3.5 text-[#F9423A]" />
                        Apropiación CLIENTES (Mercado)
                      </span>
                      <span className="font-bold text-[#1a1a1a]">{alignCliente} / 100 ptos</span>
                    </div>
                    <div className="w-full bg-gray-100 h-3.5 rounded-none-none overflow-hidden">
                      <div 
                        className="bg-[#F9423A] h-full rounded-none-none transition-all duration-500" 
                        style={{ width: `${alignCliente}%` }}
                      />
                    </div>
                  </div>

                  {/* 2. Bar Empleados */}
                  <div className="space-y-1.5">
                    <div className="flex justify-between text-xs font-mono">
                      <span className="font-bold text-gray-600 flex items-center gap-1">
                        <Briefcase className="w-3.5 h-3.5 text-[#1a1a1a]" />
                        Apropiación EMPLEADOS (Interno)
                      </span>
                      <span className="font-bold text-[#1a1a1a]">{alignInterno} / 100 ptos</span>
                    </div>
                    <div className="w-full bg-gray-100 h-3.5 rounded-none-none overflow-hidden">
                      <div 
                        className="bg-[#1a1a1a] h-full rounded-none-none transition-all duration-500" 
                        style={{ width: `${alignInterno}%` }}
                      />
                    </div>
                  </div>

                </div>

                {/* DETAILED COMPARISON ON THE LIKERT SCALE (A4 vs B2) */}
                <div className="bg-gray-50 p-4 rounded-none-none space-y-3">
                  <h5 className="text-[10px] font-mono font-bold text-gray-400 uppercase tracking-widest text-center border-b border-gray-200 pb-1.5">
                    Distribución de acuerdo: Idea central "{config.ideaMarca}"
                  </h5>
                  
                  <div className="space-y-2 text-[11px]">
                    {[
                      { label: '1. No la entienden / No la interiorizan', key: 'no_la_entiendo' },
                      { label: '2. Entienden pero sin relación directa', key: 'no_relaciono' },
                      { label: '3. Relación / Interiorización parcial', key: 'relaciono_parcialmente' },
                      { label: '4. Relación / Interiorización clara', key: 'relaciono_claramente' },
                      { label: '5. Máximo nivel y diferencial', key: 'relaciono_y_diferencial' }
                    ].map((row, idx) => {
                      const pctClient = (activeSemester.apropiacionA4 as any)[row.key] || 0;
                      const pctEmployee = (activeSemester.apropiacionB2 as any)[row.key] || 0;
                      return (
                        <div key={idx} className="grid grid-cols-12 gap-3 items-center">
                          <span className="col-span-4 text-gray-500 font-medium truncate" title={row.label}>
                            {row.label}
                          </span>
                          
                          <div className="col-span-8 grid grid-cols-2 gap-4 items-center">
                            {/* Client left bar (drawn in coral) */}
                            <div className="flex items-center justify-end space-x-1.5">
                              <span className="text-[10px] font-mono font-bold text-gray-500">{pctClient}%</span>
                              <div className="w-full bg-gray-200 h-2 rounded-none-none overflow-hidden flex justify-end">
                                <div className="bg-[#F9423A] h-full rounded-none-none" style={{ width: `${pctClient}%` }} />
                              </div>
                            </div>

                            {/* Employee right bar (drawn in dark coal) */}
                            <div className="flex items-center justify-start space-x-1.5">
                              <div className="w-full bg-gray-200 h-2 rounded-none-none overflow-hidden flex justify-start">
                                <div className="bg-[#1a1a1a] h-full rounded-none-none" style={{ width: `${pctEmployee}%` }} />
                              </div>
                              <span className="text-[10px] font-mono font-bold text-gray-500">{pctEmployee}%</span>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  <div className="flex justify-center space-x-6 pt-1 text-[10px] font-mono text-gray-400">
                    <div className="flex items-center space-x-1">
                      <span className="w-2 h-2 rounded-none-none bg-[#F9423A]" />
                      <span>Clientes</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <span className="w-2 h-2 rounded-none-none bg-[#1a1a1a]" />
                      <span>Empleados</span>
                    </div>
                  </div>

                </div>

              </div>

            </div>

          </div>
        )}

        {/* 4. DETAILS SECTION GRID (LEFT: CLIENT/MERCADO, RIGHT: EMPLEADO/INTERNO) */}
        <div className={`grid grid-cols-1 gap-6 ${mode === 'C' ? 'lg:grid-cols-2' : ''}`} id="dashboard-details-audience-split">
          
          {/* CLIENTE / MERCADO (EXPLICIT LOOKING OUTSIDE) */}
          {(mode === 'A' || mode === 'C') && (
            <div className="bg-white border border-[#E5E5E0] rounded-none-none p-6 space-y-6">
            
            <div className="flex justify-between items-center pb-3 border-b border-[#E5E5E0]">
              <div className="flex items-center space-x-2">
                <Users className="w-4.5 h-4.5 text-[#F9423A]" />
                <h3 className="font-bold font-display text-gray-900">Plano A: cliente / mercado (percepción externa)</h3>
              </div>
              <span className="text-[10px] font-mono bg-[#f5f5f5] text-gray-500 font-bold border border-gray-100 px-2 py-0.5 rounded-none leading-none">
                N={activeSemester.clienteNumRespuestas} respuestas
              </span>
            </div>

            {/* A1: Word Cloud representation */}
            <div className="space-y-2">
              <label className="block text-[10px] font-mono font-bold text-gray-400 uppercase tracking-widest">
                A1. Conceptos espontáneos dominantes (nube semántica)
              </label>
              
              <div className="p-5 bg-[#f5f5f5] rounded-none-none border border-gray-100 flex flex-wrap gap-2.5 justify-center items-center select-none">
                {activeSemester.palabrasA1.map((w, idx) => {
                  // Determine scale size
                  const sizeClass = w.value > 45 ? 'text-lg font-extrabold text-[#F9423A]' :
                                    w.value > 30 ? 'text-base font-bold text-[#1a1a1a]' :
                                    w.value > 20 ? 'text-xs font-bold text-gray-500' :
                                    'text-[11px] font-medium text-gray-400';
                  return (
                    <span 
                      key={idx} 
                      className={`${sizeClass} px-2 py-1 bg-white border border-gray-150 rounded-none-none hover:-translate-y-0.5 transition-transform cursor-default`}
                      title={`Frecuencia de mención espontánea: ${w.value}`}
                    >
                      {w.text}
                      <span className="text-[8px] font-mono text-gray-300 ml-1">({w.value})</span>
                    </span>
                  );
                })}
              </div>
            </div>

            {/* A2: Strengths Distribution */}
            <div className="space-y-3">
              <label className="block text-[10px] font-mono font-bold text-gray-400 uppercase tracking-widest">
                A2. Principal punto fuerte de la marca
              </label>
              
              <div className="space-y-2 text-xs">
                {Object.entries(activeSemester.fortalezasA2).map(([key, val], idx) => {
                  return (
                    <div key={idx} className="space-y-1">
                      <div className="flex justify-between text-[11px] font-medium text-gray-700">
                        <span>{key}</span>
                        <span className="font-mono font-bold text-[#1a1a1a]">{val}%</span>
                      </div>
                      <div className="w-full bg-gray-50 h-2 rounded-none-none overflow-hidden">
                        <div className="bg-[#1a1a1a] h-full transition-all" style={{ width: `${val}%` }} />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* A3: Brand Agreement Averages */}
            <div className="space-y-3">
              <label className="block text-[10px] font-mono font-bold text-gray-400 uppercase tracking-widest">
                A3. Acuerdo en afirmaciones de percepción de marca (0 - 10)
              </label>
              
              <div className="space-y-3.5">
                {[
                  { label: 'La marca tiene una propuesta clara', val: activeSemester.acuerdoA3.propuesta_clara },
                  { label: 'La marca es relevante para sus públicos', val: activeSemester.acuerdoA3.relevancia_publicos },
                  { label: 'La marca se diferencia de las alternativas', val: activeSemester.acuerdoA3.diferenciacion_alternativas },
                  { label: 'La marca genera confianza', val: activeSemester.acuerdoA3.genera_confianza },
                  { label: 'La marca proyecta una imagen coherente', val: activeSemester.acuerdoA3.proyecta_coherencia },
                  { label: 'La marca está evolucionando en la dirección adecuada', val: activeSemester.acuerdoA3.evolucion_adecuada }
                ].map((row, idx) => {
                  return (
                    <div key={idx} className="space-y-1 text-xs">
                      <div className="flex justify-between text-[11px] font-medium text-gray-700">
                        <span>{row.label}</span>
                        <span className="font-mono font-bold text-[#F9423A]">{row.val} / 10</span>
                      </div>
                      <div className="w-full bg-gray-50 h-2 rounded-none-none overflow-hidden">
                        <div className="bg-[#F9423A] h-full transition-all" style={{ width: `${row.val * 10}%` }} />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* A4: Idea Appropriation */}
            <div className="space-y-3">
              <label className="block text-[10px] font-mono font-bold text-gray-400 uppercase tracking-widest">
                A4. Relación y apropiación de la idea de marca
              </label>
              
              <div className="space-y-2 text-xs">
                {[
                  { label: 'No la entiende / No la relaciona', val: (activeSemester.apropiacionA4.no_la_entiendo || 0) + (activeSemester.apropiacionA4.no_relaciono || 0) },
                  { label: 'La relaciona parcialmente', val: activeSemester.apropiacionA4.relaciono_parcialmente || 0 },
                  { label: 'La relaciona claramente', val: activeSemester.apropiacionA4.relaciono_claramente || 0 },
                  { label: 'Nivel máximo y diferencial', val: activeSemester.apropiacionA4.relaciono_y_diferencial || 0 }
                ].map((row, idx) => {
                  return (
                    <div key={idx} className="space-y-1">
                      <div className="flex justify-between text-[11px] font-medium text-gray-700">
                        <span>{row.label}</span>
                        <span className="font-mono font-bold text-gray-800">{row.val}%</span>
                      </div>
                      <div className="w-full bg-gray-50 h-2 rounded-none-none overflow-hidden">
                        <div className="bg-gray-400 h-full transition-all" style={{ width: `${row.val}%` }} />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* A5: Personalidad / Sensaciones */}
            <div className="space-y-3">
              <label className="block text-[10px] font-mono font-bold text-[#F9423A] uppercase tracking-widest">
                A5. Atributos de personalidad asimilados
              </label>
              
              <div className="grid grid-cols-2 gap-3">
                {Object.entries(activeSemester.personalidadA5).map(([attr, val], idx) => {
                  return (
                    <div key={idx} className="p-2 bg-[#f5f5f5] rounded-none border border-gray-100 flex items-center justify-between">
                      <span className="text-[11px] font-bold text-gray-700">{attr}</span>
                      <span className="font-mono text-[10px] font-extrabold text-[#F9423A]">{val}%</span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* A6: Síntesis cualitativa libre */}
            <div className="space-y-2">
              <label className="block text-[10px] font-mono font-bold text-[#F9423A] uppercase tracking-widest">
                Síntesis cualitativa de percepciones libres (externo)
              </label>
              <div className="space-y-2">
                {activeSemester.clustersA7.map((c, i) => (
                  <div key={i} className="p-3 bg-red-50/20 border-l-2 border-[#F9423A] rounded-none-none text-xs">
                    <p className="font-bold text-[#1a1a1a]">{c.name}</p>
                    <span className="font-mono text-[10px] text-gray-400 mt-1 block">Peso temático en respuestas: {c.percentage}%</span>
                  </div>
                ))}
              </div>
            </div>

          </div>
          )}

          {/* EMPLEADO / INTERNO (THE INTERNAL TRANSFORMATION BASEPLANE) */}
          {(mode === 'B' || mode === 'C') && (
            <div className="bg-white border border-[#E5E5E0] rounded-none-none p-6 space-y-6">
            
            <div className="flex justify-between items-center pb-3 border-b border-[#E5E5E0]">
              <div className="flex items-center space-x-2">
                <Briefcase className="w-4.5 h-4.5 text-[#1a1a1a]" />
                <h3 className="font-bold font-display text-gray-900">Plano B: personal interno / empleados (cultura / implantación)</h3>
              </div>
              <span className="text-[10px] font-mono bg-[#f5f5f5] text-gray-500 font-bold border border-gray-100 px-2 py-0.5 rounded-none leading-none">
                N={activeSemester.empleadoNumRespuestas} colaboradores
              </span>
            </div>

            {/* B1: Internal Agreement Averages */}
            <div className="space-y-3">
              <label className="block text-[10px] font-mono font-bold text-gray-400 uppercase tracking-widest">
                B1. Acuerdo en afirmaciones de implantación (0 - 10)
              </label>
              
              <div className="space-y-3.5">
                {[
                  { label: 'Entiendo el posicionamiento actual de la marca', val: activeSemester.acuerdoB1.entiendo_posicionamiento },
                  { label: 'Sé cómo aplicar la marca en mi trabajo diario', val: activeSemester.acuerdoB1.se_aplicar_marca },
                  { label: 'Dispongo de herramientas y recursos suficientes', val: activeSemester.acuerdoB1.recursos_suficientes },
                  { label: 'La marca ayuda a tomar mejores decisiones', val: activeSemester.acuerdoB1.mejores_decisiones },
                  { label: 'Existe coherencia entre la promesa y lo que hacemos', val: activeSemester.acuerdoB1.coherencia_promesa }
                ].map((row, idx) => {
                  return (
                    <div key={idx} className="space-y-1 text-xs">
                      <div className="flex justify-between text-[11px] font-medium text-gray-700">
                        <span>{row.label}</span>
                        <span className="font-mono font-bold text-[#1a1a1a]">{row.val} / 10</span>
                      </div>
                      <div className="w-full bg-gray-50 h-2 rounded-none-none overflow-hidden">
                        <div className="bg-[#1a1a1a] h-full transition-all" style={{ width: `${row.val * 10}%` }} />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* B2: Prioridades de mejora */}
            <div className="space-y-3">
              <label className="block text-[10px] font-mono font-bold text-gray-400 uppercase tracking-widest">
                B2. Prioridades de mejora (principal reto próximo semestre)
              </label>
              
              <div className="space-y-2 text-xs">
                {Object.entries(activeSemester.retosA6).map(([opt, val], idx) => {
                  return (
                    <div key={idx} className="space-y-1">
                      <div className="flex justify-between text-[11px] font-medium text-gray-700">
                        <span>{opt}</span>
                        <span className="font-mono font-bold text-[#1a1a1a]">{val}%</span>
                      </div>
                      <div className="w-full bg-gray-50 h-2 rounded-none-none overflow-hidden">
                        <div className="bg-[#1a1a1a] h-full transition-all" style={{ width: `${val}%` }} />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* B3: clusters cualitativos internos */}
            <div className="space-y-2 pt-2">
              <label className="block text-[10px] font-mono font-bold text-[#1a1a1a] uppercase tracking-widest">
                B3. Opinión abierta: Síntesis de cambios y necesidades propuestas
              </label>
              <div className="space-y-2">
                {activeSemester.clustersB4.map((c, i) => (
                  <div key={i} className="p-3 bg-[#f5f5f5] border-l-2 border-[#1a1a1a] rounded-none-none text-xs">
                    <p className="font-bold text-[#1a1a1a]">{c.name}</p>
                    <span className="font-mono text-[10px] text-gray-400 mt-1 block">Peso temático en sugerencias: {c.percentage}%</span>
                  </div>
                ))}
              </div>
            </div>

          </div>
          )}

        </div>

        {/* 5. HISTORICAL CHART & EVOLUTION TREND LINES */}
        <div className="bg-white border border-[#E5E5E0] rounded-none-none p-6 space-y-6" id="evolucion-historica-panel">
          
          <div className="flex justify-between items-center pb-3 border-b border-[#E5E5E0]">
            <div>
              <span className="font-mono text-[9px] uppercase font-bold text-[#F9423A]">SERIES CRONOLÓGICAS</span>
              <h3 className="text-base font-bold font-display text-[#1a1a1a]">
                Trayectoria de indicadores sintéticos
              </h3>
            </div>
            <span className="text-[10px] font-mono text-gray-400 bg-[#f5f5f5] border border-gray-100 px-2.5 py-1 rounded-none">
              Semestre a Semestre
            </span>
          </div>

          <div className={`grid grid-cols-1 gap-6 ${
            mode === 'C' ? 'md:grid-cols-2 lg:grid-cols-4' : mode === 'A' ? 'md:grid-cols-3 lg:grid-cols-3' : 'md:grid-cols-2 lg:grid-cols-2'
          }`}>
            
            {/* Chart 1: Significado (Only shown in mode A and C) */}
            {(mode === 'A' || mode === 'C') && (
              <div className="space-y-2 p-3 bg-[#f5f5f5] rounded-none-none border border-gray-150">
                <span className="font-mono text-[10px] text-gray-500 font-bold block text-center">Significado de marca</span>
                <EvolutionLineChart 
                  data={semesters.map(s => calcularSignificadoScore(s))} 
                  labels={semesters.map(s => s.periodo)} 
                  activeIndex={activeIndex} 
                  maxVal={100}
                  color="#F9423A"
                />
              </div>
            )}

            {/* Chart 2: Fortaleza (Only shown in mode A and C) */}
            {(mode === 'A' || mode === 'C') && (
              <div className="space-y-2 p-3 bg-[#f5f5f5] rounded-none-none border border-gray-150">
                <span className="font-mono text-[10px] text-gray-500 font-bold block text-center">Fortaleza / dif.</span>
                <EvolutionLineChart 
                  data={semesters.map(s => calcularFortalezaScore(s))}  
                  labels={semesters.map(s => s.periodo)} 
                  activeIndex={activeIndex} 
                  maxVal={100}
                  color="#000000"
                />
              </div>
            )}

            {/* Chart 3: Alineamiento / Apropiación (Always shown) */}
            <div className="space-y-2 p-3 bg-[#f5f5f5] rounded-none-none border border-gray-150">
              <span className="font-mono text-[10px] text-gray-500 font-bold block text-center">
                {mode === 'C' ? 'Alineamiento estratégico' : 'Apropiación de la idea'}
              </span>
              <EvolutionLineChart 
                data={semesters.map(s => {
                  if (mode === 'A') return calcularApropiacionScore(s.apropiacionA4);
                  if (mode === 'B') return calcularApropiacionScore(s.apropiacionB2);
                  return calcularAlineamientoDashboard(s).score;
                })} 
                labels={semesters.map(s => s.periodo)} 
                activeIndex={activeIndex} 
                maxVal={100}
                color="#1a1a1a"
              />
            </div>

            {/* Chart 4: Implantación (Only shown in mode B and C) */}
            {(mode === 'B' || mode === 'C') && (
              <div className="space-y-2 p-3 bg-[#f5f5f5] rounded-none-none border border-gray-150">
                <span className="font-mono text-[10px] text-gray-500 font-bold block text-center">Implantación operativa</span>
                <EvolutionLineChart 
                  data={semesters.map(s => calcularImplantacionScore(s))} 
                  labels={semesters.map(s => s.periodo)} 
                  activeIndex={activeIndex} 
                  maxVal={100}
                  color="#F9423A"
                />
              </div>
            )}

          </div>

        </div>

        {/* 5b. PREGUNTAS ADICIONALES DE CLIENTE */}
        {activeSemester?.customQuestions && activeSemester.customQuestions.length > 0 && (
          <div className="bg-white border border-[#E5E5E0] rounded-none p-6 space-y-6" id="custom-questions-panel">
            
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-gray-105 pb-3">
              <div className="space-y-1">
                <span className="font-mono text-[9px] uppercase font-bold text-[#F9423A]">CUESTIONARIOS PERSONALIZADOS • AD-HOC</span>
                <h3 className="text-base font-bold font-display text-[#1a1a1a]">
                  Preguntas adicionales de {config.marca}
                </h3>
              </div>
              
              <div className="px-3 py-1 bg-[#f5f5f5] border border-[#E5E5E0] rounded-none font-mono text-[9px] font-bold text-gray-400">
                Módulo independiente — No afecta el Brand Score núcleo
              </div>
            </div>

            <p className="text-xs text-gray-500 leading-relaxed font-sans">
              Este bloque muestra los datos de las preguntas personalizadas añadidas por {config.marca} en sus cuestionarios. Estas variables ad-hoc permiten explorar dimensiones complementarias específicas de tu negocio, sin contaminar ni alterar los 4 indicadores sintéticos estandarizados ni el cálculo del Brand Score de Comuniza.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6" id="grid-custom-questions">
              {activeSemester.customQuestions.map((q, idx) => {
                return (
                  <div key={idx} className="p-5 bg-gray-50 border border-gray-150 rounded-none flex flex-col justify-between space-y-4">
                    <div className="flex justify-between items-start">
                      <div className="space-y-1">
                        <span className="font-mono text-[9px] uppercase font-extrabold text-gray-400 tracking-wider">
                          {q.audience === 'clientes' ? 'Audiencia: Clientes' : 'Audiencia: Equipo'}
                        </span>
                        <h4 className="text-sm font-bold text-[#1a1a1a] font-display pr-4">{q.header}</h4>
                      </div>
                      <span className="inline-flex items-center px-1.5 py-0.5 rounded-none text-[8px] font-bold font-mono bg-gray-100 text-gray-600 border border-gray-200 uppercase leading-none">
                        {q.type === 'numeric' ? 'Numérico' : q.type === 'categorical' ? 'Distribución' : 'Texto libre'}
                      </span>
                    </div>

                    {/* RENDER CONTENT BASED ON TYPE */}
                    {q.type === 'numeric' && q.average !== undefined && (() => {
                      const history = semesters
                        .map(s => {
                          const found = s.customQuestions?.find(cq => cq.header === q.header && cq.type === 'numeric');
                          return {
                            id: s.id,
                            periodo: s.periodo,
                            average: found?.average
                          };
                        })
                        .filter(item => item.average !== undefined)
                        .sort((a, b) => a.periodo.localeCompare(b.periodo));

                      const maxVal = history.some(h => h.average > 10) ? 100 : 10;
                      const activeHistoryIndex = history.findIndex(h => h.id === activeSemester.id);

                      return (
                        <div className="space-y-4">
                          <div className="flex justify-between items-end">
                            <div className="space-y-1">
                              <div className="flex items-baseline space-x-2">
                                <span className="text-4xl font-extrabold font-display text-[#1a1a1a] tracking-tight">{q.average}</span>
                                <span className="text-xs font-mono text-gray-400">valor medio ({activeSemester.periodo})</span>
                              </div>
                              <div className="w-48 bg-gray-200 h-2 rounded-none overflow-hidden">
                                <div 
                                  className="bg-[#F9423A] h-full transition-all duration-500" 
                                  style={{ width: `${Math.min(100, q.average <= 10 ? q.average * 10 : q.average)}%` }}
                                />
                              </div>
                            </div>
                            
                            {/* Short text description of delta if history.length > 1 */}
                            {history.length > 1 && activeHistoryIndex > 0 && (() => {
                              const prevVal = history[activeHistoryIndex - 1].average;
                              const currentVal = q.average;
                              const delta = Math.round((currentVal - prevVal) * 10) / 10;
                              return (
                                <div className="text-right">
                                  <span className={`inline-flex items-center text-[10px] font-mono font-bold ${delta > 0 ? 'text-emerald-600' : delta < 0 ? 'text-[#F9423A]' : 'text-gray-400'}`}>
                                    {delta > 0 ? `+${delta}` : delta} vs {history[activeHistoryIndex - 1].periodo}
                                  </span>
                                </div>
                              );
                            })()}
                          </div>

                          {/* Historical Line Chart if there are 2 or more semesters */}
                          {history.length >= 2 ? (
                            <div className="pt-2 border-t border-gray-150 space-y-1.5">
                              <span className="text-[9px] font-mono uppercase font-bold text-gray-400">Evolución histórica</span>
                              <div className="bg-white p-2 border border-gray-200/60 rounded-none">
                                <EvolutionLineChart 
                                  data={history.map(h => h.average)} 
                                  labels={history.map(h => h.periodo)} 
                                  activeIndex={activeHistoryIndex >= 0 ? activeHistoryIndex : history.length - 1} 
                                  maxVal={maxVal}
                                />
                              </div>
                            </div>
                          ) : (
                            <span className="text-[10px] text-gray-400 font-mono block">
                              Carga más semestres con esta columna para habilitar el gráfico de evolución histórica.
                            </span>
                          )}
                        </div>
                      );
                    })()}

                    {q.type === 'categorical' && q.distribution && (
                      <div className="space-y-2 text-xs">
                        {Object.entries(q.distribution).map(([opt, pct], oIdx) => {
                          return (
                            <div key={oIdx} className="space-y-1">
                              <div className="flex justify-between text-[11px] font-medium text-gray-700">
                                <span className="truncate pr-2" title={opt}>{opt}</span>
                                <span className="font-mono font-bold text-[#1a1a1a]">{pct}%</span>
                              </div>
                              <div className="w-full bg-gray-250 h-2 rounded-none overflow-hidden">
                                <div 
                                  className="bg-[#1a1a1a] h-full transition-all duration-500" 
                                  style={{ width: `${pct}%` }} 
                                />
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}

                    {q.type === 'text' && q.answers && (
                      <div className="space-y-3">
                        {/* Word cloud for text free custom questions */}
                        {q.words && q.words.length > 0 && (
                          <div className="p-3 bg-white border border-gray-150 rounded-none flex flex-wrap gap-1.5 justify-center items-center">
                            {q.words.map((w, wIdx) => {
                              const sizeClass = w.value > 5 ? 'text-xs font-bold text-[#F9423A]' : 'text-[10px] text-gray-500';
                              return (
                                <span key={wIdx} className={`${sizeClass} px-1.5 py-0.5 bg-gray-50 border border-gray-100`}>
                                  {w.text} <span className="text-[8px] font-mono opacity-50">({w.value})</span>
                                </span>
                              );
                            })}
                          </div>
                        )}
                        
                        <div className="space-y-1.5">
                          <span className="text-[9px] font-mono font-bold text-gray-400 uppercase tracking-widest block">Extracto de respuestas:</span>
                          <div className="max-h-[140px] overflow-y-auto space-y-1.5 pr-1" id={`custom-q-text-answers-${idx}`}>
                            {q.answers.map((ans, aIdx) => {
                              return (
                                <div key={aIdx} className="p-2 bg-white border-l-2 border-gray-200 text-[11px] text-gray-600 italic">
                                  "{ans}"
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      </div>
                    )}

                  </div>
                );
              })}
            </div>

            {/* COMPARATIVE MEMO NOTE */}
            <div className="p-3.5 bg-indigo-50/50 border border-indigo-100 rounded-none text-xs text-indigo-900 leading-relaxed font-sans">
              <strong>Nota de comparabilidad:</strong> Estas variables adicionales son independientes del estándar de Comuniza y no participan en las comparativas de benchmarking globales de marca. Se recomienda mantener una redacción estable semestre a semestre para preservar la consistencia histórica.
            </div>

          </div>
        )}

        {/* 6. AUTOMATIC DYNAMIC REBRANDING PRESCRIPTION DISPATCHER */}
        <div className="bg-white border border-[#E5E5E0] rounded-none-none p-6 space-y-6" id="automatic-action-prescriptions">
          
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-gray-100 pb-3">
            <div className="space-y-1">
              <div className="flex items-center space-x-2 text-[#1a1a1a]">
                <HelpCircle className="w-4 h-4 text-[#F9423A]" />
                <span className="font-mono text-[10px] uppercase font-bold tracking-wider">PRESCRIPCIONES AUTOMÁTICAS DE ACTUACIÓN COMUNIZA</span>
              </div>
              <h3 className="text-base font-bold font-display text-[#1a1a1a]">
                Plan de prioridad estratégica para {config.marca}
              </h3>
            </div>
            
            <div className="text-[10px] font-mono text-gray-400">
              Disparadas automáticamente ante caídas inter-semestrales
            </div>
          </div>

          {prescriptionsToTrigger.length === 0 ? (
            /* Standard baseline positive callout */
            <div className="p-5 bg-emerald-50/20 border border-emerald-100 rounded-none-none flex items-start space-x-3 text-xs text-slate-700 leading-relaxed">
              <CheckCircle className="w-5 h-5 text-emerald-500 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <p className="font-bold text-[#1a1a1a]">¡Todos los indicadores progresan favorablemente en este periodo!</p>
                <p className="text-[11px] text-gray-400">
                  No se registran caídas cuanti-cualitativas con respecto al semestre anterior. Continúa aplicando la disciplina de marca y revisando la asimilación del equipo semestralmente.
                </p>
              </div>
            </div>
          ) : (
            /* Triggered strategic directives with styled callouts */
            <div className="space-y-4">
              {prescriptionsToTrigger.map((p, i) => (
                <div key={i} className="p-5 bg-rose-50/20 border border-rose-100 rounded-none-none flex flex-col md:flex-row justify-between items-start md:items-center gap-4 text-xs">
                  <div className="space-y-1.5 flex-1">
                    <div className="flex items-center space-x-2">
                      <span className="font-mono text-[10px] bg-rose-100 text-rose-800 font-bold px-2 py-0.5 rounded-none uppercase">
                        ATENCIÓN URGENTE • {p.id.toUpperCase()}
                      </span>
                      <span className="text-gray-300">•</span>
                      <span className="font-mono text-[11px] text-gray-500">
                        Baja de {p.prevVal} a {p.activeVal} ptos.
                      </span>
                    </div>
                    <h4 className="text-sm font-bold text-[#1a1a1a] font-display">{p.name}</h4>
                    <p className="text-gray-600 leading-relaxed max-w-4xl italic">
                      "{p.text}"
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}

        </div>

      </>)}
      </div> {/* END EXPORTEABLE CONTAINER */}


      {/* SECTION B: INTERNAL PERSISTENT PRESCRIPTION DICTIONARY MANAGER: SHOWN TO BOTH ROLES BUT READ-ONLY FOR CLIENTE */}
      <div className="bg-white border border-[#E5E5E0] rounded-none-none p-6 space-y-6 hide-during-print" id="diccionario-prescripciones-edicion">
        
        <div className="space-y-1.5 pb-2 border-b border-gray-100">
          <div className="flex items-center space-x-2 text-[#1a1a1a]">
            <Edit3 className="w-4 h-4" />
            <span className="font-mono text-[10px] uppercase font-bold tracking-wider">REGISTRO DE PRESCRIPCIONES CLÍNICAS DE MARCA</span>
          </div>
          <h3 className="text-lg font-bold font-display text-[#1a1a1a]">Diccionario de prescripciones del dashboard</h3>
          <p className="text-xs text-gray-400 leading-relaxed">
            {perfilAcceso === 'consultor' ? (
              <span>Define y edita en tiempo real las guías clínicas preestablecidas que se dispararán en el dashboard ante caídas semestrales. El cliente final visualiza estas guías pero no puede modificarlas.</span>
            ) : (
              <span className="flex items-center gap-1.5 text-gray-400"><Lock className="w-3.5 h-3.5 inline text-gray-400" /> Vista de consulta para el Cliente. Las directrices clínicas estratégicas son administradas y redactadas por Comuniza.</span>
            )}
          </p>
        </div>

        {/* Dictionary card editor */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {prescriptions.map((p) => {
            const isEditing = perfilAcceso === 'consultor' && editingPrescriptionId === p.id;
            return (
              <div 
                key={p.id} 
                className={`p-4 rounded-none border flex flex-col justify-between space-y-3 transition-colors ${
                  isEditing 
                    ? 'bg-[#1a1a1a]/5 border-[#1a1a1a]' 
                    : 'bg-white border-gray-150 hover:border-gray-200'
                }`}
                id={`prescription-card-${p.id}`}
              >
                <div className="space-y-1">
                  <span className="font-mono text-[9px] font-bold text-gray-400 block">{p.id.toUpperCase()}</span>
                  <h5 className="text-[12px] font-extrabold text-[#1a1a1a] leading-tight mb-2">{p.name}</h5>
                  
                  {isEditing ? (
                    <textarea
                      value={p.text}
                      onChange={(e) => handleEditPrescription(p.id, e.target.value)}
                      rows={6}
                      className="w-full text-[11px] bg-white border border-gray-200 rounded-none p-1.5 focus:border-[#1a1a1a] outline-none leading-relaxed"
                    />
                  ) : (
                    <p className="text-[11px] text-gray-500 leading-relaxed max-h-[120px] overflow-y-auto pr-1">
                      {p.text}
                    </p>
                  )}
                </div>

                <div className="pt-2 border-t border-gray-100 flex justify-between items-center text-[10px] font-mono">
                  <span className="text-gray-400">Template dict.</span>
                  {perfilAcceso === 'consultor' ? (
                    <button
                      onClick={() => setEditingPrescriptionId(isEditing ? null : p.id)}
                      className="font-bold text-[#F9423A] hover:underline cursor-pointer"
                    >
                      {isEditing ? '[ Guardar cambios ]' : '[ Editar escrito ]'}
                    </button>
                  ) : (
                    <span className="text-gray-400 flex items-center gap-1 select-none font-sans font-medium text-[9px] bg-gray-50 px-1.5 py-0.5 rounded-none border border-gray-100">
                      <Lock className="w-2.5 h-2.5" />
                      Solo lectura
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>

      </div>

    </div>
  );
};
