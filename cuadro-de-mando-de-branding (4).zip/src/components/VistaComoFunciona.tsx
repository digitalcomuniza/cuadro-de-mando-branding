import React, { useState } from 'react';
import { 
  Compass, 
  Users, 
  HelpCircle, 
  FileSpreadsheet, 
  BarChart3, 
  AlertTriangle, 
  Download, 
  Upload, 
  Check, 
  ShieldCheck,
  Zap,
  Info,
  Sparkles,
  MessageSquare,
  Smile,
  FileText
} from 'lucide-react';
import { PlaceholderConfig, SemesterData, Prescription } from '../types';
import { IntelligentCSVImporter } from './IntelligentCSVImporter';

interface VistaComoFuncionaProps {
  config: PlaceholderConfig;
  setConfig: (config: PlaceholderConfig) => void;
  semesters: SemesterData[];
  setSemesters: (semesters: SemesterData[]) => void;
  prescriptions: Prescription[];
  setPrescriptions: (prescriptions: Prescription[]) => void;
  setActiveTab: (tab: 'como-funciona' | 'cuestionario' | 'dashboard') => void;
}

export const VistaComoFunciona: React.FC<VistaComoFuncionaProps> = ({ 
  config, 
  setConfig, 
  semesters, 
  setSemesters, 
  prescriptions, 
  setPrescriptions,
  setActiveTab
}) => {
  const [currentStep, setCurrentStep] = useState(1);
  const [backupSuccess, setBackupSuccess] = useState<string | null>(null);

  // Plantillas sugeridas en CSV real para descarga
  const csvTemplateClients = `Semestre de Medición,Asociación de Palabras libres,¿Cuál crees que es la principal fortaleza?,Claridad de propuesta,Relevancia de marca,Diferenciación,Grado de Confianza,Coherencia percibida,Evolución adecuada,Acoplamiento de marca (Apropiación),Atributos extra,Retos principales
2027-S1,Cercano;Sólido;Ágil,Propuesta de valor,8.5,8.0,7.8,8.2,9.0,8.4,relaciono_claramente,Innovadora;Fiable,Experiencia de cliente
2027-S1,Innovador;Confiable;Rápido,Calidad de productos o servicios,9.0,8.6,8.1,8.9,8.7,8.8,relaciono_y_diferencial,Transparente,Comunicación`;

  const csvTemplateEmployees = `Período de Medición,Entiendo el posicionamiento,Sé aplicar la marca en mi día a día,Tengo recursos suficientes,Ayuda a tomar mejores decisiones,Coherencia con las promesas de marca,Grado de vinculación individual con la idea,Dificultades detectadas,Sugerencias de equipo
2027-S1,9.0,8.5,8.0,8.7,8.3,relaciono_y_diferencial,Incoherencias entre áreas,Más formación
2027-S1,8.2,7.9,8.1,8.0,8.0,relaciono_claramente,Falta de tiempo,Talleres prácticos`;

  const handleDownloadCSV = (type: 'clientes' | 'equipo') => {
    try {
      const csvContent = type === 'clientes' ? csvTemplateClients : csvTemplateEmployees;
      const fileName = type === 'clientes' ? 'Plantilla_EJEMPLO_Clientes.csv' : 'Plantilla_EJEMPLO_Equipo.csv';
      
      // Force UTF-8 with BOM for correct Spanish characters in Excel
      const blob = new Blob([new Uint8Array([0xEF, 0xBB, 0xBF]), csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', fileName);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (err) {
      alert('Error al descargar el archivo CSV.');
    }
  };

  // Callback on successful active file drop/load within Step 6
  const handleWizardImportComplete = (nuevoSemestre: SemesterData, feedbackMessage: string) => {
    setSemesters([...semesters.filter(s => s.id !== nuevoSemestre.id), nuevoSemestre]);
    setBackupSuccess(feedbackMessage);
    
    // Auto-advance to Step 7 after showing success
    setTimeout(() => {
      setBackupSuccess(null);
      setCurrentStep(7);
    }, 3500);
  };

  // Copia de seguridad en JSON
  const handleDowloadBackup = () => {
    try {
      const dataPayload = {
        app: 'comuniza-brand-tracker',
        exportedAt: new Date().toISOString(),
        config,
        semesters,
        prescriptions
      };
      
      const blob = new Blob([JSON.stringify(dataPayload, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `Copia_Seguridad_Comuniza_${config.marca.replace(/\s+/g, '_')}_${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      setBackupSuccess('¡Copia de seguridad (.json) descargada a tu ordenador! Guárdala bien.');
      setTimeout(() => setBackupSuccess(null), 6000);
    } catch (err) {
      alert('Error al exportar la copia de seguridad.');
    }
  };

  // Re-importación de copia de seguridad JSON
  const handleUploadBackup = (event: React.ChangeEvent<HTMLInputElement>) => {
    const fileReader = new FileReader();
    const files = event.target.files;
    if (!files || files.length === 0) return;

    fileReader.onload = (e) => {
      try {
        const text = e.target?.result as string;
        const parsed = JSON.parse(text);
        
        if (parsed.semesters && parsed.config) {
          setSemesters(parsed.semesters);
          setConfig(parsed.config);
          if (parsed.prescriptions) {
            setPrescriptions(parsed.prescriptions);
          }
          setBackupSuccess('¡Éxito! Copia de seguridad oficial cargada. El histórico y la configuración de marca han sido actualizados.');
          setTimeout(() => setBackupSuccess(null), 6000);
        } else {
          alert('Este archivo JSON no parece ser una copia de seguridad válida de esta aplicación.');
        }
      } catch (err) {
        alert('Formato de archivo inválido.');
      }
    };
    fileReader.readAsText(files[0]);
  };

  return (
    <div className="w-full max-w-4xl mx-auto py-6 px-4 animate-comuniza-fadeIn" id="onboarding-cmo-master">
      
      {/* 1. HEADER BRAND STYLE INFO */}
      <div className="space-y-4 text-center max-w-3xl mx-auto mb-8">
        <span className="font-mono text-[10px] uppercase tracking-widest text-[#F9423A] font-bold bg-[#F9423A]/5 px-3.5 py-1.5 rounded-none border border-[#F9423A]/10">
          MÉTODO COMUNIZA • GUÍA INTERACTIVA
        </span>
        <h2 className="text-3xl font-extrabold font-display leading-tight tracking-tight text-[#1a1a1a]">
          Cómo gobernar el significado de tu marca
        </h2>
        <p className="text-sm font-sans text-gray-500 leading-relaxed">
          Diseñado para líderes y directivos de marketing. Este manual interactivo te guiará paso a paso para dominar las mediciones semestrales de marca de forma ágil y autónoma.
        </p>
      </div>

      {/* CARD MAIN WIZARD CONTAINER */}
      <div className="bg-[#f5f5f5] border border-[#E5E5E0] rounded-none shadow-xs overflow-hidden flex flex-col md:min-h-[580px]">
        
        {/* TOP STATUS BAR */}
        <div className="bg-white px-8 py-3.5 border-b border-[#E5E5E0] flex flex-col sm:flex-row justify-between items-center gap-2">
          <div className="flex items-center space-x-2">
            <span className="w-2 h-2 rounded-none bg-[#F9423A] animate-ping" />
            <span className="font-mono text-[9px] uppercase font-bold text-gray-400 tracking-wider">
              Onboarding Interactivo
            </span>
          </div>
          <div className="font-mono text-[10px] text-gray-600 font-bold bg-[#f5f5f5] px-3 py-1 rounded-none border border-gray-100">
            Paso {currentStep} de 7
          </div>
        </div>

        {/* PROGRESS BAR */}
        <div className="w-full bg-gray-100 h-1">
          <div 
            className="bg-[#F9423A] h-full transition-all duration-500 ease-out" 
            style={{ width: `${(currentStep / 7) * 100}%` }} 
          />
        </div>

        {/* INTERMEDIARY MAIN ACTIVE PANEL VIEW */}
        <div className="flex-1 p-8 sm:p-12 flex flex-col justify-center bg-white">
          
          {/* ════════════════════════ PANTALLA 1: BIENVENIDA ════════════════════════ */}
          {currentStep === 1 && (
            <div className="space-y-6 text-center animate-comuniza-fadeIn" id="step-1-welcome">
              <div className="inline-flex p-4 bg-[#F9423A]/5 rounded-none text-[#F9423A] border border-[#F9423A]/10">
                <Compass className="w-12 h-12 stroke-[1.25]" />
              </div>
              
              <div className="space-y-3">
                <h3 className="text-2xl sm:text-3xl font-extrabold font-display leading-tight text-[#1a1a1a] tracking-tight">
                  Mide cómo evoluciona tu marca, cada seis meses.
                </h3>
                <p className="text-sm sm:text-base text-gray-500 max-w-xl mx-auto leading-relaxed font-sans">
                  Esta herramienta te ayuda a averiguar si tus clientes y tus equipos están entendiendo la misma idea de marca a lo largo del tiempo.
                </p>
              </div>

              <div className="py-3 px-5 bg-[#f5f5f5] border border-[#E5E5E0] rounded-none inline-block max-w-md">
                <p className="text-xs text-gray-600 leading-normal">
                  🚀 <strong>Lo harás solo 2 veces al año.</strong> Te costará menos esfuerzo de lo que te imaginas y tendrás un histórico impecable.
                </p>
              </div>

              <div className="pt-4">
                <button
                  type="button"
                  onClick={() => setCurrentStep(2)}
                  className="btn-comuniza-primary"
                >
                  Ver a quién preguntar
                </button>
              </div>
            </div>
          )}

          {/* ════════════════════════ PANTALLA 2: A QUIÉN SE LE PREGUNTA ════════════════════════ */}
          {currentStep === 2 && (
            <div className="space-y-6 text-left animate-comuniza-fadeIn" id="step-2-audiences">
              <div className="space-y-2 text-center pb-1">
                <div className="inline-flex p-3 bg-[#7A1626]/5 rounded-none text-[#7A1626] mb-1">
                  <Users className="w-8 h-8" />
                </div>
                <h3 className="text-2xl font-extrabold font-display text-[#1a1a1a] tracking-tight">
                  ¿A quién vas a preguntar?
                </h3>
                <p className="text-xs text-gray-500 max-w-md mx-auto">
                  Cada semestre lanzamos dos consultas breves y rápidas para captar la armonía de dos miradas vitales:
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Tarjeta Clientes */}
                <div className="border border-[#E5E5E0] rounded-none p-5 bg-white space-y-2 flex flex-col justify-between shadow-2xs hover:border-gray-300 transition-colors">
                  <div>
                    <span className="font-mono text-[9px] uppercase font-bold text-[#F9423A] bg-[#F9423A]/5 px-2 py-0.5 rounded-none">
                      Mirada 1: El Mercado
                    </span>
                    <h4 className="text-sm font-bold text-[#1a1a1a] pt-1">A tus clientes</h4>
                    <p className="text-xs text-gray-500 leading-relaxed font-sans pt-1">
                      Para evaluar cómo nos perciben desde fuera. Queremos saber si asocian el concepto correcto, si la propuesta les parece útil y diferenciada, o si depositan confianza en nosotros.
                    </p>
                  </div>
                </div>

                {/* Tarjeta Empleados */}
                <div className="border border-[#E5E5E0] rounded-none p-5 bg-white space-y-2 flex flex-col justify-between shadow-2xs hover:border-gray-300 transition-colors">
                  <div>
                    <span className="font-mono text-[9px] uppercase font-bold text-[#7A1626] bg-[#7A1626]/5 px-2 py-0.5 rounded-none">
                      Mirada 2: La Cultura
                    </span>
                    <h4 className="text-sm font-bold text-[#1a1a1a] pt-1">A tu equipo</h4>
                    <p className="text-xs text-gray-500 leading-relaxed font-sans pt-1">
                      Para investigar la alineación del equipo. ¿Comprenden el posicionamiento estratégico? ¿Saben cómo aplicar la guía de marca? ¿Cuentan con las herramientas suficientes en su día a día?
                    </p>
                  </div>
                </div>
              </div>

              <div className="p-4 bg-amber-50 rounded-none text-amber-950 border border-amber-100 text-center font-medium text-xs leading-relaxed max-w-2xl mx-auto">
                💡 <strong>Comparar las dos miradas es donde está el oro.</strong> Detectar las brechas entre lo que se vive en casa y lo que se proyecta fuera te dará las mejores palancas de mejora.
              </div>
            </div>
          )}

          {/* ════════════════════════ PANTALLA 3: CÓMO SE LANZAN LAS ENCUESTAS ════════════════════════ */}
          {currentStep === 3 && (
            <div className="space-y-6 text-center animate-comuniza-fadeIn" id="step-3-surveys">
              <div className="inline-flex p-3 bg-indigo-50 rounded-none text-indigo-600 mb-1">
                <MessageSquare className="w-8 h-8" />
              </div>
              
              <div className="space-y-2 max-w-xl mx-auto">
                <h3 className="text-2xl font-extrabold font-display text-[#1a1a1a] tracking-tight">
                  ¿Cómo lanzas las encuestas?
                </h3>
                <p className="text-xs sm:text-sm text-gray-500 leading-relaxed font-sans">
                  Puedes utilizar tu herramienta favorita de siempre (<strong>Google Forms, Typeform, SurveyMonkey, Microsoft Forms</strong>) o aprovechar el simulador que te hemos integrado para realizar pruebas ágiles.
                </p>
                
                <div className="p-4 bg-[#f5f5f5] border border-[#E5E5E0] rounded-none text-left space-y-2 mt-4">
                  <span className="text-[10px] font-mono font-bold text-gray-400 uppercase tracking-widest block">Lo único que de verdad importa:</span>
                  <p className="text-xs text-gray-500 leading-relaxed">
                    No importa el software de encuestas que elijas. El único objetivo es sencillamente exportar las respuestas recogidas en un único archivo de tabla al final de cada semestre.
                  </p>
                </div>
              </div>

              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => setActiveTab('cuestionario')}
                  className="inline-flex items-center space-x-1.5 text-xs text-[#F9423A] font-mono font-bold hover:underline bg-[#F9423A]/5 px-3 py-2 rounded-none cursor-pointer"
                >
                  <span>Ver propuesta de Cuestionario modelo</span>
                </button>
              </div>
            </div>
          )}

          {/* ════════════════════════ PANTALLA 4: PREGUNTAS DEL FORMULARIO RECOMENDADO ════════════════════════ */}
          {currentStep === 4 && (
            <div className="space-y-5 text-left animate-comuniza-fadeIn" id="step-4-templates">
              <div className="space-y-2 text-center">
                <div className="inline-flex p-3 bg-indigo-50 rounded-none text-indigo-600 mb-1">
                  <Sparkles className="w-8 h-8" />
                </div>
                <h3 className="text-2xl font-extrabold font-display text-[#1a1a1a] tracking-tight">
                  Estructura de Preguntas para el Formulario
                </h3>
                <p className="text-xs sm:text-sm text-gray-500 max-w-lg mx-auto">
                  Si creas un Google Form o un Typeform con estas preguntas exactas o similares, nuestro importador automático asociará perfectamente cada dato sin errores.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Estructura Clientes */}
                <div className="border border-[#E5E5E0] bg-[#f5f5f5] p-5 rounded-none flex flex-col justify-between space-y-3 shadow-2xs hover:border-[#F9423A]/10">
                  <div className="space-y-1.5 flex-1">
                    <span className="text-[10px] text-[#F9423A] font-mono font-bold block uppercase">PREGUNTAS DE CLIENTES</span>
                    <h5 className="text-xs font-bold text-gray-800 font-display">Cuestionario del Mercado (Clientes)</h5>
                    <div className="bg-white p-2.5 rounded-none border border-gray-100 font-mono text-[9px] text-gray-500 max-h-44 overflow-y-auto space-y-1">
                      <p>1. Asociación libre de palabras (Cercano, Fiable...)</p>
                      <p>2. Principal fortaleza (Propuesta de valor / Calidad / Experiencia / Confianza)</p>
                      <p>3. Claridad de la propuesta (Votación 1-10)</p>
                      <p>4. Relevancia de la marca (Votación 1-10)</p>
                      <p>5. Diferenciación (Votación 1-10)</p>
                      <p>6. Grado de Confianza (Votación 1-10)</p>
                      <p>7. Coherencia percibida (Votación 1-10)</p>
                      <p>8. Evolución adecuada (Votación 1-10)</p>
                      <p>9. Acoplamiento de marca (Apropiación o vínculo)</p>
                      <p>10. Retos principales de la marca (Sugerencias)</p>
                    </div>
                  </div>
                  <div className="flex flex-col sm:flex-row gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        const txt = `Cuestionario de Clientes (Método Comuniza):\n1. Asociación de Palabras libres\n2. Principal fortaleza percibida\n3. Claridad de propuesta (1-10)\n4. Relevancia de marca (1-10)\n5. Diferenciación respecto a la competencia (1-10)\n6. Grado de Confianza (1-10)\n7. Coherencia percibida de marca (1-10)\n8. Evolución adecuada (1-10)\n9. Acoplamiento de marca (Apropiación)\n10. Retos principales que identificas`;
                        navigator.clipboard.writeText(txt);
                        alert('¡Estructura de Clientes copiada al portapapeles!');
                      }}
                      className="flex-1 flex items-center justify-center space-x-1 w-full bg-[#1a1a1a] hover:bg-black text-white py-1.5 px-2 rounded-none text-xs font-bold cursor-pointer transition-colors"
                    >
                      <span>Copiar preguntas</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDownloadCSV('clientes')}
                      className="flex-1 flex items-center justify-center space-x-1.5 w-full bg-white hover:bg-gray-50 text-gray-700 border border-gray-300 py-1.5 px-2 rounded-none text-xs font-bold cursor-pointer transition-colors"
                    >
                      <Download className="w-3.5 h-3.5 text-[#F9423A]" />
                      <span>Descargar Plantilla (.csv)</span>
                    </button>
                  </div>
                </div>

                {/* Estructura Equipo */}
                <div className="border border-[#E5E5E0] bg-[#f5f5f5] p-5 rounded-none flex flex-col justify-between space-y-3 shadow-2xs hover:border-[#F9423A]/10">
                  <div className="space-y-1.5 flex-1">
                    <span className="text-[10px] text-[#7A1626] font-mono font-bold block uppercase">PREGUNTAS DE EQUIPO</span>
                    <h5 className="text-xs font-bold text-gray-800 font-display">Cuestionario de Cultura (Interno)</h5>
                    <div className="bg-white p-2.5 rounded-none border border-gray-100 font-mono text-[9px] text-gray-500 max-h-44 overflow-y-auto space-y-1">
                      <p>1. Entiendo el posicionamiento estratégico (1-10)</p>
                      <p>2. Sé cómo aplicar la marca en mi día a día (1-10)</p>
                      <p>3. Dispongo de recursos suficientes (1-10)</p>
                      <p>4. La marca me ayuda a tomar mejores decisiones (1-10)</p>
                      <p>5. Coherencia con las promesas de marca (1-10)</p>
                      <p>6. Grado de vinculación individual con la idea</p>
                      <p>7. Dificultades detectadas para asimilar la marca</p>
                      <p>8. Sugerencias abiertas de equipo</p>
                    </div>
                  </div>
                  <div className="flex flex-col sm:flex-row gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        const txt = `Cuestionario del Equipo (Método Comuniza):\n1. Entiendo el posicionamiento de marca (1-10)\n2. Sé aplicar la marca en mi puesto (1-10)\n3. Tengo recursos suficientes (1-10)\n4. Ayuda a tomar mejores decisiones (1-10)\n5. Coherencia con las promesas de marca (1-10)\n6. Grado de vinculación individual con la idea\n7. Dificultades detectadas\n8. Sugerencias de equipo`;
                        navigator.clipboard.writeText(txt);
                        alert('¡Estructura de Equipo copiada al portapapeles!');
                      }}
                      className="flex-1 flex items-center justify-center space-x-1 w-full bg-[#1a1a1a] hover:bg-black text-white py-1.5 px-2 rounded-none text-xs font-bold cursor-pointer transition-colors"
                    >
                      <span>Copiar preguntas</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDownloadCSV('equipo')}
                      className="flex-1 flex items-center justify-center space-x-1.5 w-full bg-white hover:bg-gray-50 text-gray-700 border border-gray-300 py-1.5 px-2 rounded-none text-xs font-bold cursor-pointer transition-colors"
                    >
                      <Download className="w-3.5 h-3.5 text-[#F9423A]" />
                      <span>Descargar Plantilla (.csv)</span>
                    </button>
                  </div>
                </div>
              </div>

              <div className="p-4 bg-amber-50 rounded-none text-amber-900 border border-amber-100 text-center font-medium text-xs leading-relaxed max-w-2xl mx-auto font-sans space-y-1">
                <p>⚠️ <strong>Datos de ejemplo — sustitúyelos por tus respuestas reales</strong></p>
                <p className="text-[11px] text-amber-700 font-normal">Las plantillas descargables contienen filas con datos ficticios para guiarte sobre el formato. Asegúrate de vaciar estas filas de prueba e insertar las respuestas reales de tu cliente antes de importarlas.</p>
              </div>
            </div>
          )}

          {/* ════════════════════════ PANTALLA 5: REGLA DE NOMBRES ════════════════════════ */}
          {currentStep === 5 && (
            <div className="space-y-6 text-left animate-comuniza-fadeIn" id="step-5-saving">
              <div className="space-y-2 text-center pb-1">
                <div className="inline-flex p-3 bg-amber-50 rounded-none text-amber-600 mb-1">
                  <Zap className="w-8 h-8" />
                </div>
                <h3 className="text-2xl font-extrabold font-display text-[#1a1a1a] tracking-tight">
                  Cómo exportar y guardar tus respuestas
                </h3>
                <p className="text-xs text-gray-500 max-w-md mx-auto">
                  Una vez lanzadas las consultas semestrales en Google Forms, recupera el archivo CSV con solo un clic:
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-3xl mx-auto text-xs pb-2">
                <div className="p-4 bg-white border border-[#E5E5E0] rounded-none text-center space-y-2 shadow-3xs">
                  <span className="font-mono font-bold text-[#F9423A] text-sm bg-[#F9423A]/5 rounded-none w-7 h-7 inline-flex items-center justify-center border border-[#F9423A]/10">1</span>
                  <p className="font-bold text-gray-900 font-display">Exporta a Google Sheets</p>
                  <p className="text-gray-400 text-[11px] leading-relaxed font-sans">
                    Abre la pestaña "Respuestas" en tu formulario de Google y haz clic en "Ver en Sheets".
                  </p>
                </div>

                <div className="p-4 bg-white border border-[#E5E5E0] rounded-none text-center space-y-2 shadow-3xs">
                  <span className="font-mono font-bold text-[#F9423A] text-sm bg-[#F9423A]/5 rounded-none w-7 h-7 inline-flex items-center justify-center border border-[#F9423A]/10">2</span>
                  <p className="font-bold text-gray-900 font-display">Descarga a CSV</p>
                  <p className="text-gray-400 text-[11px] leading-relaxed font-sans">
                    En Google Sheets haz clic en <strong>Archivo → Descargar → Valores separados por comas (.csv)</strong>.
                  </p>
                </div>

                <div className="p-4 bg-white border border-[#E5E5E0] rounded-none text-center space-y-2 shadow-3xs">
                  <span className="font-mono font-bold text-[#F9423A] text-sm bg-[#F9423A]/5 rounded-none w-7 h-7 inline-flex items-center justify-center border border-[#F9423A]/10">3</span>
                  <p className="font-bold text-gray-900 font-display">Sube al Cuadro de Mando</p>
                  <p className="text-gray-400 text-[11px] leading-relaxed font-sans">
                    En el próximo paso de este onboarding, arrastra el archivo y agrégalo directo al histórico.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* ════════════════════════ PANTALLA 6: CARGA DE ARCHIVO INTELIGENTE DETALLES ════════════════════════ */}
          {currentStep === 6 && (
            <div className="space-y-5 text-left animate-comuniza-fadeIn" id="step-6-active-upload">
              <div className="space-y-1 text-center">
                <span className="font-mono text-[9px] uppercase font-bold text-[#F9423A] bg-[#F9423A]/10 px-2.5 py-1 rounded-none">
                  ZONA ACTIVA INTEGRADA
                </span>
                <h3 className="text-2xl font-extrabold font-display text-[#1a1a1a] tracking-tight pt-1">
                  Sube el archivo al Cuadro de Mando
                </h3>
                <p className="text-xs text-gray-500 max-w-lg mx-auto">
                  Aquí tienes el importador inteligente real. ¡Arrastra cualquier CSV exportado o usa los botones de demostración para realizar una simulación real de mapeo!
                </p>
              </div>

              {/* ACTIVE INTEGRATED INTUATIVE IMPORTER */}
              <div className="max-w-3xl mx-auto">
                <IntelligentCSVImporter 
                  semesters={semesters} 
                  onImportComplete={handleWizardImportComplete}
                />
              </div>

              {backupSuccess && (
                <div className="p-3 bg-emerald-50 text-emerald-800 border border-emerald-100 rounded-none text-xs font-mono font-bold max-w-xl mx-auto text-center">
                  {backupSuccess}
                </div>
              )}
            </div>
          )}

          {/* ════════════════════════ PANTALLA 7: PRIVACIDAD Y SEGURIDAD ════════════════════════ */}
          {currentStep === 7 && (
            <div className="space-y-6 text-center animate-comuniza-fadeIn" id="step-7-privacy">
              <div className="inline-flex p-3 bg-teal-50 rounded-none text-teal-600 mb-1">
                <ShieldCheck className="w-8 h-8" />
              </div>
              
              <div className="space-y-3 max-w-xl mx-auto text-left">
                <h3 className="text-2xl font-extrabold font-display text-[#1a1a1a] tracking-tight text-center">
                  Soberanía absoluta de tus datos
                </h3>

                <div className="space-y-3 pt-1">
                  <div className="p-3.5 bg-white border border-[#E5E5E0] rounded-none flex items-start space-x-3.5 shadow-2xs">
                    <span className="text-lg">🔒</span>
                    <p className="text-xs text-gray-500 leading-relaxed">
                      <strong>Tus datos NO se suben a servidores externos ni a internet.</strong> Toda tu información confidencial se aloja de forma segura y soberana únicamente en la memoria de este ordenador y navegador.
                    </p>
                  </div>

                  <div className="p-3.5 bg-amber-50 border border-amber-100 rounded-none flex items-start space-x-3.5">
                    <span className="text-lg">⚠️</span>
                    <p className="text-xs text-amber-900 leading-relaxed">
                      <strong>Una precaución importante:</strong> Como los datos se guardan estrictamente aquí localmente, si limpias el historial completo del navegador o usas otro ordenador, perderás la serie temporal de semestres de forma automática.
                    </p>
                  </div>

                  <div className="p-3.5 bg-emerald-50 border border-emerald-100 rounded-none flex items-start space-x-3.5">
                    <span className="text-lg">💰</span>
                    <p className="text-xs text-emerald-950 leading-relaxed">
                      <strong>Toma una Copia de Seguridad:</strong> Después de cada nueva carga semestral, descarga el archivo de copia. Te servirá de salvaguarda. Si cambias de ordenador, solo tienes que subirlo una vez y recuperarás todo en un segundo.
                    </p>
                  </div>
                </div>
              </div>

              {/* ACTION BACKUPS */}
              <div className="flex flex-col sm:flex-row justify-center items-center gap-3 pt-1 max-w-md mx-auto">
                <button
                  type="button"
                  onClick={handleDowloadBackup}
                  className="flex items-center justify-center space-x-1.5 px-4 py-2.5 bg-[#1a1a1a] hover:bg-black text-white rounded-none text-xs font-mono font-bold w-full cursor-pointer transition-colors duration-400 ease-[cubic-bezier(0.32,0.72,0,1)]"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Guardar Copia (.json)</span>
                </button>

                <label className="flex items-center justify-center space-x-1.5 px-4 py-2.5 border border-[#E5E5E0] bg-white hover:bg-gray-50 rounded-none text-xs font-mono font-bold text-gray-600 w-full cursor-pointer transition-colors duration-400 ease-[cubic-bezier(0.32,0.72,0,1)]">
                  <Upload className="w-3.5 h-3.5" />
                  <span>Restaurar Copia</span>
                  <input
                    type="file"
                    accept=".json"
                    onChange={handleUploadBackup}
                    className="hidden"
                  />
                </label>
              </div>

              {backupSuccess && (
                <div className="p-3 bg-emerald-50 text-emerald-800 border border-emerald-100 rounded-none text-xs font-mono font-bold max-w-md mx-auto">
                  {backupSuccess}
                </div>
              )}

              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setActiveTab('dashboard');
                  }}
                  className="inline-flex items-center space-x-2 px-8 py-3.5 bg-[#F9423A] hover:bg-[#e0352e] text-white font-bold rounded-none cursor-pointer transition-all duration-400 ease-[cubic-bezier(0.32,0.72,0,1)] shadow-md transform hover:-translate-y-0.5"
                >
                  <span>¡Listo, empezar a usarlo!</span>
                </button>
              </div>
            </div>
          )}

        </div>

        {/* BOTTOM WIZARD CONTROLS */}
        <div className="bg-[#f5f5f5] px-8 py-5 border-t border-[#E5E5E0] flex items-center justify-between">
          <div>
            {currentStep > 1 ? (
              <button
                type="button"
                onClick={() => setCurrentStep(prev => prev - 1)}
                className="flex items-center space-x-1.5 px-4 py-2 text-xs font-mono font-bold text-gray-500 hover:text-[#1a1a1a] transition-all duration-400 ease-[cubic-bezier(0.32,0.72,0,1)] cursor-pointer border border-[#E5E5E0] bg-white rounded-none shadow-3xs"
              >
                <span>Atrás</span>
              </button>
            ) : (
              <div className="w-16" />
            )}
          </div>

          {/* DOT INDICATORS */}
          <div className="flex items-center space-x-2">
            {[1, 2, 3, 4, 5, 6, 7].map((num) => (
              <button
                key={num}
                type="button"
                onClick={() => setCurrentStep(num)}
                className={`h-2 rounded-none transition-all duration-300 ${
                  currentStep === num 
                    ? 'w-6 bg-[#F9423A]' 
                    : 'w-2 bg-gray-300 hover:bg-gray-400'
                }`}
                title={`Ir al paso ${num}`}
              />
            ))}
          </div>

          <div>
            {currentStep < 7 ? (
              <button
                type="button"
                onClick={() => setCurrentStep(prev => prev + 1)}
                className="flex items-center space-x-1.5 px-4 py-2 text-xs font-mono font-bold bg-[#1a1a1a] hover:bg-black text-white transition-all duration-400 ease-[cubic-bezier(0.32,0.72,0,1)] cursor-pointer rounded-none"
              >
                <span>Siguiente</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={() => {
                  setActiveTab('dashboard');
                }}
                className="flex items-center space-x-1.5 px-4 py-2 text-xs font-mono font-bold bg-[#F9423A] hover:bg-[#e0352e] text-white transition-all duration-400 ease-[cubic-bezier(0.32,0.72,0,1)] cursor-pointer rounded-none"
              >
                <span>Ir al Dashboard</span>
              </button>
            )}
          </div>
        </div>

      </div>

    </div>
  );
};
