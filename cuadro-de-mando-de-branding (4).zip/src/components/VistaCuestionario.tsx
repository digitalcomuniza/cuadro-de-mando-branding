import React, { useState } from 'react';
import { PlaceholderConfig } from '../types';
import { 
  Users, 
  UserCheck, 
  HelpCircle, 
  Eye, 
  Settings, 
  Compass, 
  Sparkles, 
  FileText, 
  CheckCircle,
  Clock,
  Briefcase,
  Lock,
  Unlock
} from 'lucide-react';

interface VistaCuestionarioProps {
  config: PlaceholderConfig;
  setConfig: React.Dispatch<React.SetStateAction<PlaceholderConfig>>;
  perfilAcceso?: 'consultor' | 'marca';
}

export const VistaCuestionario: React.FC<VistaCuestionarioProps> = ({ config, setConfig, perfilAcceso = 'consultor' }) => {
  const [activeSurveyTab, setActiveSurveyTab] = useState<'cliente' | 'empleado'>('cliente');
  
  // Interactive preview input states (for demonstration of the tool)
  const [demoA1, setDemoA1] = useState({ w1: '', w2: '', w3: '' });
  const [demoA2, setDemoA2] = useState('');
  const [demoA3, setDemoA3] = useState<Record<string, string>>({});
  const [demoA4, setDemoA4] = useState('');
  const [demoA5, setDemoA5] = useState<string[]>([]);
  const [demoA6, setDemoA6] = useState('');
  const [demoA7, setDemoA7] = useState('');

  const [demoB1, setDemoB1] = useState<Record<string, string>>({});
  const [demoB2, setDemoB2] = useState('');
  const [demoB3, setDemoB3] = useState('');
  const [demoB4, setDemoB4] = useState('');

  const [submittedDemo, setSubmittedDemo] = useState(false);

  const handleCheckboxChangeA5 = (val: string) => {
    if (demoA5.includes(val)) {
      setDemoA5(prev => prev.filter(item => item !== val));
    } else {
      if (demoA5.length < 3) {
        setDemoA5(prev => [...prev, val]);
      }
    }
  };

  const resetDemoState = () => {
    setDemoA1({ w1: '', w2: '', w3: '' });
    setDemoA2('');
    setDemoA3({});
    setDemoA4('');
    setDemoA5([]);
    setDemoA6('');
    setDemoA7('');
    setDemoB1({});
    setDemoB2('');
    setDemoB3('');
    setDemoB4('');
    setSubmittedDemo(false);
  };

  return (
    <div className="space-y-8 animate-comuniza-fadeIn" id="cuestionarios-vista-root">
      
      {/* Editorial Header */}
      <div className="space-y-2 border-b border-[#E5E5E0] pb-6">
        <span className="font-mono text-xs uppercase font-extrabold text-[#F9423A] tracking-widest block">
          CONFIGURACIÓN & PREVIEW DE CUESTIONARIOS
        </span>
        <h2 className="text-3xl font-extrabold font-display tracking-tight text-[#1a1a1a]">
          Dos herramientas ágiles para una auditoría rebranding integral
        </h2>
        <p className="text-xs text-gray-500 leading-relaxed max-w-4xl">
          Para que un rebranding se traduzca en reputación real, debes contrastar el plano externo con el interno de manera paralela. Desde aquí configuras las variables maestras e inspeccionas la experiencia que tendrán los encuestados de tu marca.
        </p>
      </div>

      {/* METRIC EXPLANATION ALERT BANNER */}
      <div className="bg-[#1a1a1a] text-white p-4 rounded-none border border-[#1a1a1a]/20 flex flex-col sm:flex-row items-center justify-between gap-3 font-mono text-xs">
        <div className="flex items-center space-x-3">
          <Clock className="w-5 h-5 shrink-0 text-[#F9423A]" />
          <span>
            <strong>Sistemática Semestral:</strong> Ambos cuestionarios se coordinan al final de cada periodo (S1 y S2) para evaluar la tendencia y asimilación de la transformación de marca.
          </span>
        </div>
        <div className="bg-[#2a2a2a] border border-gray-800 text-[#FAFAF8] px-3 py-1 font-bold rounded-none shrink-0">
          Evaluando 2 Audiencias en S1/S2
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* LEFT COLUMN: EDIT REBRANDING PARAMETERS (4 cols) */}
        <div className="lg:col-span-4 space-y-6">
          <div className="bg-white border border-[#E5E5E0] rounded-none p-5 space-y-5" id="cuestionarios-editor-parametros">
            
            <div className="flex items-center justify-between pb-3 border-b border-gray-100">
              <div className="flex items-center space-x-2">
                <Settings className="w-4 h-4 text-[#F9423A]" />
                <h3 className="text-sm font-mono uppercase font-bold text-[#1a1a1a] font-display">
                  Parámetros del rebranding
                </h3>
              </div>
            </div>

            <p className="text-xs text-gray-400 leading-relaxed font-sans">
              Define los valores variables que se inyectarán de forma dinámica dentro de las preguntas de cada cuestionario semestral.
            </p>

            <div className="space-y-4">
              
              <div className="space-y-1">
                <label className="block text-[11px] font-mono font-bold text-gray-500 uppercase">
                  1. Nombre de la Marca evaluada ([MARCA])
                </label>
                <input
                  type="text"
                  value={config.marca}
                  onChange={(e) => setConfig(prev => ({ ...prev, marca: e.target.value }))}
                  className="w-full text-xs bg-[#f5f5f5] border border-[#E5E5E0] focus:border-[#F9423A] rounded-none p-2 outline-none font-medium transition-colors duration-300"
                  placeholder="e.g. Nexo Corporación"
                  id="input-config-marca"
                />
              </div>

              <div className="space-y-1">
                <label className="block text-[11px] font-mono font-bold text-gray-500 uppercase">
                  2. Idea de Marca Central ([IDEA DE MARCA])
                </label>
                <textarea
                  value={config.ideaMarca}
                  onChange={(e) => setConfig(prev => ({ ...prev, ideaMarca: e.target.value }))}
                  rows={2}
                  className="w-full text-xs bg-[#f5f5f5] border border-[#E5E5E0] focus:border-[#F9423A] rounded-none p-2 outline-none font-medium transition-colors duration-300 leading-relaxed"
                  placeholder="e.g. Transformación desde el fondo"
                  id="textarea-config-ideamarca"
                />
              </div>

              <div className="space-y-1">
                <label className="block text-[11px] font-mono font-bold text-gray-500 uppercase">
                  3. Cohorte / Target Muestra
                </label>
                <input
                  type="text"
                  value={config.cohorteMuestra}
                  onChange={(e) => setConfig(prev => ({ ...prev, cohorteMuestra: e.target.value }))}
                  className="w-full text-xs bg-[#f5f5f5] border border-[#E5E5E0] focus:border-[#F9423A] rounded-none p-2 outline-none font-medium transition-colors duration-300"
                  placeholder="e.g. Clientes B2B + Equipo Interno"
                  id="input-config-target"
                />
              </div>

              <div className="space-y-1">
                <label className="block text-[11px] font-mono font-bold text-gray-500 uppercase">
                  4. Volumen de Muestra Agregado (N)
                </label>
                <input
                  type="number"
                  value={config.numContactos}
                  onChange={(e) => setConfig(prev => ({ ...prev, numContactos: Number(e.target.value) || 0 }))}
                  className="w-full text-xs bg-[#f5f5f5] border border-[#E5E5E0] focus:border-[#F9423A] rounded-none p-2 outline-none font-medium transition-colors duration-300"
                  placeholder="e.g. 1200"
                  id="input-config-numcontactos"
                />
              </div>

            </div>

            <div className="pt-3 border-t border-gray-100 bg-gray-50/50 -mx-5 -mb-5 p-4 rounded-none text-center">
              <span className="text-[10px] font-mono text-gray-400">
                Los cambios se aplican automáticamente a las vistas y al gráfico comparativo.
              </span>
            </div>

          </div>

          {/* METRIC WEIGHT CHART SENSORS INFO */}
          <div className="bg-white border border-[#E5E5E0] p-5 rounded-none space-y-4">
            <h4 className="text-xs font-mono font-bold text-gray-800 uppercase flex items-center gap-2">
              <Compass className="w-3.5 h-3.5 text-[#F9423A]" />
              Distribución en Dashboard
            </h4>
            <div className="space-y-3 text-[11px] leading-relaxed font-sans">
              <div className="flex justify-between items-start border-b border-gray-50 pb-2">
                <span className="font-bold text-[#1a1a1a]">1. Significado</span>
                <span className="text-gray-400">Nutrido de A1 y A5 (Externa)</span>
              </div>
              <div className="flex justify-between items-start border-b border-gray-50 pb-2">
                <span className="font-bold text-[#1a1a1a]">2. Fortaleza / Dif.</span>
                <span className="text-gray-400">Nutrido de A2 y A3 (Externa)</span>
              </div>
              <div className="flex justify-between items-start border-b border-gray-50 pb-2">
                <span className="font-bold text-[#1a1a1a]">3. Alineamiento</span>
                <span className="text-gray-400">Cruce Comparado A4 vs. B2</span>
              </div>
              <div className="flex justify-between items-start pb-1">
                <span className="font-bold text-[#1a1a1a]">4. Implantación</span>
                <span className="text-gray-400">Nutrido de B1 y B3 (Interna)</span>
              </div>
            </div>
          </div>

        </div>

        {/* RIGHT COLUMN: REBRANDING SURVEY TABS PREVIEW (8 cols) */}
        <div className="lg:col-span-8 space-y-4">
          
          {/* Active survey tab selector buttons */}
          <div className="flex border border-[#E5E5E0] rounded-none bg-white p-1">
            <button
              onClick={() => { setActiveSurveyTab('cliente'); resetDemoState(); }}
              className={`flex-1 flex items-center justify-center space-x-2 py-2 text-xs font-mono font-bold rounded-none transition-all duration-400 ease-[cubic-bezier(0.32,0.72,0,1)] cursor-pointer ${
                activeSurveyTab === 'cliente'
                  ? 'bg-[#1a1a1a] text-white shadow-xs'
                  : 'text-gray-500 hover:text-[#1a1a1a] hover:bg-gray-50'
              }`}
              id="tab-survey-a-client"
            >
              <Users className="w-3.5 h-3.5" />
              <span>Cuestionario A: Clientes / Mercado</span>
              <span className="text-[9px] bg-[#F9423A] text-white px-1.5 py-0.5 rounded-none ml-1 font-sans">EXTERNA</span>
            </button>
            
            <button
              onClick={() => { setActiveSurveyTab('empleado'); resetDemoState(); }}
              className={`flex-1 flex items-center justify-center space-x-2 py-2 text-xs font-mono font-bold rounded-none transition-all duration-400 ease-[cubic-bezier(0.32,0.72,0,1)] cursor-pointer ${
                activeSurveyTab === 'empleado'
                  ? 'bg-[#1a1a1a] text-white shadow-xs'
                  : 'text-gray-500 hover:text-[#1a1a1a] hover:bg-gray-50'
              }`}
              id="tab-survey-b-employee"
            >
              <Briefcase className="w-3.5 h-3.5" />
              <span>Cuestionario B: Empleados / Interno</span>
              <span className="text-[9px] bg-[#1a1a1a] text-white px-1.5 py-0.5 rounded-none ml-1 font-sans">INTERNA</span>
            </button>
          </div>

          {/* THE PREVIEW CONTAINER AND DEMO FORM */}
          <div className="bg-white border border-[#E5E5E0] rounded-none p-6 lg:p-8 space-y-6 relative">
            
            {/* Header of preview card */}
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between border-b border-gray-100 pb-4 gap-2">
              <div className="flex items-center space-x-2">
                <Eye className="w-4 h-4 text-[#F9423A]" />
                <span className="text-xs font-mono font-bold text-gray-500 uppercase tracking-widest">
                  VISTA PREVIA DEL ENCUESTADO
                </span>
              </div>
              <span className="text-[10px] font-mono text-gray-400 bg-gray-50 px-2 py-1 rounded-none">
                Semestre: Corriente (S1 / S2)
              </span>
            </div>

            {submittedDemo ? (
              /* Success screen */
              <div className="py-12 text-center space-y-4 max-w-md mx-auto" id="survey-success-demo">
                <div className="mx-auto w-12 h-12 bg-emerald-50 rounded-none flex items-center justify-center border border-emerald-100">
                  <CheckCircle className="w-6 h-6 text-emerald-500" />
                </div>
                <h3 className="text-lg font-bold text-[#1a1a1a] font-display">¡Respuesta simulada correctamente!</h3>
                <p className="text-xs text-gray-500 leading-relaxed font-sans">
                  Has completado la experiencia del cuestionario. Los datos reales se consolidan en el dashboard mediante la carga del ficher CSV semestral de tu BBDD o equipo de trabajo global.
                </p>
                <div className="pt-2">
                  <button
                    onClick={resetDemoState}
                    className="px-4 py-1.5 border border-[#E5E5E0] text-xs font-mono font-bold rounded-none hover:border-[#F9423A] hover:text-[#F9423A] transition-colors cursor-pointer"
                  >
                    Examinar de nuevo
                  </button>
                </div>
              </div>
            ) : (
              /* Forms elements */
              <div className="space-y-8 animate-comuniza-fadeIn" id="survey-questions-form">
                
                {activeSurveyTab === 'cliente' ? (
                  /* SURVEY CONFIG A: CLIENTS */
                  <div className="space-y-6">
                    
                    {/* Header survey */}
                    <div className="p-4 bg-[#f5f5f5] rounded-none border border-gray-100">
                      <div className="flex items-center space-x-2">
                        <Users className="w-4 h-4 text-[#F9423A]" />
                        <h3 className="text-sm font-bold text-[#1a1a1a] font-display">Estudio de imagen externa y significado (cuestionario A)</h3>
                      </div>
                      <p className="text-[11px] text-gray-400 mt-1 leading-relaxed font-sans">
                        Dirigido a clientes, usuarios y público objetivo externo de {config.marca}. Evalúa asociación espontánea, fortalezas percibidas, posicionamiento de idea de marca y mapa de personalidad.
                      </p>
                    </div>

                    {/* Question A1 */}
                    <div className="space-y-3">
                      <div className="space-y-1">
                        <div className="flex items-center space-x-2">
                          <span className="text-[10px] font-mono font-bold text-[#F9423A] bg-[#F9423A]/5 px-1.5 py-0.5 rounded-none">A1</span>
                          <span className="text-[10px] font-mono font-bold text-[#F9423A] uppercase tracking-wide">
                            Asociación espontánea • (Análisis: nube de palabras + evolución semestral de conceptos dominantes)
                          </span>
                        </div>
                        <h4 className="text-xs font-bold text-gray-800 font-sans">
                          ¿Qué tres palabras asocias espontáneamente con <span className="font-bold underline text-[#1a1a1a]">{config.marca || '[MARCA]'}</span>?
                        </h4>
                      </div>
                      <div className="grid grid-cols-3 gap-3">
                        <input
                          type="text"
                          placeholder="Asociación 1"
                          value={demoA1.w1}
                          onChange={(e) => setDemoA1(p => ({ ...p, w1: e.target.value }))}
                          className="text-xs border border-gray-200 rounded-none p-2 focus:border-[#F9423A] outline-none"
                        />
                        <input
                          type="text"
                          placeholder="Asociación 2"
                          value={demoA1.w2}
                          onChange={(e) => setDemoA1(p => ({ ...p, w2: e.target.value }))}
                          className="text-xs border border-gray-200 rounded-none p-2 focus:border-[#F9423A] outline-none"
                        />
                        <input
                          type="text"
                          placeholder="Asociación 3"
                          value={demoA1.w3}
                          onChange={(e) => setDemoA1(p => ({ ...p, w3: e.target.value }))}
                          className="text-xs border border-gray-200 rounded-none p-2 focus:border-[#F9423A] outline-none"
                        />
                      </div>
                    </div>

                    {/* Question A2 */}
                    <div className="space-y-3">
                      <div className="space-y-1">
                        <div className="flex items-center space-x-2">
                          <span className="text-[10px] font-mono font-bold text-[#F9423A] bg-[#F9423A]/5 px-1.5 py-0.5 rounded-none">A2</span>
                          <span className="text-[10px] font-mono font-bold text-[#F9423A] uppercase tracking-wide">
                            Fortaleza percibida • (Análisis: distribución de fortalezas percibidas)
                          </span>
                        </div>
                        <h4 className="text-xs font-bold text-gray-800 font-sans">
                          ¿Cuál consideras que es hoy el principal punto fuerte de la marca? <span className="text-gray-400 font-normal">(Opción única)</span>
                        </h4>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                        {[
                          'Propuesta de valor',
                          'Calidad de productos o servicios',
                          'Experiencia de cliente',
                          'Credibilidad y confianza',
                          'Innovación',
                          'Cercanía',
                          'Liderazgo en su categoría',
                          'Impacto o contribución'
                        ].map((opt) => (
                          <label key={opt} className={`flex items-center space-x-2 p-2.5 border rounded-none hover:bg-gray-50 cursor-pointer transition-colors ${
                            demoA2 === opt ? 'border-[#F9423A] bg-[#F9423A]/5' : 'border-gray-100'
                          }`}>
                            <input
                              type="radio"
                              name="demoA2"
                              checked={demoA2 === opt}
                              onChange={() => setDemoA2(opt)}
                              className="accent-[#F9423A]"
                            />
                            <span className="font-medium text-gray-700">{opt}</span>
                          </label>
                        ))}

                        {/* Custom Otro option for A2 */}
                        <div className={`col-span-1 sm:col-span-2 p-2.5 border rounded-none flex flex-col sm:flex-row sm:items-center gap-2 ${
                          demoA2 === 'Otro' ? 'border-[#F9423A] bg-[#F9423A]/5' : 'border-gray-100'
                        }`}>
                          <label className="flex items-center space-x-2 cursor-pointer text-xs">
                            <input
                              type="radio"
                              name="demoA2"
                              checked={demoA2 === 'Otro'}
                              onChange={() => setDemoA2('Otro')}
                              className="accent-[#F9423A]"
                            />
                            <span className="font-medium text-gray-700 shrink-0">Otro:</span>
                          </label>
                          <input
                            type="text"
                            value={demoA6}
                            disabled={demoA2 !== 'Otro'}
                            onChange={(e) => setDemoA6(e.target.value)}
                            placeholder="Escribe otra fortaleza..."
                            className="flex-1 text-xs px-2.5 py-1 border border-gray-200 focus:border-[#F9423A] rounded-none outline-none disabled:bg-gray-50 disabled:text-gray-400"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Question A3 */}
                    <div className="space-y-3">
                      <div className="space-y-1">
                        <div className="flex items-center space-x-2">
                          <span className="text-[10px] font-mono font-bold text-[#F9423A] bg-[#F9423A]/5 px-1.5 py-0.5 rounded-none">A3</span>
                          <span className="text-[10px] font-mono font-bold text-[#F9423A] uppercase tracking-wide">
                            Evaluación de la marca • (Análisis: índice global de percepción)
                          </span>
                        </div>
                        <h4 className="text-xs font-bold text-gray-800 font-sans">
                          Indica tu nivel de acuerdo con las siguientes afirmaciones:
                        </h4>
                      </div>
                      
                      <div className="border border-gray-100 rounded-none overflow-hidden text-xs">
                        {/* Table header */}
                        <div className="grid grid-cols-12 bg-[#f5f5f5] p-2 border-b border-gray-100 text-[10px] font-mono font-bold text-gray-400">
                          <span className="col-span-6 text-left ps-1">AFIRMACIÓN</span>
                          <span className="col-span-6 grid grid-cols-4 text-center">
                            <span>NADA</span>
                            <span>POCO</span>
                            <span>BASTANTE</span>
                            <span>MUCHO</span>
                          </span>
                        </div>

                        {[
                          'La marca tiene una propuesta clara',
                          'La marca es relevante para sus públicos',
                          'La marca se diferencia de las alternativas',
                          'La marca genera confianza',
                          'La marca proyecta una imagen coherente',
                          'La marca está evolucionando en la dirección adecuada'
                        ].map((sentence, idx) => (
                          <div key={idx} className="grid grid-cols-12 p-2 border-b border-gray-100 items-center last:border-b-0 hover:bg-gray-50/50">
                            <span className="col-span-6 font-medium text-gray-700 ps-1 font-sans">{sentence}</span>
                            <div className="col-span-6 grid grid-cols-4 text-center">
                              {['Nada', 'Poco', 'Bastante', 'Mucho'].map((val) => (
                                <input
                                  key={val}
                                  type="radio"
                                  name={`demoA3_${idx}`}
                                  checked={demoA3[idx] === val}
                                  onChange={() => setDemoA3(prev => ({ ...prev, [idx]: val }))}
                                  className="mx-auto accent-[#F9423A] scale-95"
                                />
                              ))}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Question A4 */}
                    <div className="space-y-3">
                      <div className="space-y-1">
                        <div className="flex items-center space-x-2">
                          <span className="text-[10px] font-mono font-bold text-[#F9423A] bg-[#F9423A]/5 px-1.5 py-0.5 rounded-none">A4</span>
                          <span className="text-[10px] font-mono font-bold text-[#F9423A] uppercase tracking-wide">
                            Apropiación de la idea de marca • (Análisis: comprensión y apropiación estratégica)
                          </span>
                        </div>
                        <h4 className="text-xs font-bold text-gray-800 font-sans">
                          La idea central de la marca es: <span className="text-[#F9423A] font-bold italic">"{config.ideaMarca || '[IDEA CENTRAL]'}"</span>. ¿Cuál de las siguientes opciones describe mejor tu opinión?
                        </h4>
                      </div>
                      <div className="space-y-1.5 text-xs">
                        {[
                          'No la entiendo',
                          'La entiendo, pero no la relaciono con la marca',
                          'La relaciono parcialmente con la marca',
                          'La relaciono claramente con la marca',
                          'La relaciono claramente y me parece diferencial'
                        ].map((opt) => (
                          <label key={opt} className={`flex items-center space-x-2 p-2.5 border rounded-none hover:bg-gray-50 cursor-pointer transition-colors ${
                            demoA4 === opt ? 'border-[#F9423A] bg-[#F9423A]/5' : 'border-gray-100'
                          }`}>
                            <input
                              type="radio"
                              name="demoA4"
                              checked={demoA4 === opt}
                              onChange={() => setDemoA4(opt)}
                              className="accent-[#F9423A]"
                            />
                            <span className="font-medium text-gray-700 font-sans">{opt}</span>
                          </label>
                        ))}
                      </div>
                    </div>

                    {/* Question A5 */}
                    <div className="space-y-3">
                      <div className="space-y-1">
                        <div className="flex items-center space-x-2">
                          <span className="text-[10px] font-mono font-bold text-[#F9423A] bg-[#F9423A]/5 px-1.5 py-0.5 rounded-none">A5</span>
                          <span className="text-[10px] font-mono font-bold text-[#F9423A] uppercase tracking-wide">
                            Personalidad percibida • (Análisis: mapa de personalidad percibida)
                          </span>
                        </div>
                        <h4 className="text-xs font-bold text-gray-800 font-sans">
                          ¿Cuáles de estas características describen mejor a la marca? <span className="text-gray-400 font-normal">(Máximo 3 elecciones)</span>
                        </h4>
                      </div>
                      <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                        {[
                          'Cercana',
                          'Innovadora',
                          'Fiable',
                          'Inspiradora',
                          'Experta',
                          'Dinámica',
                          'Transparente',
                          'Ambiciosa',
                          'Humana',
                          'Comprometida'
                        ].map((char) => {
                          const isSel = demoA5.includes(char);
                          return (
                            <button
                              key={char}
                              type="button"
                              onClick={() => handleCheckboxChangeA5(char)}
                              className={`p-2 border rounded-none text-xs select-none cursor-pointer transition-colors duration-350 ease-out ${
                                isSel
                                  ? 'bg-[#1a1a1a] text-white border-[#1a1a1a]'
                                  : 'bg-white border-gray-200 text-gray-600 hover:bg-gray-50'
                              }`}
                            >
                              {char}
                            </button>
                          );
                        })}
                      </div>

                      {/* Custom Otra option for A5 */}
                      <div className={`p-2.5 border rounded-none flex flex-col sm:flex-row sm:items-center gap-2 text-xs ${
                        demoA5.includes('otra') ? 'border-[#F9423A] bg-[#F9423A]/5' : 'border-gray-100'
                      }`}>
                        <button
                          type="button"
                          onClick={() => {
                            if (demoA5.includes('otra')) {
                              setDemoA5(prev => prev.filter(item => item !== 'otra'));
                            } else {
                              if (demoA5.length < 3) {
                                setDemoA5(prev => [...prev, 'otra']);
                              }
                            }
                          }}
                          className={`px-3 py-1.5 border rounded-none text-xs font-bold shrink-0 select-none cursor-pointer transition-colors ${
                            demoA5.includes('otra')
                              ? 'bg-[#1a1a1a] text-white border-[#1a1a1a]'
                              : 'bg-white border-gray-200 text-gray-600 hover:bg-gray-50'
                          }`}
                        >
                          Otra personalidad:
                        </button>
                        <input
                          type="text"
                          value={demoA7}
                          disabled={!demoA5.includes('otra')}
                          onChange={(e) => setDemoA7(e.target.value)}
                          placeholder="Escribe otra característica..."
                          className="flex-1 text-xs px-2.5 py-1 border border-gray-200 focus:border-[#F9423A] rounded-none outline-none disabled:bg-gray-50 disabled:text-gray-400"
                        />
                      </div>
                    </div>

                  </div>
                ) : (
                  /* SURVEY CONFIG B: EMPLOYEES */
                  <div className="space-y-6">
                    
                    {/* Header survey */}
                    <div className="p-4 bg-[#f5f5f5] rounded-none border border-gray-100">
                      <div className="flex items-center space-x-2">
                        <Briefcase className="w-4 h-4 text-[#1a1a1a]" />
                        <h3 className="text-sm font-bold text-[#1a1a1a] font-display">Estudio de implantación operativa e identidad interna (cuestionario B)</h3>
                      </div>
                      <p className="text-[11px] text-gray-400 mt-1 leading-relaxed font-sans">
                        Dirigido a directivos, empleados y equipos de trabajo de {config.marca}. Evalúa el grado de asimilación e implantación práctica del rebranding de forma cuantitativa y cualitativa.
                      </p>
                    </div>

                    {/* Question B1 */}
                    <div className="space-y-3">
                      <div className="space-y-1">
                        <div className="flex items-center space-x-2">
                          <span className="text-[10px] font-mono font-bold text-[#1a1a1a] bg-[#1a1a1a]/5 px-1.5 py-0.5 rounded-none">B1</span>
                          <span className="text-[10px] font-mono font-bold text-[#1a1a1a] uppercase tracking-wide">
                            (Análisis: índice de implantación)
                          </span>
                        </div>
                        <h4 className="text-xs font-bold text-gray-800 font-sans">
                          ¿Hasta qué punto estás de acuerdo con las siguientes afirmaciones?
                        </h4>
                      </div>
                      
                      <div className="border border-gray-100 rounded-none overflow-hidden text-xs">
                        {/* Table header */}
                        <div className="grid grid-cols-12 bg-[#f5f5f5] p-2 border-b border-gray-100 text-[10px] font-mono font-bold text-gray-400">
                          <span className="col-span-6 text-left ps-1">AFIRMACIÓN</span>
                          <span className="col-span-6 grid grid-cols-4 text-center">
                            <span>NADA</span>
                            <span>POCO</span>
                            <span>BASTANTE</span>
                            <span>MUCHO</span>
                          </span>
                        </div>

                        {[
                          'Entiendo el posicionamiento actual de la marca',
                          'Sé cómo aplicar la marca en mi trabajo diario',
                          'Dispongo de herramientas y recursos suficientes',
                          'La marca ayuda a tomar mejores decisiones',
                          'Existe coherencia entre lo que la marca promete y lo que hacemos'
                        ].map((sentence, idx) => (
                          <div key={idx} className="grid grid-cols-12 p-2 border-b border-gray-100 items-center last:border-b-0 hover:bg-gray-50/50">
                            <span className="col-span-6 font-medium text-gray-700 ps-1 font-sans">{sentence}</span>
                            <div className="col-span-6 grid grid-cols-4 text-center">
                              {['Nada', 'Poco', 'Bastante', 'Mucho'].map((val) => (
                                <input
                                  key={val}
                                  type="radio"
                                  name={`demoB1_${idx}`}
                                  checked={demoB1[idx] === val}
                                  onChange={() => setDemoB1(prev => ({ ...prev, [idx]: val }))}
                                  className="mx-auto accent-[#1a1a1a] scale-95"
                                />
                              ))}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Question B2 */}
                    <div className="space-y-3">
                      <div className="space-y-1">
                        <div className="flex items-center space-x-2">
                          <span className="text-[10px] font-mono font-bold text-[#1a1a1a] bg-[#1a1a1a]/5 px-1.5 py-0.5 rounded-none">B2</span>
                          <span className="text-[10px] font-mono font-bold text-[#1a1a1a] uppercase tracking-wide">
                            Prioridades de mejora • (Análisis: ranking de prioridades)
                          </span>
                        </div>
                        <h4 className="text-xs font-bold text-gray-800 font-sans">
                          ¿Cuál es el principal reto que debería abordar la marca durante los próximos seis meses? <span className="text-gray-400 font-normal">(Opción única)</span>
                        </h4>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                        {[
                          'Claridad del posicionamiento',
                          'Diferenciación',
                          'Comunicación',
                          'Experiencia de cliente',
                          'Coherencia entre canales',
                          'Innovación',
                          'Cultura interna',
                          'Activación comercial'
                        ].map((opt) => (
                          <label key={opt} className={`flex items-center space-x-2 p-2.5 border rounded-none hover:bg-gray-50 cursor-pointer transition-colors ${
                            demoB2 === opt ? 'border-[#1a1a1a] bg-[#1a1a1a]/5' : 'border-gray-100'
                          }`}>
                            <input
                              type="radio"
                              name="demoB2"
                              checked={demoB2 === opt}
                              onChange={() => {
                                setDemoB2(opt);
                              }}
                              className="accent-[#1a1a1a]"
                            />
                            <span className="font-medium text-gray-700 font-sans">{opt}</span>
                          </label>
                        ))}
                        
                        {/* Custom Otro option */}
                        <div className={`col-span-1 sm:col-span-2 p-2.5 border rounded-none flex flex-col sm:flex-row sm:items-center gap-2 ${
                          demoB2 === 'Otro' ? 'border-[#1a1a1a] bg-[#1a1a1a]/5' : 'border-gray-100'
                        }`}>
                          <label className="flex items-center space-x-2 cursor-pointer text-xs">
                            <input
                              type="radio"
                              name="demoB2"
                              checked={demoB2 === 'Otro'}
                              onChange={() => setDemoB2('Otro')}
                              className="accent-[#1a1a1a]"
                            />
                            <span className="font-medium text-gray-700 shrink-0">Otro:</span>
                          </label>
                          <input
                            type="text"
                            value={demoB4}
                            disabled={demoB2 !== 'Otro'}
                            onChange={(e) => setDemoB4(e.target.value)}
                            placeholder="Escribe tu propio reto o sugerencia..."
                            className="flex-1 text-xs px-2.5 py-1 border border-gray-200 focus:border-[#1a1a1a] rounded-none outline-none disabled:bg-gray-50 disabled:text-gray-400"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Question B3 */}
                    <div className="space-y-2">
                      <div className="space-y-1">
                        <div className="flex items-center space-x-2">
                          <span className="text-[10px] font-mono font-bold text-[#1a1a1a] bg-[#1a1a1a]/5 px-1.5 py-0.5 rounded-none">B3</span>
                          <span className="text-[10px] font-mono font-bold text-[#1a1a1a] uppercase tracking-wide">
                            Comentario abierto • (Análisis: clusters temáticos)
                          </span>
                        </div>
                        <h4 className="text-xs font-bold text-gray-800 font-sans">
                          Si pudieras cambiar una sola cosa de la marca, ¿qué cambiarías? <span className="text-gray-400 font-normal">(Aportación libre y espontánea)</span>
                        </h4>
                      </div>
                      <textarea
                        value={demoB3}
                        onChange={(e) => setDemoB3(e.target.value)}
                        rows={3}
                        placeholder="Escribe aquí tu respuesta sobre aquello que reformarías o impulsarías prioritariamente..."
                        className="w-full text-xs border border-gray-200 rounded-none p-3 focus:border-[#1a1a1a] outline-none leading-relaxed"
                      />
                    </div>

                  </div>
                )}

                {/* Submit button mock */}
                <div className="pt-4 border-t border-gray-100 flex justify-between items-center">
                  <span className="text-[10px] font-mono text-gray-400">
                    Modo simulación de cuestionario ágil.
                  </span>
                  <button
                    type="button"
                    onClick={() => setSubmittedDemo(true)}
                    className="bg-[#1a1a1a] hover:bg-black text-white font-mono text-xs font-bold py-2 px-4 rounded-none transition-colors duration-400 ease-out cursor-pointer"
                  >
                    Enviar Simulación de Respuesta
                  </button>
                </div>

              </div>
            )}

          </div>

        </div>

      </div>

    </div>
  );
};
