import React from 'react';

interface SparklineProps {
  data: number[];
  width?: number;
  height?: number;
  strokeColor?: string;
  fillColor?: string;
}

export const Sparkline: React.FC<SparklineProps> = ({
  data,
  width = 110,
  height = 36,
  strokeColor = '#F9423A', // Vibrant Comuniza red
  fillColor = 'transparent'
}) => {
  if (!data || data.length === 0) return null;

  const max = Math.max(...data);
  const min = Math.min(...data);
  const range = max - min === 0 ? 1 : max - min;

  // Map each data point to local SVG coordinate space
  const points = data.map((val, index) => {
    const x = (index / (data.length - 1)) * width;
    // Invert Y axis as SVG 0 is at the top
    const y = height - ((val - min) / range) * (height - 6) - 3;
    return { x, y };
  });

  const pathD = points
    .map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x.toFixed(1)} ${p.y.toFixed(1)}`)
    .join(' ');

  // Create optional background gradient-like area fill
  const areaD = points.length ? `${pathD} L ${points[points.length - 1].x.toFixed(1)} ${height} L ${points[0].x.toFixed(1)} ${height} Z` : '';

  return (
    <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`} className="overflow-visible">
      {fillColor !== 'transparent' && points.length > 0 && (
        <path d={areaD} fill={fillColor} opacity="0.08" stroke="none" />
      )}
      <path
        d={pathD}
        fill="none"
        stroke={strokeColor}
        strokeWidth="1.6"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      {/* Dynamic hover-free dot on the last position for premium style */}
      {points.length > 0 && (
        <circle
          cx={points[points.length - 1].x}
          cy={points[points.length - 1].y}
          r="2.5"
          fill={strokeColor}
          stroke="#f5f5f5"
          strokeWidth="1"
        />
      )}
    </svg>
  );
};
