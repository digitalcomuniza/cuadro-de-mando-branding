/**
 * Types and interfaces for the Comuniza Brand Meaning & Rebranding Tracker
 * Oriented to S1 and S2 Semestral Evaluation
 */

export interface PlaceholderConfig {
  marca: string;          // Evaluated brand name (e.g., "Nexo Corporación")
  ideaMarca: string;      // Core brand idea (e.g., "Transformación desde el fondo")
  periodicidad: string;   // Always "Semestral"
  cohorteMuestra: string; // Target audience description (e.g., "Clientes B2B + Equipo Global")
  numContactos: number;   // Total sample contacts (e.g., 1200)
}

export interface WordCloudItem {
  text: string;
  value: number; // frequency count / percentage
}

export interface AverageScoresA3 {
  propuesta_clara: number;              // 0-10 scale
  relevancia_publicos: number;          // 0-10 scale
  diferenciacion_alternativas: number;  // 0-10 scale
  genera_confianza: number;             // 0-10 scale
  proyecta_coherencia: number;          // 0-10 scale
  evolucion_adecuada: number;           // 0-10 scale
}

export interface AverageScoresB1 {
  entiendo_posicionamiento: number;     // 0-10 scale
  se_aplicar_marca: number;             // 0-10 scale
  recursos_suficientes: number;         // 0-10 scale
  mejores_decisiones: number;           // 0-10 scale
  coherencia_promesa: number;           // 0-10 scale
}

export interface IdeaApropiacionDistribution {
  no_la_entiendo: number;              // percentage %
  no_relaciono: number;                // percentage %
  relaciono_parcialmente: number;      // percentage %
  relaciono_claramente: number;        // percentage %
  relaciono_y_diferencial: number;     // percentage %
}

export interface ClusterMejora {
  name: string;
  percentage: number;
}

export interface CustomQuestion {
  header: string;
  audience: 'clientes' | 'equipo';
  type: 'numeric' | 'categorical' | 'text';
  average?: number;
  distribution?: Record<string, number>;
  answers?: string[];
  words?: WordCloudItem[];
}

export interface SemesterData {
  id: string;               // e.g. "S1-2025", "S2-2025", "S1-2026", "S2-2026"
  periodo: string;          // e.g., "2025-S1", "2025-S2", etc.
  customQuestions?: CustomQuestion[];
  
  // CLIENTE / MERCADO (Survey A)
  clienteNumRespuestas: number;
  palabrasA1: WordCloudItem[];
  fortalezasA2: Record<string, number>;        // option -> percentage
  acuerdoA3: AverageScoresA3;
  apropiacionA4: IdeaApropiacionDistribution;   // % distribution
  personalidadA5: Record<string, number>;      // attribute -> percentage
  retosA6: Record<string, number>;             // option -> percentage
  clustersA7: ClusterMejora[];                 // clusters derived from text

  // EMPLEADO / INTERNO (Survey B)
  empleadoNumRespuestas: number;
  acuerdoB1: AverageScoresB1;
  apropiacionB2: IdeaApropiacionDistribution;   // % distribution
  barrerasB3: Record<string, number>;          // option -> percentage
  clustersB4: ClusterMejora[];                 // clusters derived from text
}

export interface Prescription {
  id: string;   // e.g. "significado", "fortaleza", "alineamiento", "implantacion"
  name: string;  // Indicator Name
  text: string;  // Strategic copy
}

export interface RawSurveyResponseARow {
  semestre: string; // e.g. "2025-S1"
  p1_palabras: string; // comma separated
  p2_fortaleza: string;
  p3_propuesta_clara: number;
  p3_relevancia: number;
  p3_diferenciacion: number;
  p3_confianza: number;
  p3_coherencia: number;
  p3_evolucion: number;
  p4_apropiacion: string;
  p5_atributos: string; // comma separated selection
  p6_reto: string;
  p7_cambia_una_cosa: string;
}

export interface RawSurveyResponseBRow {
  semestre: string; // e.g. "2025-S1"
  p1_entiendo: number;
  p1_se_aplicar: number;
  p1_recursos: number;
  p1_decisiones: number;
  p1_coherencia: number;
  p2_apropiacion: string;
  p3_barrera: string;
  p4_necesidad: string;
}
