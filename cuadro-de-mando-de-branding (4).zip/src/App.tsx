import React, { useState, useEffect } from 'react';
import { PlaceholderConfig, SemesterData, Prescription } from './types';
import { getInitialSemesters, getDefaultPrescriptions } from './data';
import { VistaComoFunciona } from './components/VistaComoFunciona';
import { VistaCuestionario } from './components/VistaCuestionario';
import { VistaDashboardSignificados } from './components/VistaDashboardSignificados';
import { 
  BarChart3, 
  HelpCircle, 
  FileCheck2, 
  RotateCcw, 
  Sparkles,
  Info,
  Layers,
  ArrowRight,
  Lock,
  Unlock
} from 'lucide-react';

export default function App() {
  // 2. Semesters historical data state with LocalStorage safe recovery
  const [semesters, setSemesters] = useState<SemesterData[]>(() => {
    try {
      const persisted = localStorage.getItem('comuniza_rebrand_semesters');
      if (persisted) return JSON.parse(persisted);
    } catch (e) {
      console.warn("Storage access restricted. Falls back to default state.");
    }
    return getInitialSemesters();
  });

  // 3. Selection of active Semester ID
  const [selectedSemesterId, setSelectedSemesterId] = useState<string>(() => {
    try {
      const persisted = localStorage.getItem('comuniza_rebrand_semesters');
      if (persisted) {
        const parsed = JSON.parse(persisted);
        if (parsed && parsed.length > 0) {
          return parsed[parsed.length - 1].id;
        }
      }
    } catch (e) {}
    return '';
  });

  // 4. Strategic editable prescriptions with LocalStorage safe recovery
  const [prescriptions, setPrescriptions] = useState<Prescription[]>(() => {
    try {
      const persisted = localStorage.getItem('comuniza_rebrand_prescriptions');
      if (persisted) return JSON.parse(persisted);
    } catch (e) {
      // safe fallback
    }
    return getDefaultPrescriptions();
  });

  // 4.1 Config with LocalStorage safe recovery
  const [config, setConfig] = useState<PlaceholderConfig>(() => {
    try {
      const persisted = localStorage.getItem('comuniza_rebrand_config');
      if (persisted) return JSON.parse(persisted);
    } catch (e) {
      // safe fallback
    }
    return {
      marca: '[NOMBRE DEL CLIENTE]',
      ideaMarca: '[IDEA CENTRAL DE MARCA]',
      periodicidad: 'Semestral',
      cohorteMuestra: 'Clientes Mercado + Equipo Interno',
      numContactos: 0
    };
  });

  const [showConfigModal, setShowConfigModal] = useState(false);

  // Auto-open modal if placeholders are present to guide the user on first load
  useEffect(() => {
    if (config.marca === '[NOMBRE DEL CLIENTE]' || config.ideaMarca === '[IDEA CENTRAL DE MARCA]') {
      setShowConfigModal(true);
    }
  }, [config.marca, config.ideaMarca]);

  // Helper to persist changes
  const saveSemestersWithPersist = (newSemesters: SemesterData[]) => {
    setSemesters(newSemesters);
    try {
      localStorage.setItem('comuniza_rebrand_semesters', JSON.stringify(newSemesters));
    } catch (e) {
      // ignore
    }
  };

  const saveConfigWithPersist = (newConfig: PlaceholderConfig) => {
    setConfig(newConfig);
    try {
      localStorage.setItem('comuniza_rebrand_config', JSON.stringify(newConfig));
    } catch (e) {
      // ignore
    }
  };

  const savePrescriptionsWithPersist = (newPrescriptions: Prescription[]) => {
    setPrescriptions(newPrescriptions);
    try {
      localStorage.setItem('comuniza_rebrand_prescriptions', JSON.stringify(newPrescriptions));
    } catch (e) {
      // ignore
    }
  };

  // 4.5 Access profile (Consultor vs Marca) - can be preset via URL parameter (?acceso=cliente or ?acceso=comuniza)
  const [perfilAcceso, setPerfilAcceso] = useState<'consultor' | 'marca'>(() => {
    try {
      const params = new URLSearchParams(window.location.search);
      const acceso = params.get('acceso') || params.get('role');
      if (acceso === 'cliente' || acceso === 'marca' || acceso === 'lector' || acceso === 'client') {
        return 'marca';
      }
      if (acceso === 'comuniza' || acceso === 'editor' || acceso === 'consultor') {
        return 'consultor';
      }
    } catch (e) {
      // safe fallback
    }
    return 'consultor'; // default
  });

  // 5. Navigation Tabs: 'como-funciona' | 'cuestionario' | 'dashboard'
  const [activeTab, setActiveTab] = useState<'como-funciona' | 'cuestionario' | 'dashboard'>('dashboard');

  // Unified factory reset to pristine empty template state
  const handleReset = () => {
    if (window.confirm('¿Seguro que deseas restablecer el cuadro de mando? Se borrarán todas las importaciones y datos cargados.')) {
      setSemesters([]);
      localStorage.removeItem('comuniza_rebrand_semesters');
      setPrescriptions(getDefaultPrescriptions());
      localStorage.removeItem('comuniza_rebrand_prescriptions');
      setSelectedSemesterId('');
      const defaultConf = {
        marca: '[NOMBRE DEL CLIENTE]',
        ideaMarca: '[IDEA CENTRAL DE MARCA]',
        periodicidad: 'Semestral',
        cohorteMuestra: 'Clientes Mercado + Equipo Interno',
        numContactos: 0
      };
      setConfig(defaultConf);
      localStorage.setItem('comuniza_rebrand_config', JSON.stringify(defaultConf));
      setActiveTab('dashboard');
    }
  };

  return (
    <div className="min-h-screen bg-[#f5f5f5] text-[#1a1a1a] flex flex-col font-sans antialiased selection:bg-[#F9423A]/10 selection:text-[#F9423A]" id="brand-meaning-app-root">
      
      {/* 1. SOPHISTICATED EDITORIAL HEADER IN COMUNIZA DESIGN SYSTEM */}
      <header className="sticky top-0 bg-white/95 backdrop-blur z-30 border-b border-[#E5E5E0] px-6 py-4 hide-during-print">
        <div className="max-w-7xl mx-auto flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          
          {/* Logo & Brand Designation */}
          <div className="flex flex-col sm:flex-row sm:items-center sm:space-x-5 gap-3">
            <div className="flex items-center select-none flex-shrink-0" id="comuniza-logo-textmark">
              <img
                src="https://www.topcomunicacion.com/wp-content/uploads/2024/09/logo-comuniza.jpg"
                alt="Comuniza"
                className="h-10 w-auto object-contain hover:opacity-90 transition-opacity duration-300"
                referrerPolicy="no-referrer"
              />
            </div>
 
            <div className="hidden sm:block h-8 w-[1px] bg-[#E5E5E0]" />
 
            <div className="space-y-0.5">
              <div className="flex items-center space-x-2">
                <span className="font-mono text-[9px] uppercase font-bold tracking-widest text-[#F9423A] bg-[#F9423A]/5 px-2 py-0.5 rounded-none">
                  REBRANDING MONITOR • COMUNIZA INDICES
                </span>
                <span className="font-mono text-[9px] uppercase font-bold text-gray-450">
                  | SEGUIMIENTO SEMESTRAL DE TRANSFORMACIÓN
                </span>
              </div>
              
              <h1 className="text-sm font-bold font-display text-[#1a1a1a] tracking-tight">
                Cuadro de mando de significados de marca
              </h1>
            </div>
          </div>
 
          {/* Tab Navigation Menu */}
          <div className="flex items-center gap-2 select-none">
            <nav className="flex items-center space-x-1 border border-[#E5E5E0] rounded-none bg-[#f5f5f5] p-1" id="navigation-bar-3view">
              
              <button
                onClick={() => setActiveTab('como-funciona')}
                className={`flex items-center space-x-1.5 px-3 py-1.5 text-xs font-mono font-bold rounded-none transition-all duration-400 ease-[cubic-bezier(0.32,0.72,0,1)] whitespace-nowrap select-none cursor-pointer ${
                  activeTab === 'como-funciona'
                    ? 'bg-[#1a1a1a] text-white shadow-xs'
                    : 'text-gray-500 hover:text-[#1a1a1a] hover:bg-gray-100'
                }`}
                id="btn-tab-como-funciona"
              >
                <HelpCircle className="w-3.5 h-3.5" />
                <span>Cómo Funciona</span>
              </button>
 
              <button
                onClick={() => setActiveTab('cuestionario')}
                className={`flex items-center space-x-1.5 px-3 py-1.5 text-xs font-mono font-bold rounded-none transition-all duration-400 ease-[cubic-bezier(0.32,0.72,0,1)] whitespace-nowrap select-none cursor-pointer ${
                  activeTab === 'cuestionario'
                    ? 'bg-[#1a1a1a] text-white shadow-xs'
                    : 'text-gray-500 hover:text-[#1a1a1a] hover:bg-gray-100'
                }`}
                id="btn-tab-el-cuestionario"
              >
                <FileCheck2 className="w-3.5 h-3.5" />
                <span>Cuestionarios</span>
              </button>
 
              <button
                onClick={() => setActiveTab('dashboard')}
                className={`flex items-center space-x-1.5 px-3 py-1.5 text-xs font-mono font-bold rounded-none transition-all duration-400 ease-[cubic-bezier(0.32,0.72,0,1)] whitespace-nowrap select-none cursor-pointer ${
                  activeTab === 'dashboard'
                    ? 'bg-[#1a1a1a] text-white shadow-xs'
                    : 'text-gray-500 hover:text-[#1a1a1a] hover:bg-gray-100'
                }`}
                id="btn-tab-dashboard-significados"
              >
                <BarChart3 className="w-3.5 h-3.5" />
                <span>Dashboard Dual</span>
              </button>
 
            </nav>
 
            {/* Global reset button */}
            <button 
              onClick={handleReset}
              className="p-2 border border-[#E5E5E0] text-gray-400 hover:text-[#F9423A] hover:border-[#F9423A]/35 hover:bg-[#F9423A]/5 rounded-none transition-all duration-400 ease-[cubic-bezier(0.32,0.72,0,1)] cursor-pointer"
              title="Restablecer a valores de fábrica"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>
 
         </div>
      </header>
 
      {/* 2. SUB-ALERT CALLOUT SHOWING CONFIG PARAMETERS SHORTCUT FOR SPEEDY READING */}
      <div className="bg-[#1a1a1a] text-white text-xs px-6 py-2.5 flex items-center justify-between font-mono hide-during-print">
        <div className="max-w-7xl mx-auto w-full flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
          <div className="flex flex-wrap items-center gap-x-2 gap-y-1 truncate">
            <Sparkles className="w-3.5 h-3.5 text-[#F9423A] shrink-0" />
            <span className="text-gray-400">Marca Evaluada:</span>
            <span className="text-white font-bold">{config.marca}</span>
            <span className="text-gray-600">•</span>
            <span className="text-gray-400">Concepto Central:</span>
            <span className="text-[#F9423A] font-bold">"{config.ideaMarca}"</span>
          </div>
          
          <div className="flex items-center gap-3">
            <button
              onClick={() => setShowConfigModal(true)}
              className="px-2 py-0.5 border border-[#F9423A]/30 text-[#F9423A] hover:bg-[#F9423A] hover:text-white transition-all text-[10px] uppercase font-bold tracking-wider rounded-none cursor-pointer"
            >
              Configurar cliente
            </button>
            <div className="text-right text-[11px] text-gray-400 font-bold">
              Intervalo: <span className="text-white font-extrabold">{config.periodicidad.toUpperCase()}</span>
            </div>
          </div>
        </div>
      </div>
 
      {/* 2.5 DUAL ACCESS ROLE INFO BAR (INFORMATIVA Y OPERATIVA) */}
      <div className="bg-[#f5f5f5] border-b border-[#E5E5E0] px-6 py-2.5 hide-during-print">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center md:justify-between gap-3 font-mono text-[11px]">
          <div className="flex items-center space-x-2">
            <span className="flex h-2 w-2 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-none bg-[#F9423A] opacity-75"></span>
              <span className="relative inline-flex rounded-none h-2 w-2 bg-[#F9423A]"></span>
            </span>
            <span className="text-[#1a1a1a] font-bold">Perfil de Acceso Activo:</span>
            {perfilAcceso === 'consultor' ? (
              <span className="bg-[#1a1a1a]/10 text-[#1a1a1a] px-2 py-0.5 rounded-none font-bold flex items-center space-x-1">
                <Unlock className="w-3 h-3 mr-0.5" />
                <span>Consultor (COMUNIZA - Edición habilitada)</span>
              </span>
            ) : (
              <span className="bg-gray-200 text-gray-700 px-2 py-0.5 rounded-none font-bold flex items-center space-x-1">
                <Lock className="w-3 h-3 mr-0.5" />
                <span>Cliente / Marca Evaluada (Solo Lectura)</span>
              </span>
            )}
          </div>
 
          <div className="flex flex-wrap items-center gap-3">
            <span className="text-gray-400 font-medium">Accesos vía URL para publicar:</span>
            <div className="flex space-x-1.5">
              <button
                onClick={() => {
                  setPerfilAcceso('consultor');
                  // Update URL parameter without full reload for elegance
                  const newUrl = window.location.protocol + "//" + window.location.host + window.location.pathname + '?acceso=comuniza';
                  window.history.pushState({ path: newUrl }, '', newUrl);
                }}
                className={`px-2 py-0.5 rounded-none border transition-all duration-400 ease-[cubic-bezier(0.32,0.72,0,1)] text-[10px] cursor-pointer font-bold ${
                  perfilAcceso === 'consultor'
                    ? 'border-[#1a1a1a] bg-[#1a1a1a]/5 text-[#1a1a1a]'
                    : 'border-gray-200 text-gray-500 hover:text-[#1a1a1a]'
                }`}
                title="Simula cómo vería y editaría el cuadro de mando el equipo de Comuniza"
              >
                ?acceso=comuniza (Editor)
              </button>
              <button
                onClick={() => {
                  setPerfilAcceso('marca');
                  // Update URL parameter without full reload for elegance
                  const newUrl = window.location.protocol + "//" + window.location.host + window.location.pathname + '?acceso=cliente';
                  window.history.pushState({ path: newUrl }, '', newUrl);
                }}
                className={`px-2 py-0.5 rounded-none border transition-all duration-400 ease-[cubic-bezier(0.32,0.72,0,1)] text-[10px] cursor-pointer font-bold ${
                  perfilAcceso === 'marca'
                    ? 'border-[#1a1a1a] bg-[#1a1a1a]/5 text-[#1a1a1a]'
                    : 'border-gray-200 text-gray-500 hover:text-[#1a1a1a]'
                }`}
                title="Simula cómo vería el cuadro de mando el cliente final (solo lectura)"
              >
                ?acceso=cliente (Lector)
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* 3. CORE PRESENTATIONAL BODY */}
      <main className="flex-1 w-full max-w-7xl mx-auto px-6 py-8">
        
        {activeTab === 'como-funciona' && (
          <VistaComoFunciona 
            config={config} 
            setConfig={saveConfigWithPersist}
            semesters={semesters}
            setSemesters={saveSemestersWithPersist}
            prescriptions={prescriptions}
            setPrescriptions={savePrescriptionsWithPersist}
            setActiveTab={setActiveTab}
          />
        )}

        {activeTab === 'cuestionario' && (
          <VistaCuestionario 
            config={config} 
            setConfig={saveConfigWithPersist} 
            perfilAcceso={perfilAcceso}
          />
        )}

        {activeTab === 'dashboard' && (
          <VistaDashboardSignificados 
            semesters={semesters}
            setSemesters={saveSemestersWithPersist}
            selectedSemesterId={selectedSemesterId}
            setSelectedSemesterId={setSelectedSemesterId}
            prescriptions={prescriptions}
            setPrescriptions={savePrescriptionsWithPersist}
            config={config}
            setConfig={saveConfigWithPersist}
            perfilAcceso={perfilAcceso}
            setPerfilAcceso={setPerfilAcceso}
          />
        )}

      </main>

      {/* 4. PREMIUM COMUNIZA FOOTER CREDITS */}
      <footer className="border-t border-[#E5E5E0] bg-white px-6 py-6 mt-16 text-[11px] text-gray-400 font-mono hide-during-print">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center w-full gap-4">
          <div className="flex flex-wrap items-center gap-2" id="footer-credits">
            <span className="font-extrabold text-[#F9423A] tracking-tighter">comuniza<span className="font-sans">,</span></span>
            <span className="text-gray-200">|</span>
            <span className="font-medium text-gray-600">MVP para el seguimiento de la Percepción de Significados de Marca y Alineamiento Cultural</span>
            <span className="text-gray-300">•</span>
            <span>Estudio Premium encapsulado.</span>
          </div>
          <div className="flex space-x-4">
            <a href="https://comuniza.com" target="_blank" rel="noopener noreferrer" className="hover:text-[#F9423A] transition-colors text-gray-500 font-bold">
              comuniza.com
            </a>
            <span className="text-gray-200">|</span>
            <span className="text-gray-400 font-medium font-mono">Instrumento Prototipado</span>
          </div>
        </div>
      </footer>

      {/* 5. CLIENT CONFIGURATION MODAL */}
      {showConfigModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-comuniza-fadeIn">
          <div className="bg-white border border-[#E5E5E0] shadow-2xl max-w-md w-full p-6 space-y-4 rounded-none">
            <div className="flex justify-between items-center pb-2 border-b border-gray-100">
              <div className="flex items-center space-x-2">
                <Sparkles className="w-4 h-4 text-[#F9423A]" />
                <h3 className="font-bold font-display text-sm uppercase tracking-wide text-[#1a1a1a]">
                  Configurar Cliente de Marca
                </h3>
              </div>
              <button
                onClick={() => setShowConfigModal(false)}
                className="text-gray-400 hover:text-gray-700 text-xs font-mono font-bold"
              >
                Cerrar
              </button>
            </div>

            <p className="text-xs text-gray-500 leading-relaxed font-sans">
              Personaliza el nombre del cliente y el concepto central de su marca para inyectarlos dinámicamente en todo el cuadro de mando.
            </p>

            <div className="space-y-4">
              <div className="space-y-1">
                <label className="block text-[10px] font-mono font-bold text-gray-400 uppercase tracking-wider">
                  Nombre de la Marca Evaluada
                </label>
                <input
                  type="text"
                  value={config.marca}
                  onChange={(e) => saveConfigWithPersist({ ...config, marca: e.target.value })}
                  className="w-full text-xs bg-[#f5f5f5] border border-[#E5E5E0] focus:border-[#F9423A] rounded-none p-2.5 outline-none font-medium transition-colors"
                  placeholder="Ej. Nexo Corporación o [NOMBRE DEL CLIENTE]"
                />
              </div>

              <div className="space-y-1">
                <label className="block text-[10px] font-mono font-bold text-gray-400 uppercase tracking-wider">
                  Concepto Central / Idea de Marca
                </label>
                <textarea
                  value={config.ideaMarca}
                  onChange={(e) => saveConfigWithPersist({ ...config, ideaMarca: e.target.value })}
                  rows={2}
                  className="w-full text-xs bg-[#f5f5f5] border border-[#E5E5E0] focus:border-[#F9423A] rounded-none p-2.5 outline-none font-medium transition-colors leading-relaxed"
                  placeholder="Ej. Transformación desde el fondo o [IDEA CENTRAL DE MARCA]"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="space-y-1">
                  <label className="block text-[10px] font-mono font-bold text-gray-400 uppercase tracking-wider">
                    Población / Target Muestra
                  </label>
                  <input
                    type="text"
                    value={config.cohorteMuestra}
                    onChange={(e) => saveConfigWithPersist({ ...config, cohorteMuestra: e.target.value })}
                    className="w-full text-xs bg-[#f5f5f5] border border-[#E5E5E0] focus:border-[#F9423A] rounded-none p-2 outline-none font-medium transition-colors"
                    placeholder="Ej. Clientes + Equipo"
                  />
                </div>
                <div className="space-y-1">
                  <label className="block text-[10px] font-mono font-bold text-gray-400 uppercase tracking-wider">
                    Contactos Totales
                  </label>
                  <input
                    type="number"
                    value={config.numContactos}
                    onChange={(e) => saveConfigWithPersist({ ...config, numContactos: parseInt(e.target.value) || 0 })}
                    className="w-full text-xs bg-[#f5f5f5] border border-[#E5E5E0] focus:border-[#F9423A] rounded-none p-2 outline-none font-medium transition-colors"
                    placeholder="Ej. 305"
                  />
                </div>
              </div>
            </div>

            <div className="pt-2">
              <button
                type="button"
                onClick={() => setShowConfigModal(false)}
                className="w-full py-2.5 bg-[#1a1a1a] hover:bg-black text-white text-xs font-mono font-bold transition-colors rounded-none"
              >
                Guardar y Aplicar Cambios
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
