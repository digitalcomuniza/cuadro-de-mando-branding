import { SemesterData, Prescription } from './types';

// Default editable prescriptions for indicators when they report a drop or to offer strategic guidelines
export const getDefaultPrescriptions = (): Prescription[] => [
  {
    id: 'significado',
    name: 'Significado de marca (imagen y asociaciones externas)',
    text: 'Las asociaciones espontáneas y la personalidad percibida muestran cierta dispersión o retroceso. Se aconseja consolidar un relato de marca único (brand narrative) integrado, auditar la coherencia visual/verbal en los puntos de contacto digitales clave y renovar los mensajes de valor en tus canales principales.'
  },
  {
    id: 'fortaleza',
    name: 'Fortaleza y diferenciación (competitividad y propuesta)',
    text: 'La claridad, relevancia o diferenciación de tu propuesta frente a competidores ha descendido en el mercado. Es imperativo revisar la propuesta de valor y los mensajes de diferenciación estratégica. Incrementa el esfuerzo de comunicación enfocado en beneficios exclusivos y evita competir puramente en precio.'
  },
  {
    id: 'alineamiento',
    name: 'Alineamiento estratégico (gap cliente vs. interno)',
    text: 'Se ha ensanchado la brecha (gap) entre la comprensión interna (empleados) y la asimilación del cliente. Esto ocurre cuando la cultura interna no se externaliza bien. Es fundamental traducir el entusiasmo y entrenamiento del equipo en activaciones de marca y campañas que demuestren de forma tangible la idea de marca afuera.'
  },
  {
    id: 'implantacion',
    name: 'Implantación operativa (capacidad del equipo para lanzar)',
    text: 'El equipo interno reporta dificultades o confusión para aplicar la marca. Esto suele deberse a falta de recursos o de entendimiento práctico. Se aconseja convocar seminarios prácticos por áreas de negocio, actualizar e implementar herramientas ágiles en el Brand Center y distribuir plantillas prediseñadas listas para usar.'
  }
];

export const getInitialSemesters = (): SemesterData[] => [];

// Calculation helpers for the 4 synthetic indices (0-100 score)
export function calcularSignificadoScore(sem: SemesterData): number {
  // A5 Personality attributes - sum of typical positive traits / divisor.
  // Cercana, Innovadora, Fiable, Inspiradora, Experta, Dinámica, Humana, Comprometida
  const keys = ['Cercana', 'Innovadora', 'Fiable', 'Inspiradora', 'Experta', 'Dinámica', 'Humana', 'Comprometida'];
  let sum = 0;
  keys.forEach(k => {
    sum += sem.personalidadA5[k] || 0;
  });
  // If sum is let's say 250% (since multiple choices), average of these is around 31%. 
  // Let's scale properly: normal sum goes up to ~250%. Let's divide by 3 and cap at 100, but make sure S1 scales to ~50% and S4 to ~90%.
  const raw = sum / 3.2;
  return Math.min(100, Math.max(0, Math.round(raw)));
}

export function calcularFortalezaScore(sem: SemesterData): number {
  // A3 agreement averages (0-10) scaled to 0-100.
  const ac = sem.acuerdoA3;
  const avg = (ac.propuesta_clara + ac.relevancia_publicos + ac.diferenciacion_alternativas + ac.genera_confianza + ac.proyecta_coherencia + ac.evolucion_adecuada) / 6;
  return Math.min(100, Math.max(0, Math.round(avg * 10)));
}

export function calcularApropiacionScore(dist: any): number {
  // Weighted score from 0-100: no la entiendo (0), no relaciono (25), parcialmente (50), claramente (80), diferencial (100)
  const score = (dist.no_la_entiendo * 0) +
                (dist.no_relaciono * 25) +
                (dist.relaciono_parcialmente * 55) +
                (dist.relaciono_claramente * 85) +
                (dist.relaciono_y_diferencial * 100);
  return Math.min(100, Math.max(0, Math.round(score / 100)));
}

export function calcularAlineamientoDashboard(sem: SemesterData): { cliente: number, interno: number, gap: number, score: number } {
  const cliente = calcularApropiacionScore(sem.apropiacionA4);
  const interno = calcularApropiacionScore(sem.apropiacionB2);
  const gap = interno - cliente; // how much internal understands more than external, or vice versa
  // High alignment means gap is close to 0. Score = 100 - abs(gap) adjusted, let's say:
  const absGap = Math.abs(gap);
  const score = Math.max(0, Math.round(100 - absGap * 1.5)); // Penalize bigger gap
  return { cliente, interno, gap, score };
}

export function calcularImplantacionScore(sem: SemesterData): number {
  // B1 agreement averages (0-10) scaled to 0-100.
  const ac = sem.acuerdoB1;
  const avg = (ac.entiendo_posicionamiento + ac.se_aplicar_marca + ac.recursos_suficientes + ac.mejores_decisiones + ac.coherencia_promesa) / 5;
  return Math.min(100, Math.max(0, Math.round(avg * 10)));
}
